import type { DegradedResult, LinearIssue, SourceResult } from "../types.js";

const LINEAR_API = "https://api.linear.app/graphql";
const TIMEOUT_MS = 5000;

function authHeaders(): Record<string, string> {
  return {
    Authorization: process.env.LINEAR_API_KEY ?? "",
    "Content-Type": "application/json",
  };
}

async function graphql(
  query: string,
  variables?: Record<string, unknown>
): Promise<SourceResult<Record<string, unknown>>> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), TIMEOUT_MS);
  try {
    const res = await fetch(LINEAR_API, {
      method: "POST",
      headers: authHeaders(),
      body: JSON.stringify({ query, variables }),
      signal: controller.signal,
    });
    if (res.status === 401) return { degraded: true, reason: "auth_failed" };
    if (res.status === 429) {
      const retry = parseInt(res.headers.get("retry-after") ?? "60", 10);
      return { degraded: true, reason: "rate_limited", retry_after: retry };
    }
    if (!res.ok) return { degraded: true, reason: "unavailable" };
    const json = (await res.json()) as { data?: Record<string, unknown>; errors?: { message: string }[] };
    if (json.errors?.length) {
      return { degraded: true, reason: "graphql_error", message: json.errors[0].message };
    }
    return { data: json.data ?? {} };
  } catch (err: unknown) {
    if (err instanceof Error && err.name === "AbortError") {
      return { degraded: true, reason: "timeout" };
    }
    return { degraded: true, reason: "unavailable" };
  } finally {
    clearTimeout(timer);
  }
}

function mapIssue(issue: Record<string, unknown>): LinearIssue {
  return {
    id: issue.id as string,
    title: issue.title as string,
    url: issue.url as string,
    state: ((issue.state as Record<string, string>)?.name) ?? "Unknown",
    priority: (issue.priority as number) ?? 0,
    team: ((issue.team as Record<string, string>)?.name) ?? "Unknown",
  };
}

export async function getIssues(
  teamKey?: string,
  status?: string
): Promise<SourceResult<{ issues: LinearIssue[] }>> {
  const conditions: string[] = [];
  const variables: Record<string, unknown> = {};

  if (teamKey) {
    conditions.push("team: { key: { eq: $teamKey } }");
    variables.teamKey = teamKey;
  }
  if (status) {
    conditions.push("state: { name: { eq: $status } }");
    variables.status = status;
  }

  const varDecl = Object.keys(variables)
    .map((k) => `$${k}: String`)
    .join(", ");
  const filterArg = conditions.length
    ? `(filter: { ${conditions.join(", ")} })`
    : "";
  const queryDecl = varDecl ? `query(${varDecl})` : "query";

  const query = `${queryDecl} {
    issues${filterArg} {
      nodes { id title url priority state { name } team { name } }
    }
  }`;

  const result = await graphql(query, Object.keys(variables).length ? variables : undefined);
  if ("degraded" in result && result.degraded) return result as DegradedResult;
  const issuesData = result.data.issues as Record<string, unknown> | undefined;
  const nodes = issuesData?.nodes as Record<string, unknown>[] | undefined;
  if (!nodes) return { degraded: true, reason: "unavailable" };
  return { data: { issues: nodes.map(mapIssue) } };
}

export async function getIssue(
  issueId: string
): Promise<SourceResult<{ issue: LinearIssue }>> {
  const query = `query($id: String!) {
    issue(id: $id) { id title url priority state { name } team { name } }
  }`;
  const result = await graphql(query, { id: issueId });
  if ("degraded" in result && result.degraded) return result as DegradedResult;
  if (!result.data.issue) return { degraded: true, reason: "not_found" };
  return { data: { issue: mapIssue(result.data.issue as Record<string, unknown>) } };
}

export async function createIssue(
  title: string,
  teamId: string,
  description?: string
): Promise<SourceResult<{ issue: { id: string; url: string } }>> {
  const query = `mutation($input: IssueCreateInput!) {
    issueCreate(input: $input) { issue { id url } }
  }`;
  const input: Record<string, string> = { title, teamId };
  if (description) input.description = description;
  const result = await graphql(query, { input });
  if ("degraded" in result && result.degraded) return result as DegradedResult;
  const issueCreateData = result.data.issueCreate as Record<string, unknown> | undefined;
  const created = issueCreateData?.issue as { id: string; url: string } | undefined;
  if (!created) return { degraded: true, reason: "unavailable" };
  return { data: { issue: created } };
}
