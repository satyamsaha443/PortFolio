import { describe, it, expect, vi } from "vitest";
import { projectStatusRollup } from "../../src/tools/status-rollup.js";

vi.mock("../../src/connectors/github.js", () => ({
  getPRs: vi.fn(),
}));
vi.mock("../../src/connectors/notion.js", () => ({
  searchPages: vi.fn(),
}));
vi.mock("../../src/connectors/linear.js", () => ({
  getIssues: vi.fn(),
}));

import { getPRs } from "../../src/connectors/github.js";
import { searchPages } from "../../src/connectors/notion.js";
import { getIssues } from "../../src/connectors/linear.js";

const mockPRs = vi.mocked(getPRs);
const mockPages = vi.mocked(searchPages);
const mockIssues = vi.mocked(getIssues);

describe("projectStatusRollup", () => {
  it("returns data from all three sources when all succeed", async () => {
    mockPRs.mockResolvedValueOnce({ data: { prs: [{ number: 1, title: "PR", url: "", state: "open", author: "a", labels: [], created_at: "" }] } });
    mockPages.mockResolvedValueOnce({ data: { pages: [{ id: "p1", title: "Doc", url: "", last_edited: "" }] } });
    mockIssues.mockResolvedValueOnce({ data: { issues: [{ id: "i1", title: "Issue", url: "", state: "Todo", priority: 0, team: "Eng" }] } });

    const result = await projectStatusRollup("auth", "org", "repo");

    expect(result._partial).toBeUndefined();
    expect(result._missing).toBeUndefined();
    expect(result.github).toMatchObject({ data: { prs: expect.any(Array) } });
    expect(result.notion).toMatchObject({ data: { pages: expect.any(Array) } });
    expect(result.linear).toMatchObject({ data: { issues: expect.any(Array) } });
  });

  it("marks _partial and _missing when one source is degraded", async () => {
    mockPRs.mockResolvedValueOnce({ data: { prs: [] } });
    mockPages.mockResolvedValueOnce({ degraded: true, reason: "timeout" });
    mockIssues.mockResolvedValueOnce({ data: { issues: [] } });

    const result = await projectStatusRollup("auth", "org", "repo");

    expect(result._partial).toBe(true);
    expect(result._missing).toEqual(["notion"]);
  });

  it("marks all three as missing when all fail", async () => {
    mockPRs.mockResolvedValueOnce({ degraded: true, reason: "unavailable" });
    mockPages.mockResolvedValueOnce({ degraded: true, reason: "auth_failed" });
    mockIssues.mockResolvedValueOnce({ degraded: true, reason: "graphql_error", message: "err" });

    const result = await projectStatusRollup("auth", "org", "repo");

    expect(result._partial).toBe(true);
    expect(result._missing).toEqual(["github", "notion", "linear"]);
  });

  it("handles a rejected promise from one connector gracefully", async () => {
    mockPRs.mockRejectedValueOnce(new Error("unexpected crash"));
    mockPages.mockResolvedValueOnce({ data: { pages: [] } });
    mockIssues.mockResolvedValueOnce({ data: { issues: [] } });

    const result = await projectStatusRollup("auth", "org", "repo");

    expect(result._partial).toBe(true);
    expect(result._missing).toContain("github");
  });
});
