export type Permission =
  | "read:github"
  | "read:notion"
  | "read:linear"
  | "write:linear";

export interface DegradedResult {
  degraded: true;
  reason:
    | "rate_limited"
    | "auth_failed"
    | "not_found"
    | "timeout"
    | "graphql_error"
    | "unavailable";
  retry_after?: number;
  message?: string;
}

export interface SourceSuccess<T> {
  degraded?: false;
  data: T;
}

export type SourceResult<T> = DegradedResult | SourceSuccess<T>;

export interface GitHubPR {
  number: number;
  title: string;
  url: string;
  state: string;
  author: string;
  labels: string[];
  created_at: string;
}

export interface GitHubIssue {
  number: number;
  title: string;
  url: string;
  state: string;
  body: string;
  labels: string[];
}

export interface NotionPage {
  id: string;
  title: string;
  url: string;
  last_edited: string;
}

export interface LinearIssue {
  id: string;
  title: string;
  url: string;
  state: string;
  priority: number;
  team: string;
}

export interface RollupResult {
  github: SourceResult<{ prs: GitHubPR[] }> | null;
  notion: SourceResult<{ pages: NotionPage[] }> | null;
  linear: SourceResult<{ issues: LinearIssue[] }> | null;
  _partial?: boolean;
  _missing?: string[];
}
