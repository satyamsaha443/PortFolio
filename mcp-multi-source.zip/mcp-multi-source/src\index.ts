import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import { z } from "zod";
import { config } from "dotenv";
import { checkPermission, PermissionDeniedError } from "./access-control.js";
import * as github from "./connectors/github.js";
import * as notion from "./connectors/notion.js";
import * as linear from "./connectors/linear.js";
import { projectStatusRollup } from "./tools/status-rollup.js";

config();

const ROLE = process.env.MCP_ROLE ?? "readonly";
const DEFAULT_OWNER = process.env.GITHUB_DEFAULT_OWNER ?? "";
const DEFAULT_REPO = process.env.GITHUB_DEFAULT_REPO ?? "";
const DEFAULT_TEAM = process.env.LINEAR_DEFAULT_TEAM;

const server = new McpServer({ name: "mcp-multi-source", version: "1.0.0" });

function denied(err: unknown): { content: Array<{ type: "text"; text: string }> } {
  if (err instanceof PermissionDeniedError) {
    return { content: [{ type: "text", text: `Permission denied: ${err.message}` }] };
  }
  throw err;
}

// ── GitHub ──────────────────────────────────────────────────────────────────

server.tool(
  "github_get_prs",
  "List open pull requests for a repository",
  {
    owner: z.string().optional().describe("GitHub org or user (defaults to GITHUB_DEFAULT_OWNER)"),
    repo: z.string().optional().describe("Repository name (defaults to GITHUB_DEFAULT_REPO)"),
    label: z.string().optional().describe("Filter by label name"),
    branch: z.string().optional().describe("Filter by head branch name"),
  },
  async ({ owner, repo, label, branch }) => {
    try { checkPermission("github_get_prs", ["read:github"], ROLE); } catch (e) { return denied(e); }
    const result = await github.getPRs(owner ?? DEFAULT_OWNER, repo ?? DEFAULT_REPO, label, branch);
    return { content: [{ type: "text", text: JSON.stringify(result, null, 2) }] };
  }
);

server.tool(
  "github_get_issue",
  "Fetch a GitHub issue by number",
  {
    issue_number: z.number().int().positive().describe("Issue number"),
    owner: z.string().optional(),
    repo: z.string().optional(),
  },
  async ({ issue_number, owner, repo }) => {
    try { checkPermission("github_get_issue", ["read:github"], ROLE); } catch (e) { return denied(e); }
    const result = await github.getIssue(owner ?? DEFAULT_OWNER, repo ?? DEFAULT_REPO, issue_number);
    return { content: [{ type: "text", text: JSON.stringify(result, null, 2) }] };
  }
);

server.tool(
  "github_search_code",
  "Search code in a GitHub repository by keyword",
  {
    query: z.string().describe("Search keyword"),
    owner: z.string().optional(),
    repo: z.string().optional(),
  },
  async ({ query, owner, repo }) => {
    try { checkPermission("github_search_code", ["read:github"], ROLE); } catch (e) { return denied(e); }
    const result = await github.searchCode(owner ?? DEFAULT_OWNER, repo ?? DEFAULT_REPO, query);
    return { content: [{ type: "text", text: JSON.stringify(result, null, 2) }] };
  }
);

// ── Notion ───────────────────────────────────────────────────────────────────

server.tool(
  "notion_search_pages",
  "Full-text search across a Notion workspace",
  { query: z.string().describe("Search query") },
  async ({ query }) => {
    try { checkPermission("notion_search_pages", ["read:notion"], ROLE); } catch (e) { return denied(e); }
    const result = await notion.searchPages(query);
    return { content: [{ type: "text", text: JSON.stringify(result, null, 2) }] };
  }
);

server.tool(
  "notion_get_page",
  "Fetch a Notion page by its page ID (UUID format)",
  { page_id: z.string().describe("Notion page ID") },
  async ({ page_id }) => {
    try { checkPermission("notion_get_page", ["read:notion"], ROLE); } catch (e) { return denied(e); }
    const result = await notion.getPage(page_id);
    return { content: [{ type: "text", text: JSON.stringify(result, null, 2) }] };
  }
);

server.tool(
  "notion_get_database",
  "Query a Notion database with optional filters",
  {
    database_id: z.string().describe("Notion database ID"),
    filter: z.record(z.unknown()).optional().describe("Notion filter object (see Notion API docs)"),
  },
  async ({ database_id, filter }) => {
    try { checkPermission("notion_get_database", ["read:notion"], ROLE); } catch (e) { return denied(e); }
    const result = await notion.getDatabase(database_id, filter);
    return { content: [{ type: "text", text: JSON.stringify(result, null, 2) }] };
  }
);

// ── Linear ───────────────────────────────────────────────────────────────────

server.tool(
  "linear_get_issues",
  "List Linear issues filtered by team and/or status",
  {
    team_key: z.string().optional().describe("Linear team key (e.g. ENG)"),
    status: z.string().optional().describe("Issue status name (e.g. 'In Progress', 'Todo')"),
  },
  async ({ team_key, status }) => {
    try { checkPermission("linear_get_issues", ["read:linear"], ROLE); } catch (e) { return denied(e); }
    const result = await linear.getIssues(team_key, status);
    return { content: [{ type: "text", text: JSON.stringify(result, null, 2) }] };
  }
);

server.tool(
  "linear_get_issue",
  "Fetch a single Linear issue by its ID",
  { issue_id: z.string().describe("Linear issue ID") },
  async ({ issue_id }) => {
    try { checkPermission("linear_get_issue", ["read:linear"], ROLE); } catch (e) { return denied(e); }
    const result = await linear.getIssue(issue_id);
    return { content: [{ type: "text", text: JSON.stringify(result, null, 2) }] };
  }
);

server.tool(
  "linear_create_issue",
  "Create a new Linear issue (requires write:linear permission)",
  {
    title: z.string().describe("Issue title"),
    team_id: z.string().describe("Linear team ID"),
    description: z.string().optional().describe("Issue description (markdown)"),
  },
  async ({ title, team_id, description }) => {
    try { checkPermission("linear_create_issue", ["write:linear"], ROLE); } catch (e) { return denied(e); }
    const result = await linear.createIssue(title, team_id, description);
    return { content: [{ type: "text", text: JSON.stringify(result, null, 2) }] };
  }
);

// ── Composite ────────────────────────────────────────────────────────────────

server.tool(
  "project_status_rollup",
  "Get a unified status report across GitHub PRs, Notion docs, and Linear tickets for a project keyword",
  {
    project: z.string().describe("Project name or keyword to search across all three sources"),
    owner: z.string().optional().describe("GitHub owner (defaults to GITHUB_DEFAULT_OWNER)"),
    repo: z.string().optional().describe("GitHub repo (defaults to GITHUB_DEFAULT_REPO)"),
    linear_team: z.string().optional().describe("Linear team key (defaults to LINEAR_DEFAULT_TEAM)"),
  },
  async ({ project, owner, repo, linear_team }) => {
    try {
      checkPermission("project_status_rollup", ["read:github", "read:notion", "read:linear"], ROLE);
    } catch (e) {
      return denied(e);
    }
    const result = await projectStatusRollup(
      project,
      owner ?? DEFAULT_OWNER,
      repo ?? DEFAULT_REPO,
      linear_team ?? DEFAULT_TEAM
    );
    return { content: [{ type: "text", text: JSON.stringify(result, null, 2) }] };
  }
);

// ── Start ─────────────────────────────────────────────────────────────────────

async function main() {
  if (!process.env.GITHUB_TOKEN) {
    console.error("Warning: GITHUB_TOKEN is not set — GitHub tools will return auth_failed");
  }
  if (!process.env.NOTION_TOKEN) {
    console.error("Warning: NOTION_TOKEN is not set — Notion tools will return auth_failed");
  }
  if (!process.env.LINEAR_API_KEY) {
    console.error("Warning: LINEAR_API_KEY is not set — Linear tools will return auth_failed");
  }
  const transport = new StdioServerTransport();
  await server.connect(transport);
  console.error(`mcp-multi-source running (role: ${ROLE})`);
}

main().catch((err) => {
  console.error("Fatal error:", err);
  process.exit(1);
});
