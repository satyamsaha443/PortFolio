# MCP Multi-Source Server

A [Model Context Protocol](https://modelcontextprotocol.io) server that connects Claude to **GitHub**, **Notion**, and **Linear** simultaneously. Ask Claude a single question and it synthesises an answer from all three sources.

## What it does

**Primary use case — project status rollup:**
> "What's the state of the `auth-refactor` feature?"

Claude calls `project_status_rollup("auth-refactor")` and the server:
1. Fetches open PRs from GitHub filtered by the keyword
2. Searches Notion for matching pages (design docs, specs, notes)
3. Queries Linear for linked issues

All three requests fire in parallel. The response is a merged JSON object. If one source is unavailable, the other two still return — the response is flagged `_partial: true` with a `_missing` list.

## Why these three sources

| Source | Role | Why it matters |
|--------|------|----------------|
| GitHub | Structured code/project data | Open PRs, issues, code search |
| Notion | Unstructured knowledge | Design docs, meeting notes, specs |
| Linear | Action-capable ticketing | Issue state, create new tickets |

This triad covers the three categories that appear in every enterprise AI deployment: a structured data source, an unstructured knowledge store, and an action-capable system. The server demonstrates how to wire all three behind a single interface.

## Architecture

```
Claude Desktop / Claude CLI
        │
        │  MCP (stdio)
        ▼
┌─────────────────────────────┐
│     mcp-multi-source        │
│                             │
│  ┌─────────────────────┐   │
│  │   Access Control    │   │
│  │  (roles.json + env) │   │
│  └──────────┬──────────┘   │
│             │               │
│    Promise.allSettled()     │
│    ┌────────┼────────┐      │
│    ▼        ▼        ▼      │
│  GitHub  Notion   Linear    │
│  REST    REST     GraphQL   │
└─────────────────────────────┘
```

## Authentication

Each source uses a long-lived API token. Set them in `.env` (copied from `.env.example`):

| Variable | How to obtain | Minimum required scope |
|----------|--------------|----------------------|
| `GITHUB_TOKEN` | [github.com/settings/tokens](https://github.com/settings/tokens) → Fine-grained PAT | Contents: read, Pull Requests: read, Issues: read |
| `NOTION_TOKEN` | [notion.so/my-integrations](https://www.notion.so/my-integrations) → New integration | Read content; share pages with the integration |
| `LINEAR_API_KEY` | [linear.app/settings/api](https://linear.app/settings/api) → Personal API keys | Read access (write only needed for `linear_create_issue`) |

Tokens are read from environment variables at startup. **Never commit `.env`** — only `.env.example` (with placeholder values) ships in the repo.

## Access control

The server role is set via `MCP_ROLE` in `.env`. Each tool has a required permission; if the role doesn't have it, the server returns a `PermissionDenied` error without making any network request.

**`config/roles.json`:**
```json
{
  "readonly":  ["read:github", "read:notion", "read:linear"],
  "developer": ["read:github", "read:notion", "read:linear", "write:linear"],
  "admin":     ["read:github", "read:notion", "read:linear", "write:linear"]
}
```

To add a new role: add an entry to `roles.json`. To deploy a read-only instance: set `MCP_ROLE=readonly`. To allow ticket creation: set `MCP_ROLE=developer`.

## What happens when a source is unavailable

Each connector has a 5-second timeout and handles failures independently. The server never crashes because one source is slow or down.

| Scenario | Response |
|----------|----------|
| GitHub rate limited | `{ degraded: true, reason: "rate_limited", retry_after: N }` |
| Notion timeout | `{ degraded: true, reason: "timeout" }` |
| Linear GraphQL error | `{ degraded: true, reason: "graphql_error", message: "..." }` |
| Any source unreachable | `{ degraded: true, reason: "unavailable" }` |

For `project_status_rollup`, partial results are valid:
```json
{
  "github": { "data": { "prs": [...] } },
  "notion": { "degraded": true, "reason": "timeout" },
  "linear": { "data": { "issues": [...] } },
  "_partial": true,
  "_missing": ["notion"]
}
```

## Running locally

```bash
# 1. Install dependencies
npm install

# 2. Configure environment
cp .env.example .env
# Fill in your tokens in .env

# 3. Build
npm run build

# 4. Start
npm start
```

The server communicates over stdio — it's intended to be launched by a MCP host (Claude Desktop, Claude CLI), not run as a standalone HTTP server.

## Running tests

```bash
npm test
```

Tests mock all HTTP calls using `vi.stubGlobal("fetch", ...)` — no real API credentials needed to run the test suite.

## Connecting to Claude Desktop

Add this to your `claude_desktop_config.json` (usually at `~/Library/Application Support/Claude/claude_desktop_config.json` on macOS):

```json
{
  "mcpServers": {
    "multi-source": {
      "command": "node",
      "args": ["/absolute/path/to/projects/mcp-multi-source/dist/index.js"],
      "env": {
        "GITHUB_TOKEN": "ghp_...",
        "GITHUB_DEFAULT_OWNER": "your-org",
        "GITHUB_DEFAULT_REPO": "your-repo",
        "NOTION_TOKEN": "secret_...",
        "LINEAR_API_KEY": "lin_api_...",
        "LINEAR_DEFAULT_TEAM": "ENG",
        "MCP_ROLE": "readonly"
      }
    }
  }
}
```

Restart Claude Desktop after saving. The 10 tools will appear in Claude's tool list.
