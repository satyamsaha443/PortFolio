# Setup Guide — Mac (End to End)

This guide takes you from a fresh Mac to Claude answering questions across GitHub, Notion, and Linear in one message.

**Time required:** ~20–30 minutes (most of it is creating API tokens)

---

## Part 1 — Install Prerequisites

### Node.js 20+

The server requires Node 20 or higher (it uses native `fetch` built into Node 20).

**Check if you already have it:**
```bash
node --version
```
If you see `v20.x.x` or higher, skip to Part 2.

**Install via Homebrew (recommended):**
```bash
# Install Homebrew if you don't have it
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"

# Install Node
brew install node
```

**Or download directly:**
Go to [nodejs.org](https://nodejs.org) → download the LTS installer → run it.

Verify after installing:
```bash
node --version   # should say v20.x.x or higher
npm --version    # should say 10.x.x or higher
```

---

## Part 2 — Get the Project

Unzip `mcp-multi-source.zip` anywhere you want. A good location is your home folder or Documents:

```bash
cd ~/Documents
unzip ~/Downloads/mcp-multi-source.zip
cd mcp-multi-source
```

---

## Part 3 — Create Your API Tokens

You need one token from each service. This is the most time-consuming part — do them in order.

---

### Token 1 — GitHub

1. Go to [github.com/settings/tokens](https://github.com/settings/tokens)
2. Click **"Fine-grained tokens"** → **"Generate new token"**
3. Give it a name like `mcp-multi-source`
4. Set expiration to whatever you prefer (90 days is fine)
5. Under **"Repository access"** — choose either:
   - **"All repositories"** (simpler), or
   - **"Only select repositories"** → pick the repos you want Claude to see
6. Under **"Permissions"** → **"Repository permissions"**, set these to **Read-only**:
   - Contents
   - Issues
   - Metadata
   - Pull requests
7. Click **"Generate token"**
8. **Copy the token immediately** — it starts with `ghp_` — you won't see it again

---

### Token 2 — Notion

**Step A — Create an integration:**
1. Go to [notion.so/my-integrations](https://www.notion.so/my-integrations)
2. Click **"+ New integration"**
3. Name it `mcp-multi-source`
4. Leave capabilities as default (Read content is enough; toggle off Insert/Update/Delete if you want read-only)
5. Click **"Submit"**
6. On the next page, click **"Show"** next to "Internal Integration Secret"
7. Copy the token — it starts with `secret_`

**Step B — Share your pages with the integration:**

The integration can only read pages you explicitly share with it. For each Notion page or database you want Claude to access:

1. Open the page in Notion
2. Click **"Share"** in the top-right corner
3. Click **"Invite"**
4. Search for and select your integration name (`mcp-multi-source`)
5. Click **"Invite"**

> **Tip:** Share a top-level page to give access to everything under it.

---

### Token 3 — Linear

1. Go to [linear.app](https://linear.app) → bottom-left avatar → **Settings**
2. Click **"API"** in the left sidebar
3. Under **"Personal API keys"**, click **"Create key"**
4. Name it `mcp-multi-source`
5. Copy the key — it starts with `lin_api_`

**Find your team key** (you'll need this for `LINEAR_DEFAULT_TEAM`):
- In Linear, go to your team's page
- The team key is the short code shown in issue IDs — e.g. if issues are `ENG-123`, your team key is `ENG`

---

## Part 4 — Configure the Project

### Create your `.env` file

```bash
cd ~/Documents/mcp-multi-source   # wherever you unzipped
cp .env.example .env
```

Open `.env` in any text editor (TextEdit, VS Code, nano):

```bash
open -e .env   # opens in TextEdit
# or
code .env      # opens in VS Code if you have it
```

Fill in your real values:

```env
# GitHub
GITHUB_TOKEN=ghp_xxxxxxxxxxxxxxxxxxxx        # your token from Part 3
GITHUB_DEFAULT_OWNER=your-org-or-username    # e.g. octocat or your-company
GITHUB_DEFAULT_REPO=your-main-repo           # e.g. backend or monorepo

# Notion
NOTION_TOKEN=secret_xxxxxxxxxxxxxxxxxxxx     # your integration secret from Part 3

# Linear
LINEAR_API_KEY=lin_api_xxxxxxxxxxxxxxxxxxxx  # your API key from Part 3
LINEAR_DEFAULT_TEAM=ENG                      # your team key (e.g. ENG, PRODUCT, DEV)

# Access control — leave as readonly to start
MCP_ROLE=readonly
```

Save and close the file.

---

## Part 5 — Build and Test

### Install dependencies

```bash
cd ~/Documents/mcp-multi-source
npm install
```

This downloads the required packages. It takes 30–60 seconds. You'll see a `node_modules/` folder appear.

### Build

```bash
npm run build
```

This compiles the TypeScript to JavaScript. You'll see a `dist/` folder appear. If you see any errors here, check that Node is version 20+.

### Verify the server starts

```bash
echo '{"jsonrpc":"2.0","id":1,"method":"tools/list","params":{}}' | node dist/index.js
```

You should see a JSON response listing all 10 tools:
- `github_get_prs`, `github_get_issue`, `github_search_code`
- `notion_search_pages`, `notion_get_page`, `notion_get_database`
- `linear_get_issues`, `linear_get_issue`, `linear_create_issue`
- `project_status_rollup`

The server also logs warnings for any token you forgot to set — check for those.

### Run the tests (optional — no tokens needed)

```bash
npm test
```

All 35 tests should pass. Tests use mocked HTTP calls, so they don't need real API credentials.

---

## Part 6 — Connect to Claude Desktop

### Install Claude Desktop

Download from [claude.ai/download](https://claude.ai/download) → macOS → install and sign in.

### Find the config file

The config file is at:
```
~/Library/Application Support/Claude/claude_desktop_config.json
```

The `Library` folder is hidden by default. Open it in Terminal:
```bash
open ~/Library/Application\ Support/Claude/
```

If `claude_desktop_config.json` doesn't exist yet, create it.

### Edit the config

Open the config file:
```bash
open -e ~/Library/Application\ Support/Claude/claude_desktop_config.json
```

Add the MCP server entry. Replace the path and tokens with your actual values:

```json
{
  "mcpServers": {
    "multi-source": {
      "command": "node",
      "args": ["/Users/YOUR_USERNAME/Documents/mcp-multi-source/dist/index.js"],
      "env": {
        "GITHUB_TOKEN": "ghp_your_actual_token_here",
        "GITHUB_DEFAULT_OWNER": "your-org-or-username",
        "GITHUB_DEFAULT_REPO": "your-main-repo",
        "NOTION_TOKEN": "secret_your_actual_token_here",
        "LINEAR_API_KEY": "lin_api_your_actual_key_here",
        "LINEAR_DEFAULT_TEAM": "ENG",
        "MCP_ROLE": "readonly"
      }
    }
  }
}
```

> **Get your exact path:** Run `pwd` inside the `mcp-multi-source` directory and append `/dist/index.js`
> ```bash
> cd ~/Documents/mcp-multi-source && echo "$(pwd)/dist/index.js"
> ```
> Copy that output and paste it into the `args` field above.

If you already have other MCP servers in the config, add the `"multi-source"` block inside the existing `"mcpServers"` object — don't replace everything.

Save the file.

### Restart Claude Desktop

Fully quit Claude Desktop (Cmd+Q — don't just close the window) and reopen it.

### Verify it's connected

In a new Claude chat, click the **tools icon (🔧)** near the bottom of the input box. You should see the 10 tools listed under "multi-source". If you don't see the icon, the server didn't connect — see Troubleshooting below.

---

## Part 7 — Use It

Try these example prompts:

**Status rollup (uses all 3 sources in parallel):**
> "What's the state of the auth feature? Check GitHub PRs, Notion docs, and Linear tickets."

**Single source:**
> "Show me all open pull requests in the repo"
> "Search Notion for our API design documents"
> "List all In Progress tickets in the ENG team on Linear"

**Create a ticket:**
> "Create a Linear ticket titled 'Fix rate limiting on the auth endpoint' in team ENG"
> (Only works if `MCP_ROLE=developer` or `admin` in your config)

---

## Troubleshooting

### Tools don't appear in Claude Desktop

1. Make sure you fully quit (Cmd+Q) and reopened Claude Desktop
2. Check JSON syntax in the config file — one missing comma breaks it. Validate at [jsonlint.com](https://jsonlint.com)
3. Verify the path in `args` is correct: `ls /Users/YOUR_USERNAME/Documents/mcp-multi-source/dist/index.js` should return the file
4. Check Claude Desktop logs: `~/Library/Logs/Claude/`

### "Cannot find module" error

You forgot to build. Run `npm run build` again.

### GitHub returns auth_failed

Your token is missing scopes. Go back to [github.com/settings/tokens](https://github.com/settings/tokens), find your token, edit it, and make sure Contents, Issues, Metadata, and Pull Requests are all set to Read-only.

### Notion returns auth_failed or empty results

You created the integration token but forgot to share pages with it. Go to each Notion page → Share → Invite → select your integration.

### Linear returns auth_failed

Double-check the API key. It should start with `lin_api_`. Make sure there are no extra spaces when you copy-paste it.

### Server starts but returns wrong data

Check `GITHUB_DEFAULT_OWNER` and `GITHUB_DEFAULT_REPO` — these must exactly match your GitHub org/user and repo names (case-sensitive).

### Want to allow creating Linear tickets

Change `MCP_ROLE=readonly` to `MCP_ROLE=developer` in the Claude Desktop config, then restart Claude Desktop.

---

## Updating the server

If you get a newer version of the zip:

```bash
cd ~/Documents/mcp-multi-source
npm install          # pick up any new dependencies
npm run build        # recompile
```

Then restart Claude Desktop (Cmd+Q and reopen).
