import { describe, it, expect, vi, beforeEach } from "vitest";
import { getIssues, getIssue, createIssue } from "../../src/connectors/linear.js";

const mockFetch = vi.fn();
beforeEach(() => {
  vi.stubGlobal("fetch", mockFetch);
  mockFetch.mockReset();
  process.env.LINEAR_API_KEY = "lin_api_test";
});

function mockResponse(status: number, body: unknown) {
  return Promise.resolve({
    status,
    ok: status >= 200 && status < 300,
    json: () => Promise.resolve(body),
  });
}

const linearIssueNode = {
  id: "issue-abc",
  title: "Fix login bug",
  url: "https://linear.app/team/issue/issue-abc",
  priority: 1,
  state: { name: "In Progress" },
  team: { name: "Engineering" },
};

describe("getIssues", () => {
  it("returns mapped issues on success", async () => {
    mockFetch.mockReturnValueOnce(
      mockResponse(200, { data: { issues: { nodes: [linearIssueNode] } } })
    );
    const result = await getIssues();
    expect(result).toEqual({
      data: {
        issues: [
          {
            id: "issue-abc",
            title: "Fix login bug",
            url: "https://linear.app/team/issue/issue-abc",
            state: "In Progress",
            priority: 1,
            team: "Engineering",
          },
        ],
      },
    });
  });

  it("returns graphql_error when response contains errors", async () => {
    mockFetch.mockReturnValueOnce(
      mockResponse(200, { errors: [{ message: "Unauthorized" }] })
    );
    const result = await getIssues();
    expect(result).toEqual({
      degraded: true,
      reason: "graphql_error",
      message: "Unauthorized",
    });
  });

  it("returns auth_failed on 401", async () => {
    mockFetch.mockReturnValueOnce(mockResponse(401, {}));
    const result = await getIssues();
    expect(result).toEqual({ degraded: true, reason: "auth_failed" });
  });

  it("returns timeout on AbortError", async () => {
    mockFetch.mockRejectedValueOnce(Object.assign(new Error("aborted"), { name: "AbortError" }));
    const result = await getIssues();
    expect(result).toEqual({ degraded: true, reason: "timeout" });
  });

  it("passes teamKey as a GraphQL variable, not inline string", async () => {
    mockFetch.mockReturnValueOnce(
      mockResponse(200, { data: { issues: { nodes: [] } } })
    );
    await getIssues('team-key');
    const body = JSON.parse(mockFetch.mock.calls[0][1].body);
    // Variables object should contain teamKey, not be interpolated into query string
    expect(body.variables).toBeDefined();
    expect(body.variables.teamKey).toBe('team-key');
    // Query should NOT contain the literal teamKey value
    expect(body.query).not.toContain('"team-key"');
  });
});

describe("getIssue", () => {
  it("returns mapped issue on success", async () => {
    mockFetch.mockReturnValueOnce(
      mockResponse(200, { data: { issue: linearIssueNode } })
    );
    const result = await getIssue("issue-abc");
    expect(result).toEqual({
      data: {
        issue: {
          id: "issue-abc",
          title: "Fix login bug",
          url: "https://linear.app/team/issue/issue-abc",
          state: "In Progress",
          priority: 1,
          team: "Engineering",
        },
      },
    });
  });

  it("returns not_found when issue is null", async () => {
    mockFetch.mockReturnValueOnce(mockResponse(200, { data: { issue: null } }));
    const result = await getIssue("bad-id");
    expect(result).toEqual({ degraded: true, reason: "not_found" });
  });
});

describe("createIssue", () => {
  it("returns created issue id and url", async () => {
    mockFetch.mockReturnValueOnce(
      mockResponse(200, {
        data: { issueCreate: { issue: { id: "new-id", url: "https://linear.app/issue/new-id" } } },
      })
    );
    const result = await createIssue("New bug", "team-id", "Details here");
    expect(result).toEqual({
      data: { issue: { id: "new-id", url: "https://linear.app/issue/new-id" } },
    });
  });
});
