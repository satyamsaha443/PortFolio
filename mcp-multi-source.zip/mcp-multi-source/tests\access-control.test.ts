import { describe, it, expect, vi, beforeEach } from "vitest";
import { checkPermission, getPermissionsForRole, PermissionDeniedError } from "../src/access-control.js";

// Mock fs to avoid reading actual config/roles.json in tests
vi.mock("fs", () => ({
  readFileSync: vi.fn(() =>
    JSON.stringify({
      readonly:  ["read:github", "read:notion", "read:linear"],
      developer: ["read:github", "read:notion", "read:linear", "write:linear"],
    })
  ),
}));

describe("getPermissionsForRole", () => {
  it("returns permissions for a known role", () => {
    const perms = getPermissionsForRole("readonly");
    expect(perms).toContain("read:github");
    expect(perms).toContain("read:notion");
    expect(perms).toContain("read:linear");
  });

  it("returns empty array for unknown role", () => {
    const perms = getPermissionsForRole("unknown-role");
    expect(perms).toEqual([]);
  });
});

describe("checkPermission", () => {
  it("does not throw when role has the required permission", () => {
    expect(() =>
      checkPermission("github_get_prs", ["read:github"], "readonly")
    ).not.toThrow();
  });

  it("throws PermissionDeniedError when role lacks permission", () => {
    expect(() =>
      checkPermission("linear_create_issue", ["write:linear"], "readonly")
    ).toThrow(PermissionDeniedError);
  });

  it("throws with a descriptive message naming the tool and permission", () => {
    expect(() =>
      checkPermission("linear_create_issue", ["write:linear"], "readonly")
    ).toThrow("linear_create_issue");
  });

  it("passes for developer role with write:linear", () => {
    expect(() =>
      checkPermission("linear_create_issue", ["write:linear"], "developer")
    ).not.toThrow();
  });

  it("throws on first missing permission when multiple required", () => {
    expect(() =>
      checkPermission("project_status_rollup", ["read:github", "write:linear"], "readonly")
    ).toThrow(PermissionDeniedError);
  });
});
