import type { NotionPage, SourceResult } from "../types.js";

const BASE = "https://api.notion.com/v1";
const NOTION_VERSION = "2022-06-28";
const TIMEOUT_MS = 5000;

function authHeaders(): Record<string, string> {
  return {
    Authorization: `Bearer ${process.env.NOTION_TOKEN}`,
    "Notion-Version": NOTION_VERSION,
    "Content-Type": "application/json",
  };
}

async function notionFetch(url: string, init: RequestInit = {}): Promise<Response> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), TIMEOUT_MS);
  try {
    return await fetch(url, { ...init, headers: authHeaders(), signal: controller.signal });
  } finally {
    clearTimeout(timer);
  }
}

function extractTitle(page: Record<string, unknown>): string {
  const props = page.properties as Record<string, unknown> | undefined;
  if (!props) return "Untitled";
  for (const prop of Object.values(props)) {
    const p = prop as Record<string, unknown>;
    if (p.type === "title") {
      const titles = p.title as Array<{ plain_text: string }>;
      return titles?.[0]?.plain_text ?? "Untitled";
    }
  }
  return "Untitled";
}

function mapPage(p: Record<string, unknown>): NotionPage {
  return {
    id: p.id as string,
    title: extractTitle(p),
    url: p.url as string,
    last_edited: p.last_edited_time as string,
  };
}

export async function searchPages(
  query: string
): Promise<SourceResult<{ pages: NotionPage[] }>> {
  try {
    const res = await notionFetch(`${BASE}/search`, {
      method: "POST",
      body: JSON.stringify({
        query,
        filter: { property: "object", value: "page" },
        page_size: 10,
      }),
    });
    if (res.status === 401) return { degraded: true, reason: "auth_failed" };
    if (res.status === 404) return { degraded: true, reason: "not_found" };
    if (!res.ok) return { degraded: true, reason: "unavailable" };
    const json = (await res.json()) as { results: Record<string, unknown>[] };
    return { data: { pages: json.results.map(mapPage) } };
  } catch (err: unknown) {
    if (err instanceof Error && err.name === "AbortError") {
      return { degraded: true, reason: "timeout" };
    }
    return { degraded: true, reason: "unavailable" };
  }
}

export async function getPage(
  pageId: string
): Promise<SourceResult<{ page: NotionPage }>> {
  try {
    const res = await notionFetch(`${BASE}/pages/${pageId}`);
    if (res.status === 401) return { degraded: true, reason: "auth_failed" };
    if (res.status === 404) return { degraded: true, reason: "not_found" };
    if (!res.ok) return { degraded: true, reason: "unavailable" };
    const p = (await res.json()) as Record<string, unknown>;
    return { data: { page: mapPage(p) } };
  } catch (err: unknown) {
    if (err instanceof Error && err.name === "AbortError") {
      return { degraded: true, reason: "timeout" };
    }
    return { degraded: true, reason: "unavailable" };
  }
}

export async function getDatabase(
  databaseId: string,
  filter?: Record<string, unknown>
): Promise<SourceResult<{ results: unknown[] }>> {
  try {
    const body: Record<string, unknown> = { page_size: 20 };
    if (filter) body.filter = filter;
    const res = await notionFetch(`${BASE}/databases/${databaseId}/query`, {
      method: "POST",
      body: JSON.stringify(body),
    });
    if (res.status === 401) return { degraded: true, reason: "auth_failed" };
    if (res.status === 404) return { degraded: true, reason: "not_found" };
    if (!res.ok) return { degraded: true, reason: "unavailable" };
    const json = (await res.json()) as { results: unknown[] };
    return { data: { results: json.results } };
  } catch (err: unknown) {
    if (err instanceof Error && err.name === "AbortError") {
      return { degraded: true, reason: "timeout" };
    }
    return { degraded: true, reason: "unavailable" };
  }
}
