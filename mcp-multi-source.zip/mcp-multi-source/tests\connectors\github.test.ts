import { describe, it, expect, vi, beforeEach } from "vitest";
import { getPRs, getIssue, searchCode } from "../../src/connectors/github.js";

const mockFetch = vi.fn();
beforeEach(() => {
  vi.stubGlobal("fetch", mockFetch);
  mockFetch.mockReset();
  process.env.GITHUB_TOKEN = "test-token";
});

function mockResponse(status: number, body: unknown, headers: Record<string, string> = {}) {
  return Promise.resolve({
    status,
    ok: status >= 200 && status < 300,
    json: () => Promise.resolve(body),
    headers: { get: (key: string) => headers[key] ?? null },
  });
}

describe("getPRs", () => {
  it("returns mapped PRs on 200", async () => {
    mockFetch.mockReturnValueOnce(
      mockResponse(200, [
        {
          number: 42,
          title: "Add auth",
          html_url: "https://github.com/org/repo/pull/42",
          state: "open",
          user: { login: "alice" },
          labels: [{ name: "feature" }],
          created_at: "2024-01-01T00:00:00Z",
        },
      ])
    );
    const result = await getPRs("org", "repo");
    expect(result).toEqual({
      data: {
        prs: [
          {
            number: 42,
            title: "Add auth",
            url: "https://github.com/org/repo/pull/42",
            state: "open",
            author: "alice",
            labels: ["feature"],
            created_at: "2024-01-01T00:00:00Z",
          },
        ],
      },
    });
  });

  it("returns rate_limited on 429", async () => {
    mockFetch.mockReturnValueOnce(mockResponse(429, {}, { "retry-after": "30" }));
    const result = await getPRs("org", "repo");
    expect(result).toEqual({ degraded: true, reason: "rate_limited", retry_after: 30 });
  });

  it("returns auth_failed on 401", async () => {
    mockFetch.mockReturnValueOnce(mockResponse(401, {}));
    const result = await getPRs("org", "repo");
    expect(result).toMatchObject({ degraded: true, reason: "auth_failed" });
  });

  it("returns timeout when fetch is aborted", async () => {
    mockFetch.mockRejectedValueOnce(Object.assign(new Error("aborted"), { name: "AbortError" }));
    const result = await getPRs("org", "repo");
    expect(result).toEqual({ degraded: true, reason: "timeout" });
  });

  it("returns unavailable on network error", async () => {
    mockFetch.mockRejectedValueOnce(new Error("ECONNREFUSED"));
    const result = await getPRs("org", "repo");
    expect(result).toEqual({ degraded: true, reason: "unavailable" });
  });
});

describe("getIssue", () => {
  it("returns mapped issue on 200", async () => {
    mockFetch.mockReturnValueOnce(
      mockResponse(200, {
        number: 7,
        title: "Bug in auth",
        html_url: "https://github.com/org/repo/issues/7",
        state: "open",
        body: "It crashes",
        labels: [{ name: "bug" }],
      })
    );
    const result = await getIssue("org", "repo", 7);
    expect(result).toEqual({
      data: {
        issue: {
          number: 7,
          title: "Bug in auth",
          url: "https://github.com/org/repo/issues/7",
          state: "open",
          body: "It crashes",
          labels: ["bug"],
        },
      },
    });
  });

  it("returns not_found on 404", async () => {
    mockFetch.mockReturnValueOnce(mockResponse(404, {}));
    const result = await getIssue("org", "repo", 999);
    expect(result).toEqual({ degraded: true, reason: "not_found" });
  });
});

describe("searchCode", () => {
  it("returns mapped items on 200", async () => {
    mockFetch.mockReturnValueOnce(
      mockResponse(200, {
        items: [{ path: "src/auth.ts", html_url: "https://github.com/org/repo/blob/main/src/auth.ts", score: 1.5 }],
      })
    );
    const result = await searchCode("org", "repo", "auth");
    expect(result).toEqual({
      data: { items: [{ path: "src/auth.ts", url: "https://github.com/org/repo/blob/main/src/auth.ts", score: 1.5 }] },
    });
  });
});
