import type { DegradedResult, GitHubPR, GitHubIssue, SourceResult } from "../types.js";

const BASE = "https://api.github.com";
const TIMEOUT_MS = 5000;

function authHeaders(): Record<string, string> {
  return {
    Authorization: `Bearer ${process.env.GITHUB_TOKEN}`,
    Accept: "application/vnd.github+json",
    "X-GitHub-Api-Version": "2022-11-28",
  };
}

async function githubFetch(url: string): Promise<Response> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), TIMEOUT_MS);
  try {
    return await fetch(url, { headers: authHeaders(), signal: controller.signal });
  } finally {
    clearTimeout(timer);
  }
}

function checkDegraded(res: Response): DegradedResult | null {
  if (res.status === 401) return { degraded: true, reason: "auth_failed" };
  if (res.status === 429) {
    const retry = parseInt(res.headers.get("retry-after") ?? "60", 10);
    return { degraded: true, reason: "rate_limited", retry_after: retry };
  }
  if (res.status === 403) {
    const remaining = res.headers.get("x-ratelimit-remaining");
    const retryAfter = res.headers.get("retry-after");
    if (retryAfter || remaining === "0") {
      const retry = parseInt(retryAfter ?? "60", 10);
      return { degraded: true, reason: "rate_limited", retry_after: retry };
    }
    return { degraded: true, reason: "auth_failed" };
  }
  return null;
}

export async function getPRs(
  owner: string,
  repo: string,
  label?: string,
  branch?: string
): Promise<SourceResult<{ prs: GitHubPR[] }>> {
  try {
    const params = new URLSearchParams({ state: "open", per_page: "20" });
    if (label) params.set("labels", label);
    if (branch) params.set("head", `${owner}:${branch}`);
    const res = await githubFetch(`${BASE}/repos/${owner}/${repo}/pulls?${params}`);
    const degraded = checkDegraded(res);
    if (degraded) return degraded;
    if (res.status === 404) return { degraded: true, reason: "not_found" };
    const json = (await res.json()) as Record<string, unknown>[];
    return {
      data: {
        prs: json.map((pr) => ({
          number: pr.number as number,
          title: pr.title as string,
          url: pr.html_url as string,
          state: pr.state as string,
          author: (pr.user as { login: string } | null)?.login ?? "[deleted]",
          labels: (pr.labels as { name: string }[]).map((l) => l.name),
          created_at: pr.created_at as string,
        })),
      },
    };
  } catch (err: unknown) {
    if (err instanceof Error && err.name === "AbortError") {
      return { degraded: true, reason: "timeout" };
    }
    return { degraded: true, reason: "unavailable" };
  }
}

export async function getIssue(
  owner: string,
  repo: string,
  issueNumber: number
): Promise<SourceResult<{ issue: GitHubIssue }>> {
  try {
    const res = await githubFetch(`${BASE}/repos/${owner}/${repo}/issues/${issueNumber}`);
    const degraded = checkDegraded(res);
    if (degraded) return degraded;
    if (res.status === 404) return { degraded: true, reason: "not_found" };
    const json = (await res.json()) as Record<string, unknown>;
    return {
      data: {
        issue: {
          number: json.number as number,
          title: json.title as string,
          url: json.html_url as string,
          state: json.state as string,
          body: (json.body as string) ?? "",
          labels: (json.labels as { name: string }[]).map((l) => l.name),
        },
      },
    };
  } catch (err: unknown) {
    if (err instanceof Error && err.name === "AbortError") {
      return { degraded: true, reason: "timeout" };
    }
    return { degraded: true, reason: "unavailable" };
  }
}

export async function searchCode(
  owner: string,
  repo: string,
  query: string
): Promise<SourceResult<{ items: Array<{ path: string; url: string; score: number }> }>> {
  try {
    const params = new URLSearchParams({ q: `${query} repo:${owner}/${repo}`, per_page: "10" });
    const res = await githubFetch(`${BASE}/search/code?${params}`);
    const degraded = checkDegraded(res);
    if (degraded) return degraded;
    if (res.status === 404) return { degraded: true, reason: "not_found" };
    const json = (await res.json()) as { items: Record<string, unknown>[] };
    return {
      data: {
        items: json.items.map((item) => ({
          path: item.path as string,
          url: item.html_url as string,
          score: item.score as number,
        })),
      },
    };
  } catch (err: unknown) {
    if (err instanceof Error && err.name === "AbortError") {
      return { degraded: true, reason: "timeout" };
    }
    return { degraded: true, reason: "unavailable" };
  }
}
