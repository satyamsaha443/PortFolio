import { describe, it, expect, vi, beforeEach } from "vitest";
import { searchPages, getPage, getDatabase } from "../../src/connectors/notion.js";

const mockFetch = vi.fn();
beforeEach(() => {
  vi.stubGlobal("fetch", mockFetch);
  mockFetch.mockReset();
  process.env.NOTION_TOKEN = "test-secret";
});

function mockResponse(status: number, body: unknown) {
  return Promise.resolve({
    status,
    ok: status >= 200 && status < 300,
    json: () => Promise.resolve(body),
  });
}

const notionPage = {
  id: "page-id-123",
  url: "https://notion.so/page-id-123",
  last_edited_time: "2024-06-01T12:00:00Z",
  properties: {
    Name: { type: "title", title: [{ plain_text: "Auth Design" }] },
  },
};

describe("searchPages", () => {
  it("returns mapped pages on 200", async () => {
    mockFetch.mockReturnValueOnce(mockResponse(200, { results: [notionPage] }));
    const result = await searchPages("auth");
    expect(result).toEqual({
      data: {
        pages: [
          {
            id: "page-id-123",
            title: "Auth Design",
            url: "https://notion.so/page-id-123",
            last_edited: "2024-06-01T12:00:00Z",
          },
        ],
      },
    });
  });

  it("returns auth_failed on 401", async () => {
    mockFetch.mockReturnValueOnce(mockResponse(401, {}));
    const result = await searchPages("auth");
    expect(result).toEqual({ degraded: true, reason: "auth_failed" });
  });

  it("returns timeout on AbortError", async () => {
    mockFetch.mockRejectedValueOnce(Object.assign(new Error("aborted"), { name: "AbortError" }));
    const result = await searchPages("auth");
    expect(result).toEqual({ degraded: true, reason: "timeout" });
  });

  it("returns not_found on 404", async () => {
    mockFetch.mockReturnValueOnce(mockResponse(404, {}));
    const result = await searchPages("auth");
    expect(result).toEqual({ degraded: true, reason: "not_found" });
  });
});

describe("getPage", () => {
  it("returns mapped page on 200", async () => {
    mockFetch.mockReturnValueOnce(mockResponse(200, notionPage));
    const result = await getPage("page-id-123");
    expect(result).toEqual({
      data: {
        page: {
          id: "page-id-123",
          title: "Auth Design",
          url: "https://notion.so/page-id-123",
          last_edited: "2024-06-01T12:00:00Z",
        },
      },
    });
  });

  it("returns not_found on 404", async () => {
    mockFetch.mockReturnValueOnce(mockResponse(404, {}));
    const result = await getPage("bad-id");
    expect(result).toEqual({ degraded: true, reason: "not_found" });
  });
});

describe("getDatabase", () => {
  it("returns results array on 200", async () => {
    mockFetch.mockReturnValueOnce(mockResponse(200, { results: [{ id: "row1" }] }));
    const result = await getDatabase("db-id-456");
    expect(result).toEqual({ data: { results: [{ id: "row1" }] } });
  });

  it("sends filter in request body when provided", async () => {
    mockFetch.mockReturnValueOnce(mockResponse(200, { results: [] }));
    await getDatabase("db-id", { property: "Status", select: { equals: "Done" } });
    const body = JSON.parse(mockFetch.mock.calls[0][1].body);
    expect(body.filter).toEqual({ property: "Status", select: { equals: "Done" } });
  });
});
