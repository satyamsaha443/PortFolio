import { getPRs } from "../connectors/github.js";
import { searchPages } from "../connectors/notion.js";
import { getIssues } from "../connectors/linear.js";
import type { RollupResult, SourceResult, GitHubPR, NotionPage, LinearIssue } from "../types.js";

export async function projectStatusRollup(
  project: string,
  owner: string,
  repo: string,
  linearTeam?: string
): Promise<RollupResult> {
  const [githubSettled, notionSettled, linearSettled] = await Promise.allSettled([
    getPRs(owner, repo, project),
    searchPages(project),
    getIssues(linearTeam),
  ]);

  function resolve<T>(
    settled: PromiseSettledResult<SourceResult<T>>
  ): SourceResult<T> {
    if (settled.status === "fulfilled") return settled.value;
    return { degraded: true, reason: "unavailable" };
  }

  const github = resolve(githubSettled as PromiseSettledResult<SourceResult<{ prs: GitHubPR[] }>>);
  const notion = resolve(notionSettled as PromiseSettledResult<SourceResult<{ pages: NotionPage[] }>>);
  const linear = resolve(linearSettled as PromiseSettledResult<SourceResult<{ issues: LinearIssue[] }>>);

  const missing: string[] = [];
  if ("degraded" in github && github.degraded) missing.push("github");
  if ("degraded" in notion && notion.degraded) missing.push("notion");
  if ("degraded" in linear && linear.degraded) missing.push("linear");

  const result: RollupResult = { github, notion, linear };
  if (missing.length > 0) {
    result._partial = true;
    result._missing = missing;
  }
  return result;
}
