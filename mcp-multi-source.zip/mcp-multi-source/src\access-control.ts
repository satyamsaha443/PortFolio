import { readFileSync } from "fs";
import { join, dirname } from "path";
import { fileURLToPath } from "url";
import type { Permission } from "./types.js";

const __dirname = dirname(fileURLToPath(import.meta.url));

export class PermissionDeniedError extends Error {
  constructor(tool: string, permission: Permission, role: string) {
    super(
      `Tool '${tool}' requires '${permission}' but role '${role}' does not have it`
    );
    this.name = "PermissionDeniedError";
  }
}

type RolesConfig = Record<string, Permission[]>;

function loadRoles(): RolesConfig {
  const configPath = join(__dirname, "..", "config", "roles.json");
  try {
    return JSON.parse(readFileSync(configPath, "utf-8")) as RolesConfig;
  } catch {
    return {};
  }
}

export function getPermissionsForRole(role: string): Permission[] {
  const roles = loadRoles();
  return roles[role] ?? [];
}

export function checkPermission(
  tool: string,
  required: Permission[],
  role: string
): void {
  const granted = getPermissionsForRole(role);
  for (const perm of required) {
    if (!granted.includes(perm)) {
      throw new PermissionDeniedError(tool, perm, role);
    }
  }
}
