package com.redis.protocol;

import com.redis.command.Command;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

public class RespParser {
    private final BufferedReader reader;

    public RespParser(InputStream in) {
        this.reader = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8));
    }

    public Command parse() throws IOException, RespException {
        String line = reader.readLine();
        if (line == null) {
            throw new IOException("Client disconnected");
        }
        if (line.startsWith("*")) {
            return parseArray(line);
        }
        return parseInline(line);
    }

    private Command parseArray(String firstLine) throws IOException, RespException {
        int count;
        try {
            count = Integer.parseInt(firstLine.substring(1));
        } catch (NumberFormatException e) {
            throw new RespException("Invalid array length: " + firstLine);
        }
        if (count < 1) {
            throw new RespException("Array length must be >= 1, got: " + count);
        }
        List<String> tokens = new ArrayList<>(count);
        for (int i = 0; i < count; i++) {
            tokens.add(parseBulkString());
        }
        return new Command(tokens.get(0).toUpperCase(), List.copyOf(tokens.subList(1, tokens.size())));
    }

    private String parseBulkString() throws IOException, RespException {
        String lengthLine = reader.readLine();
        if (lengthLine == null || !lengthLine.startsWith("$")) {
            throw new RespException("Expected bulk string '$', got: " + lengthLine);
        }
        int length;
        try {
            length = Integer.parseInt(lengthLine.substring(1));
        } catch (NumberFormatException e) {
            throw new RespException("Invalid bulk string length: " + lengthLine);
        }
        if (length < 0) {
            throw new RespException("Negative bulk string length: " + length);
        }
        String data = reader.readLine();
        if (data == null) {
            throw new RespException("Unexpected end of stream reading bulk string data");
        }
        return data;
    }

    private Command parseInline(String line) {
        String[] parts = line.trim().split("\\s+");
        List<String> args = parts.length > 1
            ? List.copyOf(List.of(parts).subList(1, parts.length))
            : List.of();
        return new Command(parts[0].toUpperCase(), args);
    }
}
