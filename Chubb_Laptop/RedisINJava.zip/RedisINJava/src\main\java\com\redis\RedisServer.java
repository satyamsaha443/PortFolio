package com.redis;

import com.redis.command.CommandDispatcher;
import com.redis.storage.InMemoryStore;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class RedisServer {
    private final int port;
    private volatile ServerSocket serverSocket;

    public RedisServer(int port) {
        this.port = port;
    }

    public void start() throws IOException {
        var store = new InMemoryStore();
        var dispatcher = new CommandDispatcher(store);
        serverSocket = new ServerSocket();
        serverSocket.setReuseAddress(true);
        serverSocket.bind(new InetSocketAddress(port));

        ExecutorService executor = Executors.newCachedThreadPool();
        try {
            System.out.println("Redis server started on port " + port);
            while (!serverSocket.isClosed()) {
                try {
                    Socket socket = serverSocket.accept();
                    executor.submit(new ClientHandler(socket, dispatcher));
                } catch (IOException e) {
                    if (!serverSocket.isClosed()) throw e;
                }
            }
        } finally {
            executor.shutdown();
        }
    }

    public void stop() throws IOException {
        if (serverSocket != null) {
            serverSocket.close();
        }
    }

    public static void main(String[] args) throws IOException {
        int port = Integer.parseInt(System.getProperty("redis.port", "6379"));
        new RedisServer(port).start();
    }
}
