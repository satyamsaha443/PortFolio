package com.redis;

import org.junit.jupiter.api.*;
import redis.clients.jedis.Jedis;

import java.io.IOException;

import static org.junit.jupiter.api.Assertions.*;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
class RedisServerIntegrationTest {
    private static final int PORT = 16379;
    private RedisServer server;

    @BeforeAll
    void startServer() throws Exception {
        server = new RedisServer(PORT);
        new Thread(() -> {
            try { server.start(); } catch (IOException ignored) {}
        }).start();
        Thread.sleep(300); // wait for ServerSocket to bind
    }

    @AfterAll
    void stopServer() throws IOException {
        server.stop();
    }

    @Test
    void ping() {
        try (var jedis = new Jedis("localhost", PORT)) {
            assertEquals("PONG", jedis.ping());
        }
    }

    @Test
    void setAndGet() {
        try (var jedis = new Jedis("localhost", PORT)) {
            assertEquals("OK", jedis.set("lang", "Java"));
            assertEquals("Java", jedis.get("lang"));
        }
    }

    @Test
    void getMissingKeyReturnsNull() {
        try (var jedis = new Jedis("localhost", PORT)) {
            assertNull(jedis.get("nonexistent-key-xyz"));
        }
    }

    @Test
    void multipleClientsShareSameStore() {
        try (var c1 = new Jedis("localhost", PORT);
             var c2 = new Jedis("localhost", PORT)) {
            c1.set("shared", "from-c1");
            assertEquals("from-c1", c2.get("shared"));
        }
    }
}
