package com.redis.command;

import org.junit.jupiter.api.Test;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

class CommandTest {

    @Test
    void holdsNameAndArgs() {
        var cmd = new Command("SET", List.of("foo", "bar"));
        assertEquals("SET", cmd.name());
        assertEquals(List.of("foo", "bar"), cmd.args());
    }

    @Test
    void noArgCommand() {
        var cmd = new Command("PING", List.of());
        assertEquals("PING", cmd.name());
        assertTrue(cmd.args().isEmpty());
    }
}
