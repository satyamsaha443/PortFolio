package com.redis.protocol;

import org.junit.jupiter.api.Test;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import static org.junit.jupiter.api.Assertions.*;

class RespWriterTest {

    @FunctionalInterface
    interface WriterAction {
        void run(RespWriter writer) throws IOException;
    }

    private String write(WriterAction action) throws IOException {
        var out = new ByteArrayOutputStream();
        action.run(new RespWriter(out));
        return out.toString(StandardCharsets.UTF_8);
    }

    @Test
    void writesSimpleString() throws IOException {
        assertEquals("+PONG\r\n", write(w -> w.writeSimpleString("PONG")));
    }

    @Test
    void writesBulkString() throws IOException {
        assertEquals("$3\r\nfoo\r\n", write(w -> w.writeBulkString("foo")));
    }

    @Test
    void writesNil() throws IOException {
        assertEquals("$-1\r\n", write(RespWriter::writeNil));
    }

    @Test
    void writesError() throws IOException {
        assertEquals("-ERR unknown command\r\n", write(w -> w.writeError("unknown command")));
    }
}
