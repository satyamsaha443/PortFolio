# Redis Clone in Java — Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Build a Java 21 Redis clone that speaks real RESP protocol over TCP, handling PING/SET/GET with one virtual thread per client.

**Architecture:** Layered pipeline — `RespParser` decodes wire bytes into `Command` records; `CommandDispatcher` routes to `InMemoryStore` and writes responses via `RespWriter`. Each layer is independently unit-testable. `ClientHandler` wires the layers together for one socket lifecycle; `RedisServer` accepts connections and submits each to a virtual-thread executor.

**Tech Stack:** Java 21 LTS, Maven 3.x, JUnit Jupiter 5.10.2, Jedis 5.1.0 (test scope)

## Global Constraints

- Java 21 — `maven.compiler.release=21` in `pom.xml`
- Package root: `com.redis`
- Wire protocol: RESP — all socket communication uses RESP encoding/decoding
- Every `RespWriter` public method must call `flush()` before returning
- `RespWriter` is the **only** class that writes bytes to the socket — `ClientHandler` never writes raw bytes directly
- `ConcurrentHashMap` backs `InMemoryStore` — use `compute()`/`putIfAbsent()`/`merge()` for any compound operations
- Virtual threads via `Executors.newVirtualThreadPerTaskExecutor()`

---

### Task 1: Maven project scaffold

**Files:**
- Create: `pom.xml`
- Create directory tree: `src/main/java/com/redis/{protocol,command,storage}/` and `src/test/java/com/redis/{protocol,command,storage}/`

**Interfaces:**
- Produces: compilable Maven project with JUnit 5 and Jedis available on the test classpath

- [ ] **Step 1: Create `pom.xml` at the project root**

```xml
<?xml version="1.0" encoding="UTF-8"?>
<project xmlns="http://maven.apache.org/POM/4.0.0"
         xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
         xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 http://maven.apache.org/xsd/maven-4.0.0.xsd">
  <modelVersion>4.0.0</modelVersion>

  <groupId>com.redis</groupId>
  <artifactId>redis-java</artifactId>
  <version>1.0-SNAPSHOT</version>
  <packaging>jar</packaging>

  <properties>
    <maven.compiler.release>21</maven.compiler.release>
    <project.build.sourceEncoding>UTF-8</project.build.sourceEncoding>
  </properties>

  <dependencies>
    <dependency>
      <groupId>org.junit.jupiter</groupId>
      <artifactId>junit-jupiter</artifactId>
      <version>5.10.2</version>
      <scope>test</scope>
    </dependency>
    <dependency>
      <groupId>redis.clients</groupId>
      <artifactId>jedis</artifactId>
      <version>5.1.0</version>
      <scope>test</scope>
    </dependency>
  </dependencies>

  <build>
    <plugins>
      <plugin>
        <groupId>org.apache.maven.plugins</groupId>
        <artifactId>maven-compiler-plugin</artifactId>
        <version>3.12.1</version>
      </plugin>
      <plugin>
        <groupId>org.apache.maven.plugins</groupId>
        <artifactId>maven-surefire-plugin</artifactId>
        <version>3.2.5</version>
      </plugin>
      <plugin>
        <groupId>org.apache.maven.plugins</groupId>
        <artifactId>maven-jar-plugin</artifactId>
        <version>3.3.0</version>
        <configuration>
          <archive>
            <manifest>
              <mainClass>com.redis.RedisServer</mainClass>
            </manifest>
          </archive>
        </configuration>
      </plugin>
      <plugin>
        <groupId>org.codehaus.mojo</groupId>
        <artifactId>exec-maven-plugin</artifactId>
        <version>3.1.1</version>
        <configuration>
          <mainClass>com.redis.RedisServer</mainClass>
        </configuration>
      </plugin>
    </plugins>
  </build>
</project>
```

- [ ] **Step 2: Create source directory structure**

```bash
mkdir -p src/main/java/com/redis/protocol
mkdir -p src/main/java/com/redis/command
mkdir -p src/main/java/com/redis/storage
mkdir -p src/test/java/com/redis/protocol
mkdir -p src/test/java/com/redis/command
mkdir -p src/test/java/com/redis/storage
```

- [ ] **Step 3: Verify Maven resolves dependencies**

```bash
mvn compile
```
Expected: `BUILD SUCCESS` (no source files yet, just dependency resolution)

- [ ] **Step 4: Commit**

```bash
git add pom.xml src/
git commit -m "chore: scaffold Maven project with Java 21, JUnit 5, Jedis"
```

---

### Task 2: `RespException`

**Files:**
- Create: `src/main/java/com/redis/protocol/RespException.java`

**Interfaces:**
- Produces: `new RespException(String message)` — checked exception, thrown by `RespParser` on protocol violations

- [ ] **Step 1: Create `RespException.java`**

```java
package com.redis.protocol;

public class RespException extends Exception {
    public RespException(String message) {
        super(message);
    }
}
```

- [ ] **Step 2: Compile**

```bash
mvn compile
```
Expected: `BUILD SUCCESS`

- [ ] **Step 3: Commit**

```bash
git add src/main/java/com/redis/protocol/RespException.java
git commit -m "feat: add RespException checked exception for RESP protocol errors"
```

---

### Task 3: `InMemoryStore`

**Files:**
- Create: `src/main/java/com/redis/storage/InMemoryStore.java`
- Create: `src/test/java/com/redis/storage/InMemoryStoreTest.java`

**Interfaces:**
- Produces:
  - `InMemoryStore()` — no-arg constructor
  - `void set(String key, String value)`
  - `Optional<String> get(String key)` — `Optional.empty()` when key absent

- [ ] **Step 1: Write failing tests**

Create `src/test/java/com/redis/storage/InMemoryStoreTest.java`:

```java
package com.redis.storage;

import org.junit.jupiter.api.Test;
import java.util.Optional;
import static org.junit.jupiter.api.Assertions.*;

class InMemoryStoreTest {

    @Test
    void getMissingKeyReturnsEmpty() {
        var store = new InMemoryStore();
        assertEquals(Optional.empty(), store.get("missing"));
    }

    @Test
    void setThenGetReturnsValue() {
        var store = new InMemoryStore();
        store.set("name", "Satyam");
        assertEquals(Optional.of("Satyam"), store.get("name"));
    }

    @Test
    void setOverwritesExistingKey() {
        var store = new InMemoryStore();
        store.set("key", "first");
        store.set("key", "second");
        assertEquals(Optional.of("second"), store.get("key"));
    }
}
```

- [ ] **Step 2: Run tests — verify they fail**

```bash
mvn test -Dtest=InMemoryStoreTest
```
Expected: compilation error (`InMemoryStore` not found)

- [ ] **Step 3: Implement `InMemoryStore`**

Create `src/main/java/com/redis/storage/InMemoryStore.java`:

```java
package com.redis.storage;

import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;

public class InMemoryStore {
    private final ConcurrentHashMap<String, String> data = new ConcurrentHashMap<>();

    public void set(String key, String value) {
        data.put(key, value);
    }

    public Optional<String> get(String key) {
        return Optional.ofNullable(data.get(key));
    }
}
```

- [ ] **Step 4: Run tests — verify they pass**

```bash
mvn test -Dtest=InMemoryStoreTest
```
Expected: `Tests run: 3, Failures: 0, Errors: 0`

- [ ] **Step 5: Commit**

```bash
git add src/main/java/com/redis/storage/InMemoryStore.java \
        src/test/java/com/redis/storage/InMemoryStoreTest.java
git commit -m "feat: add InMemoryStore backed by ConcurrentHashMap"
```

---

### Task 4: `Command` record

**Files:**
- Create: `src/main/java/com/redis/command/Command.java`
- Create: `src/test/java/com/redis/command/CommandTest.java`

**Interfaces:**
- Produces: `record Command(String name, List<String> args)` — immutable; name is always uppercase (enforced by caller)

- [ ] **Step 1: Write failing tests**

Create `src/test/java/com/redis/command/CommandTest.java`:

```java
package com.redis.command;

import org.junit.jupiter.api.Test;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

class CommandTest {

    @Test
    void holdsNameAndArgs() {
        var cmd = new Command("SET", List.of("foo", "bar"));
        assertEquals("SET", cmd.name());
        assertEquals(List.of("foo", "bar"), cmd.args());
    }

    @Test
    void noArgCommand() {
        var cmd = new Command("PING", List.of());
        assertEquals("PING", cmd.name());
        assertTrue(cmd.args().isEmpty());
    }
}
```

- [ ] **Step 2: Run tests — verify they fail**

```bash
mvn test -Dtest=CommandTest
```
Expected: compilation error

- [ ] **Step 3: Implement `Command`**

Create `src/main/java/com/redis/command/Command.java`:

```java
package com.redis.command;

import java.util.List;

public record Command(String name, List<String> args) {}
```

- [ ] **Step 4: Run tests — verify they pass**

```bash
mvn test -Dtest=CommandTest
```
Expected: `Tests run: 2, Failures: 0, Errors: 0`

- [ ] **Step 5: Commit**

```bash
git add src/main/java/com/redis/command/Command.java \
        src/test/java/com/redis/command/CommandTest.java
git commit -m "feat: add Command record for parsed RESP commands"
```

---

### Task 5: `RespWriter`

**Files:**
- Create: `src/main/java/com/redis/protocol/RespWriter.java`
- Create: `src/test/java/com/redis/protocol/RespWriterTest.java`

**Interfaces:**
- Produces:
  - `RespWriter(OutputStream out)`
  - `void writeSimpleString(String value) throws IOException` → `+value\r\n`
  - `void writeBulkString(String value) throws IOException` → `$<byteLen>\r\n<value>\r\n`
  - `void writeNil() throws IOException` → `$-1\r\n`
  - `void writeError(String message) throws IOException` → `-ERR message\r\n`

- [ ] **Step 1: Write failing tests**

Create `src/test/java/com/redis/protocol/RespWriterTest.java`:

```java
package com.redis.protocol;

import org.junit.jupiter.api.Test;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import static org.junit.jupiter.api.Assertions.*;

class RespWriterTest {

    @FunctionalInterface
    interface WriterAction {
        void run(RespWriter writer) throws IOException;
    }

    private String write(WriterAction action) throws IOException {
        var out = new ByteArrayOutputStream();
        action.run(new RespWriter(out));
        return out.toString(StandardCharsets.UTF_8);
    }

    @Test
    void writesSimpleString() throws IOException {
        assertEquals("+PONG\r\n", write(w -> w.writeSimpleString("PONG")));
    }

    @Test
    void writesBulkString() throws IOException {
        assertEquals("$3\r\nfoo\r\n", write(w -> w.writeBulkString("foo")));
    }

    @Test
    void writesNil() throws IOException {
        assertEquals("$-1\r\n", write(RespWriter::writeNil));
    }

    @Test
    void writesError() throws IOException {
        assertEquals("-ERR unknown command\r\n", write(w -> w.writeError("unknown command")));
    }
}
```

- [ ] **Step 2: Run tests — verify they fail**

```bash
mvn test -Dtest=RespWriterTest
```
Expected: compilation error

- [ ] **Step 3: Implement `RespWriter`**

Create `src/main/java/com/redis/protocol/RespWriter.java`:

```java
package com.redis.protocol;

import java.io.IOException;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

public class RespWriter {
    private final OutputStream out;

    public RespWriter(OutputStream out) {
        this.out = out;
    }

    public void writeSimpleString(String value) throws IOException {
        write("+" + value + "\r\n");
    }

    public void writeBulkString(String value) throws IOException {
        byte[] bytes = value.getBytes(StandardCharsets.UTF_8);
        write("$" + bytes.length + "\r\n");
        out.write(bytes);
        write("\r\n");
    }

    public void writeNil() throws IOException {
        write("$-1\r\n");
    }

    public void writeError(String message) throws IOException {
        write("-ERR " + message + "\r\n");
    }

    private void write(String text) throws IOException {
        out.write(text.getBytes(StandardCharsets.UTF_8));
        out.flush();
    }
}
```

- [ ] **Step 4: Run tests — verify they pass**

```bash
mvn test -Dtest=RespWriterTest
```
Expected: `Tests run: 4, Failures: 0, Errors: 0`

- [ ] **Step 5: Commit**

```bash
git add src/main/java/com/redis/protocol/RespWriter.java \
        src/test/java/com/redis/protocol/RespWriterTest.java
git commit -m "feat: add RespWriter encoding RESP responses to OutputStream"
```

---

### Task 6: `RespParser`

**Files:**
- Create: `src/main/java/com/redis/protocol/RespParser.java`
- Create: `src/test/java/com/redis/protocol/RespParserTest.java`

**Interfaces:**
- Consumes: `Command(String name, List<String> args)`, `RespException(String message)`
- Produces:
  - `RespParser(InputStream in)`
  - `Command parse() throws IOException, RespException` — reads one complete RESP frame; throws `IOException` when client disconnects (null line from `readLine()`); throws `RespException` on malformed protocol bytes

- [ ] **Step 1: Write failing tests**

Create `src/test/java/com/redis/protocol/RespParserTest.java`:

```java
package com.redis.protocol;

import com.redis.command.Command;
import org.junit.jupiter.api.Test;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

class RespParserTest {

    private Command parse(String input) throws IOException, RespException {
        byte[] bytes = input.getBytes(StandardCharsets.UTF_8);
        return new RespParser(new ByteArrayInputStream(bytes)).parse();
    }

    @Test
    void parsesArrayPing() throws Exception {
        Command cmd = parse("*1\r\n$4\r\nPING\r\n");
        assertEquals("PING", cmd.name());
        assertTrue(cmd.args().isEmpty());
    }

    @Test
    void parsesSet() throws Exception {
        Command cmd = parse("*3\r\n$3\r\nSET\r\n$3\r\nfoo\r\n$3\r\nbar\r\n");
        assertEquals("SET", cmd.name());
        assertEquals(List.of("foo", "bar"), cmd.args());
    }

    @Test
    void parsesGet() throws Exception {
        Command cmd = parse("*2\r\n$3\r\nGET\r\n$3\r\nfoo\r\n");
        assertEquals("GET", cmd.name());
        assertEquals(List.of("foo"), cmd.args());
    }

    @Test
    void parsesInlinePing() throws Exception {
        Command cmd = parse("PING\r\n");
        assertEquals("PING", cmd.name());
        assertTrue(cmd.args().isEmpty());
    }

    @Test
    void normalizesCommandNameToUpperCase() throws Exception {
        Command cmd = parse("*1\r\n$4\r\nping\r\n");
        assertEquals("PING", cmd.name());
    }

    @Test
    void throwsRespExceptionOnInvalidArrayLength() {
        assertThrows(RespException.class, () -> parse("*abc\r\n$4\r\nPING\r\n"));
    }

    @Test
    void throwsRespExceptionOnMissingBulkStringPrefix() {
        assertThrows(RespException.class, () -> parse("*1\r\nfoo\r\n"));
    }

    @Test
    void throwsIOExceptionOnEmptyStream() {
        assertThrows(IOException.class,
            () -> new RespParser(new ByteArrayInputStream(new byte[0])).parse());
    }
}
```

- [ ] **Step 2: Run tests — verify they fail**

```bash
mvn test -Dtest=RespParserTest
```
Expected: compilation error

- [ ] **Step 3: Implement `RespParser`**

Create `src/main/java/com/redis/protocol/RespParser.java`:

```java
package com.redis.protocol;

import com.redis.command.Command;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

public class RespParser {
    private final BufferedReader reader;

    public RespParser(InputStream in) {
        this.reader = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8));
    }

    public Command parse() throws IOException, RespException {
        String line = reader.readLine();
        if (line == null) {
            throw new IOException("Client disconnected");
        }
        if (line.startsWith("*")) {
            return parseArray(line);
        }
        return parseInline(line);
    }

    private Command parseArray(String firstLine) throws IOException, RespException {
        int count;
        try {
            count = Integer.parseInt(firstLine.substring(1));
        } catch (NumberFormatException e) {
            throw new RespException("Invalid array length: " + firstLine);
        }
        if (count < 1) {
            throw new RespException("Array length must be >= 1, got: " + count);
        }
        List<String> tokens = new ArrayList<>(count);
        for (int i = 0; i < count; i++) {
            tokens.add(parseBulkString());
        }
        return new Command(tokens.get(0).toUpperCase(), List.copyOf(tokens.subList(1, tokens.size())));
    }

    private String parseBulkString() throws IOException, RespException {
        String lengthLine = reader.readLine();
        if (lengthLine == null || !lengthLine.startsWith("$")) {
            throw new RespException("Expected bulk string '$', got: " + lengthLine);
        }
        int length;
        try {
            length = Integer.parseInt(lengthLine.substring(1));
        } catch (NumberFormatException e) {
            throw new RespException("Invalid bulk string length: " + lengthLine);
        }
        if (length < 0) {
            throw new RespException("Negative bulk string length: " + length);
        }
        String data = reader.readLine();
        if (data == null) {
            throw new RespException("Unexpected end of stream reading bulk string data");
        }
        return data;
    }

    private Command parseInline(String line) {
        String[] parts = line.trim().split("\\s+");
        List<String> args = parts.length > 1
            ? List.copyOf(List.of(parts).subList(1, parts.length))
            : List.of();
        return new Command(parts[0].toUpperCase(), args);
    }
}
```

- [ ] **Step 4: Run tests — verify they pass**

```bash
mvn test -Dtest=RespParserTest
```
Expected: `Tests run: 8, Failures: 0, Errors: 0`

- [ ] **Step 5: Commit**

```bash
git add src/main/java/com/redis/protocol/RespParser.java \
        src/test/java/com/redis/protocol/RespParserTest.java
git commit -m "feat: add RespParser decoding RESP arrays and inline commands"
```

---

### Task 7: `CommandDispatcher`

**Files:**
- Create: `src/main/java/com/redis/command/CommandDispatcher.java`
- Create: `src/test/java/com/redis/command/CommandDispatcherTest.java`

**Interfaces:**
- Consumes: `Command(String name, List<String> args)`, `InMemoryStore.set(String,String)` / `InMemoryStore.get(String): Optional<String>`, all `RespWriter.write*` methods
- Produces:
  - `CommandDispatcher(InMemoryStore store)`
  - `void dispatch(Command command, RespWriter writer) throws IOException`

- [ ] **Step 1: Write failing tests**

Create `src/test/java/com/redis/command/CommandDispatcherTest.java`:

```java
package com.redis.command;

import com.redis.protocol.RespWriter;
import com.redis.storage.InMemoryStore;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class CommandDispatcherTest {
    private InMemoryStore store;
    private CommandDispatcher dispatcher;

    @BeforeEach
    void setUp() {
        store = new InMemoryStore();
        dispatcher = new CommandDispatcher(store);
    }

    private String dispatch(Command command) throws IOException {
        var out = new ByteArrayOutputStream();
        dispatcher.dispatch(command, new RespWriter(out));
        return out.toString(StandardCharsets.UTF_8);
    }

    @Test
    void pingReturnsPong() throws IOException {
        assertEquals("+PONG\r\n", dispatch(new Command("PING", List.of())));
    }

    @Test
    void setStoresValueAndReturnsOk() throws IOException {
        assertEquals("+OK\r\n", dispatch(new Command("SET", List.of("key", "value"))));
        assertEquals("value", store.get("key").orElseThrow());
    }

    @Test
    void getReturnsStoredValue() throws IOException {
        store.set("greeting", "hello");
        assertEquals("$5\r\nhello\r\n", dispatch(new Command("GET", List.of("greeting"))));
    }

    @Test
    void getMissingKeyReturnsNil() throws IOException {
        assertEquals("$-1\r\n", dispatch(new Command("GET", List.of("missing"))));
    }

    @Test
    void setWithMissingValueReturnsError() throws IOException {
        String response = dispatch(new Command("SET", List.of("key")));
        assertTrue(response.startsWith("-ERR"));
        assertTrue(response.contains("set"));
    }

    @Test
    void unknownCommandReturnsError() throws IOException {
        String response = dispatch(new Command("HGET", List.of("key", "field")));
        assertTrue(response.startsWith("-ERR"));
        assertTrue(response.contains("hget"));
    }
}
```

- [ ] **Step 2: Run tests — verify they fail**

```bash
mvn test -Dtest=CommandDispatcherTest
```
Expected: compilation error

- [ ] **Step 3: Implement `CommandDispatcher`**

Create `src/main/java/com/redis/command/CommandDispatcher.java`:

```java
package com.redis.command;

import com.redis.protocol.RespWriter;
import com.redis.storage.InMemoryStore;

import java.io.IOException;

public class CommandDispatcher {
    private final InMemoryStore store;

    public CommandDispatcher(InMemoryStore store) {
        this.store = store;
    }

    public void dispatch(Command command, RespWriter writer) throws IOException {
        switch (command.name()) {
            case "PING" -> writer.writeSimpleString("PONG");
            case "SET"  -> handleSet(command, writer);
            case "GET"  -> handleGet(command, writer);
            default     -> writer.writeError("unknown command '" + command.name().toLowerCase() + "'");
        }
    }

    private void handleSet(Command command, RespWriter writer) throws IOException {
        if (command.args().size() < 2) {
            writer.writeError("wrong number of arguments for 'set' command");
            return;
        }
        store.set(command.args().get(0), command.args().get(1));
        writer.writeSimpleString("OK");
    }

    private void handleGet(Command command, RespWriter writer) throws IOException {
        if (command.args().isEmpty()) {
            writer.writeError("wrong number of arguments for 'get' command");
            return;
        }
        var value = store.get(command.args().get(0));
        if (value.isPresent()) {
            writer.writeBulkString(value.get());
        } else {
            writer.writeNil();
        }
    }
}
```

- [ ] **Step 4: Run tests — verify they pass**

```bash
mvn test -Dtest=CommandDispatcherTest
```
Expected: `Tests run: 6, Failures: 0, Errors: 0`

- [ ] **Step 5: Commit**

```bash
git add src/main/java/com/redis/command/CommandDispatcher.java \
        src/test/java/com/redis/command/CommandDispatcherTest.java
git commit -m "feat: add CommandDispatcher routing PING/SET/GET via RespWriter"
```

---

### Task 8: `ClientHandler`

**Files:**
- Create: `src/main/java/com/redis/ClientHandler.java`

**Interfaces:**
- Consumes: `RespParser(InputStream)` returning `Command`; `RespWriter(OutputStream)`; `CommandDispatcher.dispatch(Command, RespWriter) throws IOException`
- Produces: `ClientHandler(Socket socket, CommandDispatcher dispatcher)` — implements `Runnable`; closes socket on exit

No dedicated unit test — `ClientHandler` is a thin coordinator; its end-to-end behaviour is verified by the integration test in Task 9.

- [ ] **Step 1: Implement `ClientHandler`**

Create `src/main/java/com/redis/ClientHandler.java`:

```java
package com.redis;

import com.redis.command.CommandDispatcher;
import com.redis.protocol.RespException;
import com.redis.protocol.RespParser;
import com.redis.protocol.RespWriter;

import java.io.IOException;
import java.net.Socket;

public class ClientHandler implements Runnable {
    private final Socket socket;
    private final CommandDispatcher dispatcher;

    public ClientHandler(Socket socket, CommandDispatcher dispatcher) {
        this.socket = socket;
        this.dispatcher = dispatcher;
    }

    @Override
    public void run() {
        try (socket) {
            var parser = new RespParser(socket.getInputStream());
            var writer = new RespWriter(socket.getOutputStream());
            while (true) {
                try {
                    var command = parser.parse();
                    dispatcher.dispatch(command, writer);
                } catch (RespException e) {
                    writer.writeError(e.getMessage());
                }
            }
        } catch (IOException ignored) {
            // client disconnected or server shutting down — normal exit
        }
    }
}
```

- [ ] **Step 2: Compile**

```bash
mvn compile
```
Expected: `BUILD SUCCESS`

- [ ] **Step 3: Commit**

```bash
git add src/main/java/com/redis/ClientHandler.java
git commit -m "feat: add ClientHandler coordinating parser/dispatcher per socket"
```

---

### Task 9: `RedisServer` + integration test

**Files:**
- Create: `src/main/java/com/redis/RedisServer.java`
- Create: `src/test/java/com/redis/RedisServerIntegrationTest.java`

**Interfaces:**
- Consumes: `ClientHandler(Socket, CommandDispatcher)`, `InMemoryStore()`, `CommandDispatcher(InMemoryStore)`
- Produces:
  - `RedisServer(int port)`
  - `void start() throws IOException` — binds `ServerSocket`, runs accept loop; blocks until `stop()` closes the socket
  - `void stop() throws IOException` — closes the `ServerSocket` to unblock `accept()`
  - `static void main(String[] args) throws IOException` — reads system property `redis.port` (default `"6379"`), delegates to `new RedisServer(port).start()`

- [ ] **Step 1: Write failing integration test**

Create `src/test/java/com/redis/RedisServerIntegrationTest.java`:

```java
package com.redis;

import org.junit.jupiter.api.*;
import redis.clients.jedis.Jedis;

import java.io.IOException;

import static org.junit.jupiter.api.Assertions.*;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
class RedisServerIntegrationTest {
    private static final int PORT = 16379;
    private RedisServer server;

    @BeforeAll
    void startServer() throws Exception {
        server = new RedisServer(PORT);
        Thread.ofVirtual().start(() -> {
            try { server.start(); } catch (IOException ignored) {}
        });
        Thread.sleep(300); // wait for ServerSocket to bind
    }

    @AfterAll
    void stopServer() throws IOException {
        server.stop();
    }

    @Test
    void ping() {
        try (var jedis = new Jedis("localhost", PORT)) {
            assertEquals("PONG", jedis.ping());
        }
    }

    @Test
    void setAndGet() {
        try (var jedis = new Jedis("localhost", PORT)) {
            assertEquals("OK", jedis.set("lang", "Java"));
            assertEquals("Java", jedis.get("lang"));
        }
    }

    @Test
    void getMissingKeyReturnsNull() {
        try (var jedis = new Jedis("localhost", PORT)) {
            assertNull(jedis.get("nonexistent-key-xyz"));
        }
    }

    @Test
    void multipleClientsShareSameStore() {
        try (var c1 = new Jedis("localhost", PORT);
             var c2 = new Jedis("localhost", PORT)) {
            c1.set("shared", "from-c1");
            assertEquals("from-c1", c2.get("shared"));
        }
    }
}
```

- [ ] **Step 2: Run test — verify it fails**

```bash
mvn test -Dtest=RedisServerIntegrationTest
```
Expected: compilation error (`RedisServer` not found)

- [ ] **Step 3: Implement `RedisServer`**

Create `src/main/java/com/redis/RedisServer.java`:

```java
package com.redis;

import com.redis.command.CommandDispatcher;
import com.redis.storage.InMemoryStore;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.concurrent.Executors;

public class RedisServer {
    private final int port;
    private volatile ServerSocket serverSocket;

    public RedisServer(int port) {
        this.port = port;
    }

    public void start() throws IOException {
        var store = new InMemoryStore();
        var dispatcher = new CommandDispatcher(store);
        serverSocket = new ServerSocket(port);

        try (var executor = Executors.newVirtualThreadPerTaskExecutor()) {
            System.out.println("Redis server started on port " + port);
            while (!serverSocket.isClosed()) {
                try {
                    Socket socket = serverSocket.accept();
                    executor.submit(new ClientHandler(socket, dispatcher));
                } catch (IOException e) {
                    if (!serverSocket.isClosed()) throw e;
                }
            }
        }
    }

    public void stop() throws IOException {
        if (serverSocket != null) {
            serverSocket.close();
        }
    }

    public static void main(String[] args) throws IOException {
        int port = Integer.parseInt(System.getProperty("redis.port", "6379"));
        new RedisServer(port).start();
    }
}
```

- [ ] **Step 4: Run the full test suite**

```bash
mvn test
```
Expected (all tests green):
```
Tests run: 4  -- RedisServerIntegrationTest
Tests run: 6  -- CommandDispatcherTest
Tests run: 8  -- RespParserTest
Tests run: 4  -- RespWriterTest
Tests run: 3  -- InMemoryStoreTest
Tests run: 2  -- CommandTest
BUILD SUCCESS
```

- [ ] **Step 5: Manual smoke test**

Terminal 1 — start the server:
```bash
mvn compile exec:java
# Output: Redis server started on port 6379
```

Terminal 2 — test with `redis-cli` (if installed):
```bash
redis-cli ping               # PONG
redis-cli set name Satyam    # OK
redis-cli get name           # "Satyam"
redis-cli get missing        # (nil)
redis-cli hget x y           # (error) ERR unknown command 'hget'
```

Terminal 2 — test without `redis-cli` (PowerShell):
```powershell
$tcp = New-Object System.Net.Sockets.TcpClient("localhost", 6379)
$stream = $tcp.GetStream()
$msg = [System.Text.Encoding]::UTF8.GetBytes("*1`r`n`$4`r`nPING`r`n")
$stream.Write($msg, 0, $msg.Length)
$buf = New-Object byte[] 64
$n = $stream.Read($buf, 0, $buf.Length)
[System.Text.Encoding]::UTF8.GetString($buf, 0, $n)   # +PONG
$tcp.Close()
```

- [ ] **Step 6: Commit**

```bash
git add src/main/java/com/redis/RedisServer.java \
        src/test/java/com/redis/RedisServerIntegrationTest.java
git commit -m "feat: add RedisServer with virtual threads and integration tests"
```
