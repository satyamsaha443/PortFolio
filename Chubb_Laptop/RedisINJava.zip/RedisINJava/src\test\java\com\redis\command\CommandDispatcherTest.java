package com.redis.command;

import com.redis.protocol.RespWriter;
import com.redis.storage.InMemoryStore;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class CommandDispatcherTest {
    private InMemoryStore store;
    private CommandDispatcher dispatcher;

    @BeforeEach
    void setUp() {
        store = new InMemoryStore();
        dispatcher = new CommandDispatcher(store);
    }

    private String dispatch(Command command) throws IOException {
        var out = new ByteArrayOutputStream();
        dispatcher.dispatch(command, new RespWriter(out));
        return out.toString(StandardCharsets.UTF_8);
    }

    @Test
    void pingReturnsPong() throws IOException {
        assertEquals("+PONG\r\n", dispatch(new Command("PING", List.of())));
    }

    @Test
    void setStoresValueAndReturnsOk() throws IOException {
        assertEquals("+OK\r\n", dispatch(new Command("SET", List.of("key", "value"))));
        assertEquals("value", store.get("key").orElseThrow());
    }

    @Test
    void getReturnsStoredValue() throws IOException {
        store.set("greeting", "hello");
        assertEquals("$5\r\nhello\r\n", dispatch(new Command("GET", List.of("greeting"))));
    }

    @Test
    void getMissingKeyReturnsNil() throws IOException {
        assertEquals("$-1\r\n", dispatch(new Command("GET", List.of("missing"))));
    }

    @Test
    void setWithMissingValueReturnsError() throws IOException {
        String response = dispatch(new Command("SET", List.of("key")));
        assertTrue(response.startsWith("-ERR"));
        assertTrue(response.contains("set"));
    }

    @Test
    void unknownCommandReturnsError() throws IOException {
        String response = dispatch(new Command("HGET", List.of("key", "field")));
        assertTrue(response.startsWith("-ERR"));
        assertTrue(response.contains("hget"));
    }
}
