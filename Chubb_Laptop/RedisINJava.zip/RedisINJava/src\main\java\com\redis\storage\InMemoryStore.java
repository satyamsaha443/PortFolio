package com.redis.storage;

import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;

public class InMemoryStore {
    private final ConcurrentHashMap<String, String> data = new ConcurrentHashMap<>();

    public void set(String key, String value) {
        data.put(key, value);
    }

    public Optional<String> get(String key) {
        return Optional.ofNullable(data.get(key));
    }
}
