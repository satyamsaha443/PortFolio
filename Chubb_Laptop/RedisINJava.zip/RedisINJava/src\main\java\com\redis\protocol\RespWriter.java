package com.redis.protocol;

import java.io.IOException;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

public class RespWriter {
    private final OutputStream out;

    public RespWriter(OutputStream out) {
        this.out = out;
    }

    public void writeSimpleString(String value) throws IOException {
        write("+" + value + "\r\n");
    }

    public void writeBulkString(String value) throws IOException {
        byte[] bytes = value.getBytes(StandardCharsets.UTF_8);
        write("$" + bytes.length + "\r\n");
        out.write(bytes);
        write("\r\n");
    }

    public void writeNil() throws IOException {
        write("$-1\r\n");
    }

    public void writeError(String message) throws IOException {
        write("-ERR " + message + "\r\n");
    }

    private void write(String text) throws IOException {
        out.write(text.getBytes(StandardCharsets.UTF_8));
        out.flush();
    }
}
