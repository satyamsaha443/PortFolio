# Redis Clone in Java — Design Spec

**Date:** 2026-08-26  
**Author:** Satyam Saha  
**Status:** Approved

---

## Overview

A simplified Redis clone built in Java 21 using Maven. Supports the PING, SET, and GET commands over TCP sockets using the real Redis wire protocol (RESP). Designed as a learning project with clean, production-style layered architecture that can be extended incrementally.

---

## Decisions

| Decision | Choice | Rationale |
|---|---|---|
| Java version | Java 21 LTS | Virtual Threads for scalable thread-per-client without NIO complexity |
| Build tool | Maven | Standard enterprise Java build tool |
| Concurrency model | Virtual thread per client | Simple mental model, scales to thousands of connections |
| Wire protocol | RESP (Redis Serialization Protocol) | Real `redis-cli` and Jedis clients can connect |
| Architecture | Layered pipeline | Clean separation; each layer testable in isolation |
| Storage | `ConcurrentHashMap<String, String>` | Thread-safe for individual operations; no external dependency |

---

## Project Structure

```
redis-java/
├── pom.xml
└── src/
    ├── main/
    │   └── java/
    │       └── com/redis/
    │           ├── RedisServer.java
    │           ├── ClientHandler.java
    │           ├── protocol/
    │           │   ├── RespParser.java
    │           │   ├── RespWriter.java
    │           │   └── RespException.java
    │           ├── command/
    │           │   ├── Command.java
    │           │   └── CommandDispatcher.java
    │           └── storage/
    │               └── InMemoryStore.java
    └── test/
        └── java/
            └── com/redis/
                ├── protocol/
                │   └── RespParserTest.java
                ├── command/
                │   └── CommandDispatcherTest.java
                └── RedisServerIntegrationTest.java
```

---

## Architecture

### Data Flow

```
Client (redis-cli / Jedis / telnet)
   │
   │  TCP bytes (RESP format)
   ▼
RespParser.parse()
   │
   │  Command record (name + args)
   ▼
CommandDispatcher.dispatch()
   │
   ├──► InMemoryStore.set() / get()
   │
   │  String response value
   ▼
RespWriter.write*()
   │
   │  TCP bytes (RESP format)
   ▼
Client
```

### Thread Model

`RedisServer` runs a single accept loop on the main thread. Each accepted `Socket` is submitted to `Executors.newVirtualThreadPerTaskExecutor()`. Virtual threads (Project Loom, GA in Java 21) are lightweight (~1 KB stack vs ~1 MB for platform threads), so a thread-per-client model scales to tens of thousands of concurrent connections without NIO complexity.

---

## Component Responsibilities

### `RedisServer`
- Entry point (`main`)
- Binds `ServerSocket` on port 6379 (configurable via system property `redis.port`)
- Creates virtual-thread executor
- Accept loop: `accept()` → `executor.submit(new ClientHandler(socket))`
- Shuts down executor on JVM shutdown hook

### `ClientHandler implements Runnable`
- Owns the full lifecycle of one client connection
- Constructor: `ClientHandler(Socket socket, CommandDispatcher dispatcher)`
- `run()`: loop of parse → dispatch → write until `IOException` (client disconnect)
- Closes socket in `finally` block regardless of exit reason

### `RespParser`
- Stateless; constructed with an `InputStream`
- `List<String> parse()` — reads one complete RESP command, returns tokens
- Handles: arrays (`*`), bulk strings (`$`), inline commands (bare `PING`)
- Throws `RespException` (checked) on malformed input

### `RespWriter`
- Stateless; constructed with an `OutputStream`
- `writeSimpleString(String)` → `+text\r\n`
- `writeBulkString(String)` → `$len\r\ndata\r\n`
- `writeNil()` → `$-1\r\n`
- `writeError(String)` → `-ERR message\r\n`
- Always flushes after write

### `Command`
- Java `record`: `record Command(String name, List<String> args)`
- Immutable; no logic

### `CommandDispatcher`
- Constructor: `CommandDispatcher(InMemoryStore store)`
- `void dispatch(Command command, RespWriter writer)` — routes command, calls the appropriate `RespWriter` method to encode and send the response directly
- Routes on `command.name().toUpperCase()`:
  - `PING` → `writer.writeSimpleString("PONG")`
  - `SET key value` → store.set; `writer.writeSimpleString("OK")`
  - `GET key` → store.get → `writer.writeBulkString(value)` or `writer.writeNil()`
  - wrong arg count → `writer.writeError("wrong number of arguments for 'X' command")`
  - unknown → `writer.writeError("unknown command 'X'")`
- `RespWriter` is the single point of encoding — `ClientHandler` never writes raw bytes directly

### `InMemoryStore`
- Wraps `ConcurrentHashMap<String, String>`
- `void set(String key, String value)`
- `Optional<String> get(String key)`
- Thread-safe: each method is a single atomic map operation

### `RespException`
- Checked exception thrown by `RespParser`
- Message describes the protocol violation

---

## RESP Protocol Reference

RESP is a line-based protocol where each message starts with a type prefix byte:

| Prefix | Type | Example |
|---|---|---|
| `+` | Simple string | `+OK\r\n` |
| `-` | Error | `-ERR unknown command\r\n` |
| `:` | Integer | `:42\r\n` |
| `$` | Bulk string | `$3\r\nfoo\r\n` |
| `*` | Array | `*2\r\n$3\r\nGET\r\n$3\r\nfoo\r\n` |

A `SET foo bar` command arrives as:
```
*3\r\n$3\r\nSET\r\n$3\r\nfoo\r\n$3\r\nbar\r\n
```

A `GET` response for an existing key `foo` with value `bar`:
```
$3\r\nbar\r\n
```

A `GET` response for a missing key:
```
$-1\r\n
```

---

## Error Handling

| Scenario | Handler | Response |
|---|---|---|
| Malformed RESP bytes | `RespParser` throws `RespException`; `ClientHandler` catches | `-ERR bad protocol\r\n` |
| Wrong arg count (SET with 1 arg) | `CommandDispatcher` validates args | `-ERR wrong number of arguments\r\n` |
| Unknown command | `CommandDispatcher` default case | `-ERR unknown command 'X'\r\n` |
| Client disconnects | `IOException` in `ClientHandler.run()`; exits loop silently | Socket closed in `finally` |

---

## Testing Plan

### Unit Tests
- `RespParserTest` — feed raw byte arrays, assert parsed token lists; test malformed input throws `RespException`
- `CommandDispatcherTest` — construct with a real `InMemoryStore`, assert responses for PING/SET/GET/unknown

### Integration Tests
- `RedisServerIntegrationTest` — starts server on a random port in `@BeforeAll`, connects via raw socket or Jedis client, fires commands, asserts RESP responses. Stops server in `@AfterAll`.

### Manual Testing
```bash
# Start server
mvn compile exec:java -Dexec.mainClass=com.redis.RedisServer

# Test with redis-cli (if installed)
redis-cli ping
redis-cli set name Satyam
redis-cli get name

# Test with netcat (no redis-cli needed)
echo -e "*1\r\n\$4\r\nPING\r\n" | nc localhost 6379
```

---

## Extension Points

The layered design makes these extensions additive — no existing class needs structural change:

| Feature | What changes |
|---|---|
| **Key expiry (TTL)** | `InMemoryStore` stores `(value, Instant expiresAt)` pairs; background virtual thread sweeps expired keys; `CommandDispatcher` adds `EXPIRE`/`TTL` cases |
| **More commands** (`DEL`, `EXISTS`, `INCR`, `APPEND`) | One new `case` in `CommandDispatcher.dispatch()` |
| **Persistence (AOF)** | `CommandDispatcher` appends each mutating command to an append-only log file before returning `+OK` |
| **Pub/Sub** | New `SubscriptionManager` class; `ClientHandler` enters a long-lived subscription mode on `SUBSCRIBE` |
| **Replication** | `RedisServer` opens outbound socket to a leader; replays leader's AOF stream into local store |
| **Password auth** | `ClientHandler` requires `AUTH` command before accepting any other command |

---

## Common Pitfalls

1. **Shared streams between threads** — each `ClientHandler` must own its own `InputStream`/`OutputStream`. Never share a `BufferedReader` across handlers.
2. **Compound operations on `ConcurrentHashMap`** — `get()`+`put()` is not atomic. Use `compute()`, `putIfAbsent()`, or `merge()` for check-then-act logic.
3. **Missing flush** — `OutputStream.write()` buffers data. Always call `flush()` after writing a response or the client hangs waiting.
4. **Forgetting `\r\n` after bulk string data** — RESP bulk strings end with `\r\n` after the data bytes, not just after the length line. Missing it breaks all clients silently.
5. **Blocking accept loop with no timeout** — `ServerSocket.accept()` blocks forever. Set `serverSocket.setSoTimeout()` or use a shutdown flag + close the socket to interrupt cleanly.
6. **Not handling inline commands** — `redis-cli` sometimes sends bare `PING\r\n` (not RESP array). The parser must handle both forms.
7. **Integer overflow on length** — RESP lengths are sent as ASCII integers. Parse with `Integer.parseInt()` and reject negative values other than `-1` (nil).
