package com.redis;

import com.redis.command.CommandDispatcher;
import com.redis.protocol.RespException;
import com.redis.protocol.RespParser;
import com.redis.protocol.RespWriter;

import java.io.IOException;
import java.net.Socket;

public class ClientHandler implements Runnable {
    private final Socket socket;
    private final CommandDispatcher dispatcher;

    public ClientHandler(Socket socket, CommandDispatcher dispatcher) {
        this.socket = socket;
        this.dispatcher = dispatcher;
    }

    @Override
    public void run() {
        try (socket) {
            var parser = new RespParser(socket.getInputStream());
            var writer = new RespWriter(socket.getOutputStream());
            while (true) {
                try {
                    var command = parser.parse();
                    dispatcher.dispatch(command, writer);
                } catch (RespException e) {
                    writer.writeError(e.getMessage());
                    return;
                }
            }
        } catch (IOException ignored) {
            // client disconnected or server shutting down — normal exit
        }
    }
}
