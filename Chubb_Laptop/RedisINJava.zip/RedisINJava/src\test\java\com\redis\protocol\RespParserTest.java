package com.redis.protocol;

import com.redis.command.Command;
import org.junit.jupiter.api.Test;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

class RespParserTest {

    private Command parse(String input) throws IOException, RespException {
        byte[] bytes = input.getBytes(StandardCharsets.UTF_8);
        return new RespParser(new ByteArrayInputStream(bytes)).parse();
    }

    @Test
    void parsesArrayPing() throws Exception {
        Command cmd = parse("*1\r\n$4\r\nPING\r\n");
        assertEquals("PING", cmd.name());
        assertTrue(cmd.args().isEmpty());
    }

    @Test
    void parsesSet() throws Exception {
        Command cmd = parse("*3\r\n$3\r\nSET\r\n$3\r\nfoo\r\n$3\r\nbar\r\n");
        assertEquals("SET", cmd.name());
        assertEquals(List.of("foo", "bar"), cmd.args());
    }

    @Test
    void parsesGet() throws Exception {
        Command cmd = parse("*2\r\n$3\r\nGET\r\n$3\r\nfoo\r\n");
        assertEquals("GET", cmd.name());
        assertEquals(List.of("foo"), cmd.args());
    }

    @Test
    void parsesInlinePing() throws Exception {
        Command cmd = parse("PING\r\n");
        assertEquals("PING", cmd.name());
        assertTrue(cmd.args().isEmpty());
    }

    @Test
    void normalizesCommandNameToUpperCase() throws Exception {
        Command cmd = parse("*1\r\n$4\r\nping\r\n");
        assertEquals("PING", cmd.name());
    }

    @Test
    void throwsRespExceptionOnInvalidArrayLength() {
        assertThrows(RespException.class, () -> parse("*abc\r\n$4\r\nPING\r\n"));
    }

    @Test
    void throwsRespExceptionOnMissingBulkStringPrefix() {
        assertThrows(RespException.class, () -> parse("*1\r\nfoo\r\n"));
    }

    @Test
    void throwsIOExceptionOnEmptyStream() {
        assertThrows(IOException.class,
            () -> new RespParser(new ByteArrayInputStream(new byte[0])).parse());
    }
}
