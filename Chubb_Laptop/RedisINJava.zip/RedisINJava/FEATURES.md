# Redis Clone in Java — Features & Technical Details

## What Is This?

A from-scratch Redis-compatible server written in Java 17. It speaks the real **RESP (Redis Serialization Protocol)** — the same wire format the official Redis server uses — which means any Redis client library (Jedis, Lettuce, redis-cli) can connect to it without modification.

This is not a toy key-value map wrapped in a socket loop. Every layer is cleanly separated, independently tested, and designed the way a real production server would be structured.

---

## Supported Commands

| Command | Syntax | Description |
|---|---|---|
| `PING` | `PING` | Health check — returns `PONG` |
| `SET` | `SET key value` | Store a string value under a key |
| `GET` | `GET key` | Retrieve a value, or nil if absent |

---

## What Makes It Stand Out

### 1. Real RESP Protocol — Not a Text Hack

Most Redis-clone tutorials use a simple line-based protocol (`SET foo bar\n`). This server speaks **actual RESP**, the same binary-safe protocol Redis uses in production.

That means:

- **`redis-cli` connects and works out of the box** — no adapter, no translation layer
- **Jedis, Lettuce, or any Java Redis client** can connect directly
- The parser handles both RESP array frames (`*3\r\n$3\r\nSET\r\n...`) and inline commands (`PING\r\n`) — just like the real Redis does

### 2. Thread-Per-Client with a Cached Thread Pool

Each accepted TCP connection gets its own dedicated thread from a `CachedThreadPool`. The threading model is simple to reason about: one connection = one thread = one parse→dispatch loop. No shared state between connections except the store itself.

The `InMemoryStore` uses `ConcurrentHashMap` which handles concurrent reads and writes safely without any manual locking.

### 3. Clean Layered Architecture

The code is split into four layers, each with a single responsibility:

```
[Network]     RedisServer       — accepts connections, manages thread pool
[Transport]   ClientHandler     — owns one socket's full lifecycle
[Protocol]    RespParser        — bytes → Command
              RespWriter        — response → bytes
[Application] CommandDispatcher — routes Command → storage → response
[Storage]     InMemoryStore     — ConcurrentHashMap wrapper
```

Each layer only talks to the layer directly next to it. `RespWriter` is the **single point of byte encoding** in the entire system — no other class writes raw bytes to the socket.

### 4. 27 Tests Across 6 Test Classes

Every layer is tested in isolation — no network needed for unit tests:

| Test Class | What It Tests | Tests |
|---|---|---|
| `RespParserTest` | RESP array frames, inline commands, malformed input | 8 |
| `RespWriterTest` | Every RESP encoding: `+`, `$`, `$-1`, `-ERR` | 4 |
| `CommandDispatcherTest` | All command paths including error cases | 6 |
| `InMemoryStoreTest` | Set, get, overwrite | 3 |
| `CommandTest` | Command record construction | 2 |
| `RedisServerIntegrationTest` | Full end-to-end with a real Jedis client | 4 |

The integration test spins up the actual server on port 16379 and connects with Jedis — a real Redis client library. It tests `PING`, `SET`/`GET`, missing-key nil, and two simultaneous clients sharing the same store.

### 5. Proper Connection Lifecycle Management

- Sockets are closed using **try-with-resources** — the connection is always cleaned up regardless of how the loop exits (client disconnect, protocol error, or exception)
- On a **protocol error** (malformed RESP frame), the server sends a clean `-ERR` response and closes the connection — it does not try to keep reading from a desynchronised stream
- The `ServerSocket` uses `SO_REUSEADDR` so the server can restart immediately without waiting for the OS to release the port from `TIME_WAIT`

### 6. Java Record for Commands

The `Command` type is a Java **record** — immutable by definition, no boilerplate:

```java
public record Command(String name, List<String> args) {}
```

This is idiomatic modern Java (17+). Immutability means a `Command` object can be safely read from multiple threads without any synchronisation.

---

## Architecture Deep-Dive

### RESP Protocol

RESP (REdis Serialization Protocol) encodes every message with a single-byte type prefix:

```
+ Simple string    →  +PONG\r\n
- Error            →  -ERR unknown command 'x'\r\n
$ Bulk string      →  $5\r\nhello\r\n
$ Nil              →  $-1\r\n
* Array            →  *2\r\n$3\r\nGET\r\n$3\r\nfoo\r\n
```

A `SET name Satyam` command arrives from the client as:

```
*3\r\n$3\r\nSET\r\n$4\r\nname\r\n$5\r\nSatyam\r\n
```

`RespParser` reads this and produces `Command("SET", ["name", "Satyam"])`. `CommandDispatcher` routes it, `InMemoryStore` stores it, and `RespWriter` sends back `+OK\r\n`.

### Request Lifecycle (one `SET` command)

```
Client (redis-cli)
  │ sends: *3\r\n$3\r\nSET\r\n$4\r\nname\r\n$5\r\nSatyam\r\n
  ▼
ClientHandler.run()
  ├── RespParser.parse()
  │     reads *3 → loop 3x parseBulkString()
  │     returns Command("SET", ["name", "Satyam"])
  ├── CommandDispatcher.dispatch(command, writer)
  │     case "SET" → handleSet()
  │       store.set("name", "Satyam")
  │       writer.writeSimpleString("OK")
  │         writes: +OK\r\n  →  flushes  →  sent to client
  └── loop back to parser.parse()
```

### Thread Safety

- `ConcurrentHashMap` handles concurrent `set()` and `get()` calls safely
- Each `ClientHandler` owns its own `RespParser` and `RespWriter` — no shared stream objects between threads
- `RedisServer.serverSocket` is declared `volatile` so visibility is guaranteed across the main accept thread and the thread that calls `stop()`

---

## File-by-File Reference

| File | Lines | What It Does |
|---|---|---|
| `RedisServer.java` | ~50 | Main entry point. Binds port, accept loop, thread pool |
| `ClientHandler.java` | ~35 | One client = one thread. parse → dispatch → loop |
| `RespParser.java` | ~80 | Reads RESP frames from InputStream into Command records |
| `RespWriter.java` | ~45 | Encodes responses into RESP bytes, flushes after each write |
| `RespException.java` | ~8 | Checked exception for protocol violations |
| `Command.java` | ~5 | Immutable record: name + args |
| `CommandDispatcher.java` | ~45 | Routes commands, validates args, calls store and writer |
| `InMemoryStore.java` | ~20 | ConcurrentHashMap with set() / get() |

Total production code: **~290 lines**. Total test code: **~200 lines**.

---

## What Can Be Added Next

The layered design makes extensions additive — no existing class needs structural changes:

| Feature | Effort | What Changes |
|---|---|---|
| `DEL`, `EXISTS`, `INCR` | Low | One new `case` in `CommandDispatcher` per command |
| `PING message` (echo form) | Low | Check `args` in `CommandDispatcher` PING case |
| Key expiry (TTL / EXPIRE) | Medium | `InMemoryStore` stores `(value, Instant)` pairs + background sweep thread |
| Persistence (AOF) | Medium | `CommandDispatcher` appends each write to a log file before returning `+OK` |
| Pub/Sub | High | New `SubscriptionManager`; `ClientHandler` enters subscription mode on `SUBSCRIBE` |
| Password auth | Low | `ClientHandler` requires `AUTH` before accepting any other command |
| Replication | High | `RedisServer` opens outbound socket to leader; replays AOF stream into local store |

---

## Design Decisions

| Decision | Choice | Why |
|---|---|---|
| Wire protocol | Full RESP | Real Redis clients (redis-cli, Jedis) work without adaptation |
| Thread model | Thread-per-client via CachedThreadPool | Simple to reason about; no NIO/selector complexity |
| Storage | ConcurrentHashMap | Thread-safe for individual operations; no external dependency |
| Command type | Java record | Immutable by definition; no boilerplate equals/hashCode |
| Encoding boundary | RespWriter only | One place that produces bytes = one place to fix encoding bugs |
| Error on protocol violation | Close connection | Prevents stream desynchronisation from leftover buffered bytes |
| SO_REUSEADDR | Enabled | Server can restart immediately without 60s TIME_WAIT delay |
