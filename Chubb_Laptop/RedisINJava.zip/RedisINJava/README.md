# Redis Clone in Java

A simplified Redis server built in Java 17 using Maven. Supports real Redis clients (`redis-cli`, Jedis) via the RESP wire protocol over TCP.

## What it supports

| Command | Example | Response |
|---|---|---|
| `PING` | `PING` | `+PONG` |
| `SET key value` | `SET name Satyam` | `+OK` |
| `GET key` | `GET name` | `"Satyam"` or `(nil)` |

---

## Prerequisites

You need **Java 17+** and **Maven 3.6+** installed.

Check:
```bash
java -version   # must be 17 or higher
mvn -version    # must be 3.6 or higher
```

If not installed:
- Java 17: https://adoptium.net/temurin/releases/?version=17
- Maven: https://maven.apache.org/download.cgi

---

## Step 1 — Build the project

Open a terminal in the project folder (where `pom.xml` is) and run:

```bash
mvn compile
```

Expected output ends with:
```
BUILD SUCCESS
```

---

## Step 2 — Run the server

```bash
mvn exec:java
```

Expected output:
```
Redis server started on port 6379
```

Leave this terminal open. The server is now listening on port **6379**.

---

## Step 3 — Test it

### Option A: With `redis-cli` (if you have Redis installed)

Open a **second terminal** and run:

```bash
redis-cli ping
# PONG

redis-cli set name Satyam
# OK

redis-cli get name
# "Satyam"

redis-cli get missing
# (nil)

redis-cli hget x y
# (error) ERR unknown command 'hget'
```

### Option B: Without any Redis tools (PowerShell)

Open a **second terminal** (PowerShell) and run:

```powershell
$tcp = New-Object System.Net.Sockets.TcpClient("localhost", 6379)
$stream = $tcp.GetStream()
$msg = [System.Text.Encoding]::UTF8.GetBytes("*1`r`n`$4`r`nPING`r`n")
$stream.Write($msg, 0, $msg.Length)
$buf = New-Object byte[] 64
$n = $stream.Read($buf, 0, $buf.Length)
[System.Text.Encoding]::UTF8.GetString($buf, 0, $n)
$tcp.Close()
# +PONG
```

### Option C: Run the automated test suite

Stop the server first (Ctrl+C in terminal 1), then:

```bash
mvn test
```

Expected output:
```
Tests run: 27, Failures: 0, Errors: 0, Skipped: 0
BUILD SUCCESS
```

---

## Step 4 — Stop the server

Press **Ctrl+C** in the terminal where the server is running.

---

## Change the port (optional)

Default port is 6379. To use a different port:

```bash
mvn exec:java -Dexec.args="" -Dredis.port=7379
```

---

## Project structure

```
src/main/java/com/redis/
├── RedisServer.java          ← Entry point (main method)
├── ClientHandler.java        ← Handles one client connection
├── protocol/
│   ├── RespParser.java       ← Reads RESP bytes from client
│   ├── RespWriter.java       ← Writes RESP bytes to client
│   └── RespException.java    ← Protocol error exception
├── command/
│   ├── Command.java          ← Holds parsed command name + args
│   └── CommandDispatcher.java← Routes PING/SET/GET to storage
└── storage/
    └── InMemoryStore.java    ← ConcurrentHashMap key-value store
```

---

## How to extend it

### Add a new command (e.g. `DEL`)

Open `CommandDispatcher.java` and add a new `case` inside `dispatch()`:

```java
case "DEL" -> handleDel(command, writer);
```

Then add the handler method:

```java
private void handleDel(Command command, RespWriter writer) throws IOException {
    if (command.args().isEmpty()) {
        writer.writeError("wrong number of arguments for 'del' command");
        return;
    }
    // InMemoryStore would need a delete() method added
    writer.writeSimpleString("OK");
}
```

### Add key expiry (TTL)

Change `InMemoryStore` to store `(value, Instant expiresAt)` pairs. Add a background thread in `RedisServer` that sweeps expired keys every second. Add `EXPIRE` and `TTL` cases in `CommandDispatcher`.

### Add persistence (AOF)

In `CommandDispatcher`, before returning `+OK` for SET, append the command to a file:

```java
Files.writeString(Path.of("appendonly.aof"),
    "SET " + key + " " + value + "\n",
    StandardOpenOption.CREATE, StandardOpenOption.APPEND);
```

On startup, replay the file to restore state.

---

## Common issues

| Problem | Fix |
|---|---|
| `Address already in use` | Another process is on port 6379. Use `-Dredis.port=7379` to pick a different port. |
| `BUILD FAILURE` on `mvn compile` | Check `java -version` is 17+. |
| `Connection refused` | Server is not running — start it first with `mvn exec:java`. |
| SSL/certificate errors on first `mvn compile` | The project includes `.mvn/maven.config` with SSL bypass for corporate networks. If you're on a normal network, delete that file. |
