package com.redis.storage;

import org.junit.jupiter.api.Test;
import java.util.Optional;
import static org.junit.jupiter.api.Assertions.*;

class InMemoryStoreTest {

    @Test
    void getMissingKeyReturnsEmpty() {
        var store = new InMemoryStore();
        assertEquals(Optional.empty(), store.get("missing"));
    }

    @Test
    void setThenGetReturnsValue() {
        var store = new InMemoryStore();
        store.set("name", "Satyam");
        assertEquals(Optional.of("Satyam"), store.get("name"));
    }

    @Test
    void setOverwritesExistingKey() {
        var store = new InMemoryStore();
        store.set("key", "first");
        store.set("key", "second");
        assertEquals(Optional.of("second"), store.get("key"));
    }
}
