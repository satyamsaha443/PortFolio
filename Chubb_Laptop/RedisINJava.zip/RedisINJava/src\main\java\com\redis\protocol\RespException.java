package com.redis.protocol;

public class RespException extends Exception {
    public RespException(String message) {
        super(message);
    }
}
