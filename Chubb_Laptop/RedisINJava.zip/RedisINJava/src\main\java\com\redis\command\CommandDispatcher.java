package com.redis.command;

import com.redis.protocol.RespWriter;
import com.redis.storage.InMemoryStore;

import java.io.IOException;

public class CommandDispatcher {
    private final InMemoryStore store;

    public CommandDispatcher(InMemoryStore store) {
        this.store = store;
    }

    public void dispatch(Command command, RespWriter writer) throws IOException {
        switch (command.name()) {
            case "PING" -> writer.writeSimpleString("PONG");
            case "SET"  -> handleSet(command, writer);
            case "GET"  -> handleGet(command, writer);
            default     -> writer.writeError("unknown command '" + command.name().toLowerCase() + "'");
        }
    }

    private void handleSet(Command command, RespWriter writer) throws IOException {
        if (command.args().size() < 2) {
            writer.writeError("wrong number of arguments for 'set' command");
            return;
        }
        store.set(command.args().get(0), command.args().get(1));
        writer.writeSimpleString("OK");
    }

    private void handleGet(Command command, RespWriter writer) throws IOException {
        if (command.args().isEmpty()) {
            writer.writeError("wrong number of arguments for 'get' command");
            return;
        }
        var value = store.get(command.args().get(0));
        if (value.isPresent()) {
            writer.writeBulkString(value.get());
        } else {
            writer.writeNil();
        }
    }
}
