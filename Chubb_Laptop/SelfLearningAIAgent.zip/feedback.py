import json
import uuid
from collections import defaultdict
from datetime import datetime
from pathlib import Path


class FeedbackTracker:
    def __init__(self, log_path: str = "feedback_log.json"):
        self._log_path = Path(log_path)
        self._log: list[dict] = self._load_log()
        self._counts: dict[str, dict] = defaultdict(lambda: {"confirmed": 0, "denied": 0})
        self._rebuild_counts()

    def _load_log(self) -> list[dict]:
        if not self._log_path.exists():
            return []
        try:
            return json.loads(self._log_path.read_text())
        except json.JSONDecodeError:
            print(f"Warning: {self._log_path} is corrupt — starting with empty feedback log.")
            return []

    def _rebuild_counts(self) -> None:
        for entry in self._log:
            outcome = entry.get("outcome")
            if outcome in ("confirmed", "denied"):
                self._counts[entry["rule_id"]][outcome] += 1

    def _save_log(self) -> None:
        tmp = self._log_path.with_suffix(".tmp")
        tmp.write_text(json.dumps(self._log, indent=2))
        tmp.replace(self._log_path)

    def record(self, rule_id: str, profile_id: str, outcome: str) -> str:
        entry_id = str(uuid.uuid4())[:8]
        entry = {
            "id": entry_id,
            "rule_id": rule_id,
            "profile_id": profile_id,
            "outcome": outcome,
            "resolved": outcome != "pending",
            "timestamp": datetime.now().isoformat(timespec="seconds"),
        }
        self._log.append(entry)
        self._save_log()
        if outcome in ("confirmed", "denied"):
            self._counts[rule_id][outcome] += 1
        return entry_id

    def load_pending(self) -> list[dict]:
        return [e for e in self._log if e["outcome"] == "pending"]

    def resolve(self, entry_id: str, outcome: str) -> None:
        for entry in self._log:
            if entry["id"] == entry_id:
                entry["outcome"] = outcome
                entry["resolved"] = True
                if outcome in ("confirmed", "denied"):
                    self._counts[entry["rule_id"]][outcome] += 1
                break
        self._save_log()

    def success_rate(self, rule_id: str) -> float | None:
        counts = self._counts.get(rule_id)
        if not counts:
            return None
        total = counts["confirmed"] + counts["denied"]
        if total == 0:
            return None
        return counts["confirmed"] / total
