import re
import sys
import yaml
from pathlib import Path
from models import Finding


class RulesEngine:
    def __init__(self, rules_path: str = "rules.yaml"):
        path = Path(rules_path)
        if not path.exists():
            print(f"Error: rules file not found: {rules_path}", file=sys.stderr)
            sys.exit(1)
        try:
            data = yaml.safe_load(path.read_text())
        except yaml.YAMLError as e:
            print(f"Error: malformed rules file {rules_path}: {e}", file=sys.stderr)
            sys.exit(1)
        if not isinstance(data, dict):
            print(f"Error: rules file {rules_path} must be a YAML mapping", file=sys.stderr)
            sys.exit(1)
        self._rules: list[dict] = data.get("rules", [])
        self._validate_regex_rules()

    def _validate_regex_rules(self) -> None:
        for rule in self._rules:
            if rule.get("check") in ("regex_match", "regex_no_match"):
                pattern = rule.get("params", {}).get("pattern", "")
                try:
                    re.compile(pattern)
                except re.error as e:
                    print(f"Error: bad regex in rule {rule.get('id')!r}: {e}", file=sys.stderr)
                    sys.exit(1)

    def apply(self, profiles: list[dict]) -> list[Finding]:
        findings = []
        for profile in profiles:
            for rule in self._rules:
                if not self._matches(rule, profile):
                    continue
                if not self._check_fails(rule, profile):
                    continue
                line_number: int | None = None
                if rule["check"] == "regex_match":
                    pattern = rule.get("params", {}).get("pattern", "")
                    for i, line in enumerate(profile.get("content", "").splitlines(), start=1):
                        if re.search(pattern, line):
                            line_number = i
                            break
                findings.append(Finding(
                    rule_id=rule["id"],
                    profile_id=profile["id"],
                    severity=rule["severity"],
                    message=rule["message"],
                    fix_draft=rule["fix_template"],
                    line_number=line_number,
                ))
        return findings

    def _matches(self, rule: dict, profile: dict) -> bool:
        pattern = rule.get("applies_to", "*")
        if pattern == "*":
            return True
        field = rule.get("match_field", "id")
        value = str(profile.get(field, ""))
        if field == "id":
            return value.startswith(pattern)
        return value == pattern

    def _check_fails(self, rule: dict, profile: dict) -> bool:
        check = rule["check"]
        params = rule.get("params", {})
        if check == "has_metadata_key":
            return params["key"] not in profile.get("metadata_keys", [])
        if check == "has_element":
            return params["element"] not in profile.get("elements", [])
        if check == "regex_match":
            return bool(re.search(params["pattern"], profile.get("content", "")))
        if check == "regex_no_match":
            return not bool(re.search(params["pattern"], profile.get("content", "")))
        if check == "yaml_path_missing":
            return self._get_nested(profile.get("raw", {}), params["path"]) is None
        if check == "yaml_value_equals":
            return self._get_nested(profile.get("raw", {}), params["path"]) == params["value"]
        if check == "csv_missing_column":
            return params["column"] not in profile.get("headers", [])
        raise ValueError(f"Unknown check type: {check!r} in rule {rule.get('id')!r}")

    @staticmethod
    def _get_nested(d: dict, path: str):
        for key in path.split("."):
            if not isinstance(d, dict) or key not in d:
                return None
            d = d[key]
        return d
