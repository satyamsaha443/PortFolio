# SelfLearningAIAgent

A local, self-improving static analysis CLI. It scans your code and config files for issues, asks whether each finding was accurate, and remembers your answers — getting smarter with every run. No cloud, no API keys, no data leaves your machine.

---

## What it does

- **Scans files** across five domains: Python/JS/Go code, YAML infra (Kubernetes, GitHub Actions), CSV data quality, log files, and pip security audits
- **Auto-detects** what to scan: changed files in your git repo, a specific file, or an entire folder
- **Asks for feedback** on each finding (accurate / not accurate / skip)
- **Learns over time**: confirmed findings increase a rule's confidence score; denied findings lower it — the confidence label updates on the next run
- **Auto-fixes** confirmed findings: when you confirm a `regex_match` finding the offending line is automatically commented out in the source file
- **Blocks bad commits** via an optional pre-commit hook that runs `scan` before every `git commit`

---

## Quick setup (Mac)

**Prerequisites:** Python 3.12+ and `git`

```bash
# 1. Clone or unzip the project, then enter it
cd SelfLearningAIAgent

# 2. Create a virtual environment and activate it
python3 -m venv .venv
source .venv/bin/activate

# 3. Install dependencies
pip install -r requirements.txt

# 4. Verify everything works
pytest -q          # should print: 144 passed, 1 skipped
```

That's it. No config file needed for basic use.

---

## Usage

### Scan changed files (most common)

Run from inside any git repo. It finds all staged and unstaged changes automatically:

```bash
python main.py scan
```

### Scan a specific file

```bash
python main.py scan path/to/script.py
python main.py scan path/to/deployment.yaml
```

### Scan an entire folder

```bash
python main.py scan src/
```

### Run a specific domain directly

```bash
python main.py code-review  src/auth.py src/utils.py
python main.py infra        k8s/deployment.yaml
python main.py csv          data/export.csv
python main.py security     pip-audit.json
python main.py log-analysis app.log
```

---

## Install the pre-commit hook (optional)

Automatically scans your changed files before every `git commit`. If issues are found, the commit is blocked until you review them.

```bash
python scripts/install_hook.py
```

To bypass the hook for a single commit (e.g. when committing docs or test files):

```bash
git -c core.hooksPath="" commit -m "your message"
```

---

## How learning works

After each scan, the agent asks about each finding:

```
[LOW] [NEW RULE] src/app.py
  Rule:    debug-print
  Issue:   Debug print() found.

  Suggested fix:
    Remove the print() statement.

  Was this finding accurate? (y/n/skip):
```

- **y** — confirmed. The line is auto-commented out, and the rule's confidence goes up.
- **n** — denied. Rule confidence goes down; you'll see `[UNCERTAIN]` or `[LOW CONFIDENCE]` next time.
- **skip** — recorded as pending; asked again next run.

Confidence labels you'll see:

| Label | Meaning |
|---|---|
| `[NEW RULE]` | No history yet |
| `[CONFIRMED]` | Rule has been accurate >= 70% of the time |
| `[UNCERTAIN ?]` | Between 40–70% accurate |
| `[LOW CONFIDENCE]` | Less than 40% accurate |

Memory is stored locally in `agent_memory_<domain>.json`. Delete any of these files to reset learning for that domain.

---

## Adding or customising rules

Rules live in the `rules/` folder — one YAML file per domain. Example rule:

```yaml
rules:
  - id: no-hardcoded-secrets
    name: "Hardcoded secret pattern"
    applies_to: "*"
    check: regex_match
    params:
      pattern: "(password|secret|api_key)\\s*=\\s*['\"][^'\"]{4,}"
    severity: HIGH
    message: "Possible hardcoded secret found."
    fix_template: "Move this value to an environment variable or secrets manager."
```

**Check types:**

| Check | Fires when |
|---|---|
| `regex_match` | Pattern found in file content (also auto-fixes) |
| `regex_no_match` | Pattern is absent from file content |
| `yaml_path_missing` | A YAML key path doesn't exist |
| `yaml_value_equals` | A YAML value equals the specified value |
| `has_metadata_key` | A metadata key is missing from the profile |
| `has_element` | An XML/structural element is absent |
| `csv_missing_column` | A CSV column header is not present |

---

## Project layout

```
main.py              — CLI entry point; scan + domain dispatch
agent.py             — Learning loop: analyze → feedback → memory update
rules.py             — Rule evaluation engine
tools.py             — File parsers and the apply_fix tool
detector.py          — Maps file extensions to domains
models.py            — Finding dataclass
memory.py            — Long-term confidence storage (JSON)
feedback.py          — Feedback log (JSON)
rules/               — YAML rule definitions (one per domain)
scripts/
  install_hook.py    — Installs the git pre-commit hook
tests/               — 144 pytest tests
```

---

## Supported file types

| Extension | Domain |
|---|---|
| `.py`, `.js`, `.ts`, `.go`, `.rb`, `.java`, `.sh` | `code-review` |
| `.yaml`, `.yml` | `infra` |
| `.log` | `log-analysis` |
| `.csv` | `csv` |
| `pip-audit.json`, `audit.json` | `security` |
