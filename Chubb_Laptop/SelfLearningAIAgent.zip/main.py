import subprocess
import sys
from collections import defaultdict
from pathlib import Path

from agent import Agent
from detector import detect_domain
from feedback import FeedbackTracker
from memory import LongTermMemory
from rules import RulesEngine
from tools import (
    ToolRegistry,
    make_code_review_tools,
    make_csv_tools,
    make_infra_tools,
    make_security_tools,
)

DOMAINS: dict[str, tuple] = {
    "code-review":  (make_code_review_tools, "rules/code-review.yaml"),
    "infra":        (make_infra_tools,        "rules/infra.yaml"),
    "log-analysis": (make_code_review_tools,  "rules/log-analysis.yaml"),
    "csv":          (make_csv_tools,           "rules/csv.yaml"),
    "security":     (make_security_tools,      "rules/security.yaml"),
}

_EXCLUDED_DIRS = {".git", "__pycache__", "venv", ".venv", "node_modules", ".tox", "dist", "build"}


def run(
    domain: str,
    paths: list[str],
    rules_path: str | None = None,
    memory_path: str | None = None,
    feedback_path: str | None = None,
) -> bool:
    if domain not in DOMAINS:
        print(
            f"Unknown domain {domain!r}. Available: {', '.join(DOMAINS)}",
            file=sys.stderr,
        )
        sys.exit(1)

    make_tools_fn, default_rules = DOMAINS[domain]
    rules_path    = rules_path    or default_rules
    memory_path   = memory_path   or f"agent_memory_{domain}.json"
    feedback_path = feedback_path or f"feedback_log_{domain}.json"

    memory   = LongTermMemory(path=memory_path)
    feedback = FeedbackTracker(log_path=feedback_path)
    rules    = RulesEngine(rules_path=rules_path)
    tools    = ToolRegistry()
    make_tools_fn(tools)

    agent = Agent(rules=rules, tools=tools, memory=memory, feedback=feedback)
    agent.startup_reconcile()

    all_findings = []
    for path in paths:
        print(f"\nAnalyzing: {path}")
        try:
            findings = agent.analyze(path)
        except ValueError as e:
            print(f"  Error: {e}", file=sys.stderr)
            continue
        if not findings:
            print("  No issues found.")
        all_findings.extend(findings)

    if all_findings:
        agent.collect_feedback(all_findings)
    return bool(all_findings)


def _walk_folder(folder: Path) -> list[Path]:
    results = []
    for p in folder.rglob("*"):
        if p.is_file() and not any(part in _EXCLUDED_DIRS for part in p.parts):
            results.append(p)
    return results


def _git_changed_files() -> list[Path] | None:
    try:
        unstaged = subprocess.run(
            ["git", "diff", "--name-only", "HEAD"],
            capture_output=True, text=True, check=False,
        )
        staged = subprocess.run(
            ["git", "diff", "--name-only", "--cached"],
            capture_output=True, text=True, check=False,
        )
        repo_root_result = subprocess.run(
            ["git", "rev-parse", "--show-toplevel"],
            capture_output=True, text=True, check=False,
        )
    except FileNotFoundError:
        return None

    if unstaged.returncode != 0 and staged.returncode != 0:
        return None

    names = set(unstaged.stdout.splitlines()) | set(staged.stdout.splitlines())
    root = Path(repo_root_result.stdout.strip()) if repo_root_result.returncode == 0 else Path(".")
    return [root / n for n in names if n and (root / n).exists()]


def _group_by_domain(files: list[Path]) -> dict[str, list[Path]]:
    groups: dict[str, list[Path]] = defaultdict(list)
    for f in files:
        domain = detect_domain(f)
        if domain is None:
            print(f"Skipping {f.name} — no domain matched")
            continue
        groups[domain].append(f)
    return dict(groups)


def scan(target: str | None = None) -> bool:
    found_any = False

    if target is None:
        files = _git_changed_files()
        if files is None:
            print("Not in a git repo — scanning current directory instead.")
            files = _walk_folder(Path("."))
    else:
        p = Path(target)
        if p.is_file():
            domain = detect_domain(p)
            if domain is None:
                print(f"Skipping {p.name} — no domain matched")
                return False
            print(f"\n── {domain} (1 file) ──")
            return run(domain, [str(p)])
        files = _walk_folder(p)

    groups = _group_by_domain(files)

    if not groups:
        print("Nothing to scan.")
        return False

    for domain, paths in groups.items():
        print(f"\n── {domain} ({len(paths)} file{'s' if len(paths) != 1 else ''}) ──")
        if run(domain, [str(p) for p in paths]):
            found_any = True

    return found_any


if __name__ == "__main__":
    args = sys.argv[1:]

    if not args:
        print("Usage: python main.py <domain> <file1> [file2 ...]\n"
              "       python main.py scan [file_or_folder]\n"
              f"Domains: {', '.join(DOMAINS)}", file=sys.stderr)
        sys.exit(1)

    if args[0] == "scan":
        found = scan(args[1] if len(args) > 1 else None)
        if found:
            sys.exit(1)
    else:
        if len(args) < 2:
            print(f"Usage: python main.py <domain> <file1> [file2 ...]\n"
                  f"Domains: {', '.join(DOMAINS)}", file=sys.stderr)
            sys.exit(1)
        if run(args[0], args[1:]):
            sys.exit(1)
