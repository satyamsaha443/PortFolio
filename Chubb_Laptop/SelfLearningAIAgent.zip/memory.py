import json
from collections import deque
from pathlib import Path


class ShortTermMemory:
    def __init__(self, maxlen: int = 20):
        self._buffer: deque[dict] = deque(maxlen=maxlen)

    def record(self, rule_id: str, profile_id: str, confidence: float) -> None:
        self._buffer.append({
            "rule_id": rule_id,
            "profile_id": profile_id,
            "confidence": confidence,
        })

    def recent(self, n: int | None = None) -> list[dict]:
        items = list(self._buffer)
        return items[-n:] if n else items

    def clear(self) -> None:
        self._buffer.clear()


class LongTermMemory:
    def __init__(self, path: str = "agent_memory.json"):
        self._path: Path = Path(path)
        self._store: dict[str, dict] = self._load()

    def _load(self) -> dict[str, dict]:
        if not self._path.exists():
            return {}
        try:
            return json.loads(self._path.read_text())
        except json.JSONDecodeError:
            print(f"Warning: {self._path} is corrupt — starting with empty memory.")
            return {}

    def save(self, key: str, value: dict) -> None:
        self._store[key] = value
        tmp = self._path.with_suffix(".tmp")
        tmp.write_text(json.dumps(self._store, indent=2))
        tmp.replace(self._path)

    def recall(self, key: str, default: dict | None = None) -> dict | None:
        return self._store.get(key, default)

    def all(self) -> dict:
        return dict(self._store)
