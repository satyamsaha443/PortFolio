from models import Finding
from memory import LongTermMemory, ShortTermMemory
from feedback import FeedbackTracker
from rules import RulesEngine
from tools import ToolRegistry


def confidence_label(confidence: float, has_history: bool) -> str:
    if not has_history:
        return "[NEW RULE]"
    if confidence >= 0.70:
        return "[CONFIRMED]"
    if confidence >= 0.40:
        return "[UNCERTAIN ?]"
    return "[LOW CONFIDENCE]"


class Agent:
    def __init__(
        self,
        rules: RulesEngine,
        tools: ToolRegistry,
        memory: LongTermMemory,
        feedback: FeedbackTracker,
    ):
        self._rules = rules
        self._tools = tools
        self._memory = memory
        self._feedback = feedback
        self._short_term = ShortTermMemory()

    def startup_reconcile(self) -> None:
        pending = self._feedback.load_pending()
        if not pending:
            return
        print(f"\n{len(pending)} pending feedback item(s) from previous sessions:")
        for entry in pending:
            answer = input(
                f"  {entry['rule_id']} on {entry['profile_id']} — "
                f"was the fix correct? (y/n/skip): "
            ).strip().lower()
            if answer == "y":
                self._feedback.resolve(entry["id"], "confirmed")
                self._update_memory(entry["rule_id"], "confirmed")
            elif answer == "n":
                self._feedback.resolve(entry["id"], "denied")
                self._update_memory(entry["rule_id"], "denied")

    def analyze(self, xml_path: str) -> list[Finding]:
        profiles = self._tools.call("parse_xml", path=xml_path)
        raw_findings = self._rules.apply(profiles)
        scored = []
        for f in raw_findings:
            mem = self._memory.recall(f"rule:{f.rule_id}")
            f.confidence = mem["confidence"] if mem is not None else 0.5
            f.fix_draft = self._tools.call("suggest_fix", finding=f)
            self._short_term.record(f.rule_id, f.profile_id, f.confidence)
            scored.append(f)
        return scored

    def collect_feedback(self, findings: list[Finding]) -> None:
        for f in findings:
            mem = self._memory.recall(f"rule:{f.rule_id}")
            label = confidence_label(f.confidence, has_history=mem is not None)
            print(f"\n[{f.severity}] {label} {f.profile_id}")
            print(f"  Rule:    {f.rule_id}")
            print(f"  Issue:   {f.message}")
            print(f"\n  Suggested fix:\n    {f.fix_draft}")
            answer = input("\n  Was this finding accurate? (y/n/skip): ").strip().lower()
            outcome = {"y": "confirmed", "n": "denied"}.get(answer, "pending")
            self._feedback.record(f.rule_id, f.profile_id, outcome)
            if outcome in ("confirmed", "denied"):
                self._update_memory(f.rule_id, outcome)
            if outcome == "confirmed":
                if f.line_number is not None:
                    applied = self._tools.call("apply_fix", finding=f)
                    if applied:
                        print(f"  [OK] Commented out line {f.line_number} in {f.profile_id}")
                else:
                    print("  (auto-fix not available for this finding type)")

    def _update_memory(self, rule_id: str, outcome: str) -> None:
        key = f"rule:{rule_id}"
        existing = self._memory.recall(key, default={"attempts": 0, "confirmed": 0, "confidence": 0.5})
        attempts = existing["attempts"] + 1
        confirmed = existing["confirmed"] + (1 if outcome == "confirmed" else 0)
        self._memory.save(key, {
            "attempts": attempts,
            "confirmed": confirmed,
            "confidence": confirmed / attempts,
        })
