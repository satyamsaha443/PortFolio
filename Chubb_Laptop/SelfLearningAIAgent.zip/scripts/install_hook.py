import stat
import sys
from pathlib import Path

HOOK_CONTENT = "#!/bin/sh\npython main.py scan\n"


def _hooks_dir() -> Path:
    return Path(".git") / "hooks"


def install() -> None:
    hooks = _hooks_dir()
    if not hooks.exists():
        sys.stderr.write("Error: .git/hooks not found. Run from the project root.\n")
        sys.exit(1)

    hook_path = hooks / "pre-commit"

    if hook_path.exists():
        sys.stdout.write(f"Warning: {hook_path} already exists.\n")
        answer = input("Overwrite? [y/N] ").strip().lower()
        if answer != "y":
            sys.stdout.write("Aborted.\n")
            return

    hook_path.write_text(HOOK_CONTENT)
    hook_path.chmod(hook_path.stat().st_mode | stat.S_IEXEC | stat.S_IXGRP | stat.S_IXOTH)
    sys.stdout.write(f"Installed pre-commit hook at {hook_path}\n")
    sys.stdout.write("Run 'git commit --no-verify' to bypass when needed.\n")


if __name__ == "__main__":
    install()
