import csv as _csv
import json as _json
import sys
from collections.abc import Callable
from pathlib import Path
from typing import Any

import yaml as _yaml

from models import Finding


class ToolRegistry:
    def __init__(self):
        self._tools: dict[str, dict] = {}

    def register(self, name: str, fn: Callable, description: str = "") -> None:
        self._tools[name] = {"fn": fn, "description": description}

    def call(self, name: str, **kwargs) -> Any:
        if name not in self._tools:
            raise ValueError(f"Unknown tool: '{name}'. Available: {list(self._tools)}")
        return self._tools[name]["fn"](**kwargs)

    def available(self) -> list[str]:
        return list(self._tools)

    def describe(self) -> dict[str, str]:
        return {name: meta["description"] for name, meta in self._tools.items()}


def _suggest_fix(finding: Finding) -> str:
    return finding.fix_draft.replace("{profile_id}", finding.profile_id)


_COMMENT_PREFIX: dict[str, str] = {
    ".py":   "# ",
    ".sh":   "# ",
    ".yaml": "# ",
    ".yml":  "# ",
    ".js":   "// ",
    ".ts":   "// ",
    ".go":   "// ",
    ".java": "// ",
}


def _apply_fix(finding: Finding) -> bool:
    suffix = Path(finding.profile_id).suffix.lower()
    prefix = _COMMENT_PREFIX.get(suffix)
    if prefix is None:
        print(f"  (auto-fix not available for {suffix or 'unknown'} files)")
        return False
    if finding.line_number is None:
        print("  (auto-fix not available — no line number)", file=sys.stderr)
        return False

    path = Path(finding.profile_id)
    try:
        lines = path.read_text(encoding="utf-8").splitlines(keepends=True)
        lines[finding.line_number - 1] = prefix + lines[finding.line_number - 1]
    except FileNotFoundError:
        print(f"  Warning: cannot apply fix — {finding.profile_id} not found", file=sys.stderr)
        return False
    except IndexError:
        print(f"  Warning: cannot apply fix — line {finding.line_number} out of range", file=sys.stderr)
        return False

    tmp = path.with_suffix(path.suffix + ".tmp")
    try:
        tmp.write_text("".join(lines), encoding="utf-8")
        tmp.replace(path)
    except OSError as e:
        print(f"  Warning: cannot write fix to {finding.profile_id}: {e}", file=sys.stderr)
        try:
            tmp.unlink(missing_ok=True)
        except OSError:
            pass
        return False
    return True


def _parse_file(path: str) -> list[dict]:
    p = Path(path)
    try:
        content = p.read_text(encoding="utf-8", errors="replace")
    except OSError as e:
        print(f"Warning: cannot read {path}: {e}", file=sys.stderr)
        return []
    return [{
        "id": path,
        "extension": p.suffix.lstrip("."),
        "lines": content.split("\n"),
        "content": content,
    }]


def make_code_review_tools(registry: ToolRegistry) -> None:
    registry.register("parse_xml",   _parse_file,  "Parse a source file into a code-review profile")
    registry.register("suggest_fix", _suggest_fix, "Render fix_draft template for a Finding")
    registry.register("apply_fix",   _apply_fix,   "Comment out the offending line in the source file")


def _parse_yaml_infra(path: str) -> list[dict]:
    p = Path(path)
    try:
        content = p.read_text(encoding="utf-8", errors="replace")
        docs = list(_yaml.safe_load_all(content))
    except OSError as e:
        print(f"Warning: cannot read {path}: {e}", file=sys.stderr)
        return []
    except _yaml.YAMLError as e:
        print(f"Warning: YAML parse error in {path}: {e}", file=sys.stderr)
        return []

    normalised = path.replace("\\", "/")
    source = "github-actions" if ".github/workflows" in normalised else "kubernetes"

    profiles = []
    for doc in docs:
        if not isinstance(doc, dict):
            continue
        if source == "github-actions":
            kind = doc.get("kind", "Workflow")
            name = doc.get("name", "unnamed")
        else:
            kind = doc.get("kind", "Unknown")
            name = doc.get("metadata", {}).get("name", "unnamed")
        profiles.append({
            "id": f"{path}::{kind}/{name}",
            "kind": kind,
            "source": source,
            "content": _yaml.dump(doc, default_flow_style=False),
            "raw": doc,
        })
    return profiles


def make_infra_tools(registry: ToolRegistry) -> None:
    registry.register("parse_xml",   _parse_yaml_infra, "Parse a YAML infra file into profiles")
    registry.register("suggest_fix", _suggest_fix,      "Render fix_draft template for a Finding")
    registry.register("apply_fix",   _apply_fix,        "Comment out the offending line in the source file")


def _parse_csv(path: str) -> list[dict]:
    p = Path(path)
    try:
        content = p.read_text(encoding="utf-8", errors="replace")
    except OSError as e:
        print(f"Warning: cannot read {path}: {e}", file=sys.stderr)
        return []
    try:
        reader = _csv.DictReader(content.splitlines())
        headers = list(reader.fieldnames or [])
        rows = list(reader)
    except _csv.Error as e:
        print(f"Warning: CSV parse error in {path}: {e}", file=sys.stderr)
        return []
    empty_counts = {
        h: sum(1 for row in rows if not (row.get(h) or "").strip())
        for h in headers
    }
    return [{
        "id":        path,
        "extension": "csv",
        "headers":   headers,
        "row_count": len(rows),
        "content":   content,
        "raw": {
            "headers":      headers,
            "empty_counts": empty_counts,
        },
    }]


def make_csv_tools(registry: ToolRegistry) -> None:
    registry.register("parse_xml",   _parse_csv,   "Parse a CSV file into a data-quality profile")
    registry.register("suggest_fix", _suggest_fix, "Render fix_draft template for a Finding")
    registry.register("apply_fix",   _apply_fix,   "Comment out the offending line in the source file")


def _parse_pip_audit(path: str) -> list[dict]:
    p = Path(path)
    try:
        data = _json.loads(p.read_text(encoding="utf-8"))
    except OSError as e:
        print(f"Warning: cannot read {path}: {e}", file=sys.stderr)
        return []
    except _json.JSONDecodeError as e:
        print(f"Warning: JSON parse error in {path}: {e}", file=sys.stderr)
        return []
    if not isinstance(data, list):
        print(
            f"Warning: unexpected pip-audit format in {path} (expected a JSON list)",
            file=sys.stderr,
        )
        return []
    profiles = []
    for pkg in data:
        name    = pkg.get("name", "unknown")
        version = pkg.get("version", "unknown")
        for vuln in pkg.get("vulns", []):
            vuln_id      = vuln.get("id", "UNKNOWN")
            fix_versions = vuln.get("fix_versions", [])
            fixed        = fix_versions[0] if fix_versions else ""
            fix_token    = f"fix:{fixed}" if fixed else ""
            content      = f"{name}=={version} {vuln_id} {fix_token}".strip()
            profiles.append({
                "id":                vuln_id,
                "package":           name,
                "installed_version": version,
                "fixed_version":     fixed,
                "source":            "pip-audit",
                "content":           content,
                "raw": {
                    "vuln_id":           vuln_id,
                    "package":           name,
                    "installed_version": version,
                    "fix_versions":      fix_versions,
                    "description":       vuln.get("description", ""),
                    "aliases":           vuln.get("aliases", []),
                },
            })
    return profiles


def make_security_tools(registry: ToolRegistry) -> None:
    registry.register("parse_xml",   _parse_pip_audit, "Parse pip-audit JSON into vulnerability profiles")
    registry.register("suggest_fix", _suggest_fix,     "Render fix_draft template for a Finding")
    registry.register("apply_fix",   _apply_fix,       "Comment out the offending line in the source file")
