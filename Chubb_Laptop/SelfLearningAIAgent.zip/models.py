from dataclasses import dataclass


@dataclass
class Finding:
    rule_id:     str
    profile_id:  str
    severity:    str
    message:     str
    fix_draft:   str
    confidence:  float = 0.5
    line_number: int | None = None
