from unittest.mock import MagicMock
from models import Finding
from agent import Agent, confidence_label


def make_finding(**kwargs):
    defaults = dict(
        rule_id="missing-creds",
        profile_id="SomeProfile",
        severity="HIGH",
        message="Test message",
        fix_draft="Fix for {profile_id}",
        confidence=0.5,
    )
    defaults.update(kwargs)
    return Finding(**defaults)


def make_agent(memory_data=None, pending=None, rule_findings=None):
    rules = MagicMock()
    rules.apply.return_value = rule_findings or []

    tools = MagicMock()
    tools.call.side_effect = lambda name, **kw: (
        [{"id": "profile:A", "metadata_keys": [], "elements": []}]
        if name == "parse_xml" else "rendered fix"
    )

    memory = MagicMock()
    memory.recall.return_value = memory_data
    memory.save.return_value = None

    feedback = MagicMock()
    feedback.load_pending.return_value = pending or []
    feedback.success_rate.return_value = None

    return Agent(rules=rules, tools=tools, memory=memory, feedback=feedback), memory, feedback


def test_confidence_label_new_rule():
    assert confidence_label(0.5, has_history=False) == "[NEW RULE]"


def test_confidence_label_confirmed():
    assert confidence_label(0.75, has_history=True) == "[CONFIRMED]"


def test_confidence_label_uncertain():
    assert confidence_label(0.55, has_history=True) == "[UNCERTAIN ?]"


def test_confidence_label_low():
    assert confidence_label(0.2, has_history=True) == "[LOW CONFIDENCE]"


def test_analyze_scores_confidence_from_memory():
    finding = make_finding(rule_id="known-rule")
    agent, memory, _ = make_agent(
        memory_data={"attempts": 10, "confirmed": 8, "confidence": 0.8},
        rule_findings=[finding],
    )
    results = agent.analyze("fake.xml")
    assert results[0].confidence == 0.8


def test_analyze_defaults_confidence_when_no_memory():
    finding = make_finding(rule_id="new-rule")
    agent, memory, _ = make_agent(memory_data=None, rule_findings=[finding])
    results = agent.analyze("fake.xml")
    assert results[0].confidence == 0.5


def test_analyze_renders_fix_draft():
    finding = make_finding()
    agent, _, _ = make_agent(rule_findings=[finding])
    results = agent.analyze("fake.xml")
    assert results[0].fix_draft == "rendered fix"


def test_startup_reconcile_resolves_yes(monkeypatch):
    pending = [{"id": "fb-001", "rule_id": "test-rule", "profile_id": "ProfileA"}]
    agent, memory, feedback = make_agent(pending=pending)
    memory.recall.return_value = {"attempts": 0, "confirmed": 0, "confidence": 0.5}
    monkeypatch.setattr("builtins.input", lambda _: "y")
    agent.startup_reconcile()
    feedback.resolve.assert_called_once_with("fb-001", "confirmed")


def test_startup_reconcile_resolves_no(monkeypatch):
    pending = [{"id": "fb-002", "rule_id": "test-rule", "profile_id": "ProfileA"}]
    agent, memory, feedback = make_agent(pending=pending)
    memory.recall.return_value = {"attempts": 0, "confirmed": 0, "confidence": 0.5}
    monkeypatch.setattr("builtins.input", lambda _: "n")
    agent.startup_reconcile()
    feedback.resolve.assert_called_once_with("fb-002", "denied")


def test_startup_reconcile_noop_when_no_pending():
    agent, _, feedback = make_agent(pending=[])
    agent.startup_reconcile()
    feedback.resolve.assert_not_called()


def test_collect_feedback_skip_does_not_update_memory(monkeypatch):
    finding = make_finding()
    agent, memory, feedback = make_agent(rule_findings=[finding])
    monkeypatch.setattr("builtins.input", lambda _: "skip")
    agent.collect_feedback([finding])
    feedback.record.assert_called_once()
    args = feedback.record.call_args[0]
    assert args[2] == "pending"   # "skip" input → "pending" outcome
    memory.save.assert_not_called()


def test_startup_reconcile_skips_on_other_input(monkeypatch):
    pending = [{"id": "fb-003", "rule_id": "test-rule", "profile_id": "ProfileA"}]
    agent, memory, feedback = make_agent(pending=pending)
    monkeypatch.setattr("builtins.input", lambda _: "skip")
    agent.startup_reconcile()
    feedback.resolve.assert_not_called()
    memory.save.assert_not_called()


def _make_agent():
    agent, memory, _ = make_agent()
    # memory.recall must honour the `default` kwarg so _update_memory doesn't crash
    memory.recall.side_effect = lambda key, default=None: default
    return agent


def test_collect_feedback_calls_apply_fix_when_confirmed_with_line_number():
    from models import Finding
    from unittest.mock import patch

    finding = Finding(
        rule_id="r", profile_id="p.py", severity="LOW",
        message="m", fix_draft="fix", line_number=5,
    )
    agent = _make_agent()

    with patch.object(agent._tools, "call") as mock_call, \
         patch("builtins.input", return_value="y"):
        agent.collect_feedback([finding])

    apply_fix_calls = [c for c in mock_call.call_args_list if c.args[0] == "apply_fix"]
    assert len(apply_fix_calls) == 1


def test_collect_feedback_skips_apply_fix_when_no_line_number():
    from models import Finding
    from unittest.mock import patch

    finding = Finding(
        rule_id="r", profile_id="p.yaml", severity="LOW",
        message="m", fix_draft="fix", line_number=None,
    )
    agent = _make_agent()

    with patch.object(agent._tools, "call") as mock_call, \
         patch("builtins.input", return_value="y"):
        agent.collect_feedback([finding])

    apply_fix_calls = [c for c in mock_call.call_args_list if c.args[0] == "apply_fix"]
    assert len(apply_fix_calls) == 0
