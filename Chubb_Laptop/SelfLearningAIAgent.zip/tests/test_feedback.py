import json
from pathlib import Path
from feedback import FeedbackTracker


def test_record_confirmed(tmp_path):
    tracker = FeedbackTracker(log_path=str(tmp_path / "log.json"))
    tracker.record("rule:test", "ProfileA", "confirmed")
    assert tracker.success_rate("rule:test") == 1.0


def test_record_denied(tmp_path):
    tracker = FeedbackTracker(log_path=str(tmp_path / "log.json"))
    tracker.record("rule:test", "ProfileA", "confirmed")
    tracker.record("rule:test", "ProfileB", "denied")
    assert tracker.success_rate("rule:test") == 0.5


def test_skip_not_counted_in_success_rate(tmp_path):
    tracker = FeedbackTracker(log_path=str(tmp_path / "log.json"))
    tracker.record("rule:test", "ProfileA", "pending")
    assert tracker.success_rate("rule:test") is None


def test_no_history_returns_none(tmp_path):
    tracker = FeedbackTracker(log_path=str(tmp_path / "log.json"))
    assert tracker.success_rate("rule:unknown") is None


def test_persists_to_log_file(tmp_path):
    path = str(tmp_path / "log.json")
    tracker = FeedbackTracker(log_path=path)
    tracker.record("rule:test", "ProfileA", "confirmed")
    data = json.loads(Path(path).read_text())
    assert len(data) == 1
    assert data[0]["outcome"] == "confirmed"
    assert data[0]["resolved"] is True


def test_pending_entry_not_resolved(tmp_path):
    path = str(tmp_path / "log.json")
    tracker = FeedbackTracker(log_path=path)
    tracker.record("rule:test", "ProfileA", "pending")
    pending = tracker.load_pending()
    assert len(pending) == 1
    assert pending[0]["rule_id"] == "rule:test"


def test_resolve_updates_outcome_and_clears_pending(tmp_path):
    path = str(tmp_path / "log.json")
    tracker = FeedbackTracker(log_path=path)
    tracker.record("rule:test", "ProfileA", "pending")
    entry_id = tracker.load_pending()[0]["id"]
    tracker.resolve(entry_id, "confirmed")
    assert tracker.success_rate("rule:test") == 1.0
    assert tracker.load_pending() == []


def test_counts_reload_on_init(tmp_path):
    path = str(tmp_path / "log.json")
    FeedbackTracker(log_path=path).record("rule:test", "ProfileA", "confirmed")
    assert FeedbackTracker(log_path=path).success_rate("rule:test") == 1.0
