import json as _json
from models import Finding
from tools import ToolRegistry, make_code_review_tools, make_infra_tools, make_csv_tools, make_security_tools


def test_unknown_tool_raises_value_error():
    registry = ToolRegistry()
    try:
        registry.call("nonexistent")
        assert False, "Should have raised ValueError"
    except ValueError as e:
        assert "nonexistent" in str(e)


def test_suggest_fix_renders_profile_id():
    registry = ToolRegistry()
    make_code_review_tools(registry)
    finding = Finding(
        rule_id="rule:test",
        profile_id="MyProfile",
        severity="HIGH",
        message="Test",
        fix_draft="Add client_id to {profile_id} metadata",
    )
    result = registry.call("suggest_fix", finding=finding)
    assert "MyProfile" in result
    assert "{profile_id}" not in result


# ── _parse_file ───────────────────────────────────────────────────────────────

def test_parse_file_returns_one_profile(tmp_path):
    src = tmp_path / "main.py"
    src.write_text("import os\nprint('hello')\n")
    registry = ToolRegistry()
    make_code_review_tools(registry)
    result = registry.call("parse_xml", path=str(src))
    assert len(result) == 1


def test_parse_file_profile_has_correct_extension(tmp_path):
    src = tmp_path / "main.py"
    src.write_text("x = 1\n")
    registry = ToolRegistry()
    make_code_review_tools(registry)
    profile = registry.call("parse_xml", path=str(src))[0]
    assert profile["extension"] == "py"


def test_parse_file_profile_has_content_and_lines(tmp_path):
    src = tmp_path / "util.js"
    src.write_text("const x = 1;\nconsole.log(x);\n")
    registry = ToolRegistry()
    make_code_review_tools(registry)
    profile = registry.call("parse_xml", path=str(src))[0]
    assert profile["content"] == "const x = 1;\nconsole.log(x);\n"
    assert profile["lines"] == ["const x = 1;", "console.log(x);", ""]


def test_parse_file_id_is_the_path(tmp_path):
    src = tmp_path / "main.py"
    src.write_text("")
    registry = ToolRegistry()
    make_code_review_tools(registry)
    profile = registry.call("parse_xml", path=str(src))[0]
    assert profile["id"] == str(src)


def test_parse_file_returns_empty_list_for_missing_file(tmp_path, capsys):
    registry = ToolRegistry()
    make_code_review_tools(registry)
    result = registry.call("parse_xml", path=str(tmp_path / "nonexistent.py"))
    assert result == []
    assert "Warning" in capsys.readouterr().err


def test_code_review_suggest_fix_renders_profile_id(tmp_path):
    from models import Finding
    src = tmp_path / "main.py"
    src.write_text("")
    registry = ToolRegistry()
    make_code_review_tools(registry)
    finding = Finding(
        rule_id="cr:no-eval",
        profile_id=str(src),
        severity="HIGH",
        message="eval found",
        fix_draft="Remove eval() in {profile_id}",
    )
    result = registry.call("suggest_fix", finding=finding)
    assert str(src) in result
    assert "{profile_id}" not in result


# ── _parse_yaml_infra — kubernetes ────────────────────────────────────────────

def test_parse_yaml_infra_kubernetes_returns_one_profile(tmp_path):
    manifest = tmp_path / "deployment.yaml"
    manifest.write_text(
        "apiVersion: apps/v1\nkind: Deployment\nmetadata:\n  name: my-app\nspec: {}\n"
    )
    registry = ToolRegistry()
    make_infra_tools(registry)
    result = registry.call("parse_xml", path=str(manifest))
    assert len(result) == 1


def test_parse_yaml_infra_kubernetes_profile_fields(tmp_path):
    manifest = tmp_path / "deployment.yaml"
    manifest.write_text(
        "apiVersion: apps/v1\nkind: Deployment\nmetadata:\n  name: my-app\nspec: {}\n"
    )
    registry = ToolRegistry()
    make_infra_tools(registry)
    profile = registry.call("parse_xml", path=str(manifest))[0]
    assert profile["source"] == "kubernetes"
    assert profile["kind"] == "Deployment"
    assert "Deployment/my-app" in profile["id"]
    assert "raw" in profile
    assert "content" in profile


def test_parse_yaml_infra_github_actions_detected(tmp_path):
    workflows = tmp_path / ".github" / "workflows"
    workflows.mkdir(parents=True)
    ci = workflows / "ci.yml"
    ci.write_text("name: CI\non: push\njobs:\n  build:\n    runs-on: ubuntu-latest\n    steps: []\n")
    registry = ToolRegistry()
    make_infra_tools(registry)
    profile = registry.call("parse_xml", path=str(ci))[0]
    assert profile["source"] == "github-actions"
    assert profile["kind"] == "Workflow"


def test_parse_yaml_infra_multi_document(tmp_path):
    manifest = tmp_path / "multi.yaml"
    manifest.write_text(
        "kind: Deployment\nmetadata:\n  name: app\nspec: {}\n---\nkind: Service\nmetadata:\n  name: svc\nspec: {}\n"
    )
    registry = ToolRegistry()
    make_infra_tools(registry)
    result = registry.call("parse_xml", path=str(manifest))
    assert len(result) == 2
    kinds = {p["kind"] for p in result}
    assert kinds == {"Deployment", "Service"}


def test_parse_yaml_infra_returns_empty_for_missing_file(tmp_path, capsys):
    registry = ToolRegistry()
    make_infra_tools(registry)
    result = registry.call("parse_xml", path=str(tmp_path / "nonexistent.yaml"))
    assert result == []
    assert "Warning" in capsys.readouterr().err


def test_parse_yaml_infra_returns_empty_for_invalid_yaml(tmp_path, capsys):
    bad = tmp_path / "bad.yaml"
    bad.write_text("key: [unclosed\n  bad: indent\n")
    registry = ToolRegistry()
    make_infra_tools(registry)
    result = registry.call("parse_xml", path=str(bad))
    assert result == []
    assert "Warning" in capsys.readouterr().err


def test_parse_yaml_infra_multi_doc_content_scoped_per_document(tmp_path):
    manifest = tmp_path / "multi.yaml"
    manifest.write_text(
        "kind: Deployment\nmetadata:\n  name: app-a\nspec: {}\n"
        "---\n"
        "kind: Deployment\nmetadata:\n  name: app-b\nspec:\n  resources: {}\n"
    )
    registry = ToolRegistry()
    make_infra_tools(registry)
    profiles = registry.call("parse_xml", path=str(manifest))
    assert len(profiles) == 2
    contents = {p["id"].split("/")[1]: p["content"] for p in profiles}
    assert "resources" not in contents["app-a"]
    assert "resources" in contents["app-b"]


def test_suggest_fix_preserves_gha_double_brace_expressions():
    from models import Finding
    registry = ToolRegistry()
    make_code_review_tools(registry)
    finding = Finding(
        rule_id="gha:test",
        profile_id="ci.yml::Workflow/CI",
        severity="HIGH",
        message="test",
        fix_draft="Use ${{ secrets.API_KEY }} in {profile_id}",
    )
    result = registry.call("suggest_fix", finding=finding)
    assert "${{ secrets.API_KEY }}" in result
    assert "ci.yml::Workflow/CI" in result
    assert "{profile_id}" not in result


# ── _parse_csv ────────────────────────────────────────────────────────────────

def test_parse_csv_returns_one_profile(tmp_path):
    src = tmp_path / "data.csv"
    src.write_text("id,name,email\n1,Alice,alice@example.com\n2,Bob,bob@example.com\n")
    registry = ToolRegistry()
    make_csv_tools(registry)
    result = registry.call("parse_xml", path=str(src))
    assert len(result) == 1


def test_parse_csv_extracts_headers(tmp_path):
    src = tmp_path / "data.csv"
    src.write_text("id,name,email\n1,Alice,alice@example.com\n")
    registry = ToolRegistry()
    make_csv_tools(registry)
    profile = registry.call("parse_xml", path=str(src))[0]
    assert profile["headers"] == ["id", "name", "email"]


def test_parse_csv_counts_rows(tmp_path):
    src = tmp_path / "data.csv"
    src.write_text("id,name\n1,Alice\n2,Bob\n3,Carol\n")
    registry = ToolRegistry()
    make_csv_tools(registry)
    profile = registry.call("parse_xml", path=str(src))[0]
    assert profile["row_count"] == 3


def test_parse_csv_counts_empty_cells(tmp_path):
    src = tmp_path / "data.csv"
    src.write_text("name,email\nAlice,\nBob,bob@example.com\n,carol@example.com\n")
    registry = ToolRegistry()
    make_csv_tools(registry)
    profile = registry.call("parse_xml", path=str(src))[0]
    assert profile["raw"]["empty_counts"]["email"] == 1
    assert profile["raw"]["empty_counts"]["name"] == 1


def test_parse_csv_includes_content_and_extension(tmp_path):
    src = tmp_path / "data.csv"
    content = "id,name\n1,Alice\n"
    src.write_text(content)
    registry = ToolRegistry()
    make_csv_tools(registry)
    profile = registry.call("parse_xml", path=str(src))[0]
    assert profile["content"] == content
    assert profile["extension"] == "csv"


def test_parse_csv_empty_file_has_no_headers(tmp_path):
    src = tmp_path / "data.csv"
    src.write_text("")
    registry = ToolRegistry()
    make_csv_tools(registry)
    profile = registry.call("parse_xml", path=str(src))[0]
    assert profile["headers"] == []
    assert profile["row_count"] == 0


def test_parse_csv_returns_empty_for_missing_file(tmp_path, capsys):
    registry = ToolRegistry()
    make_csv_tools(registry)
    result = registry.call("parse_xml", path=str(tmp_path / "nonexistent.csv"))
    assert result == []
    assert "Warning" in capsys.readouterr().err


def test_parse_csv_handles_short_rows_without_crashing(tmp_path):
    src = tmp_path / "data.csv"
    src.write_text("id,name,email\n1,Alice\n")  # row missing the email column
    registry = ToolRegistry()
    make_csv_tools(registry)
    profile = registry.call("parse_xml", path=str(src))[0]
    assert profile["row_count"] == 1
    assert profile["raw"]["empty_counts"]["email"] >= 1


# ── _parse_pip_audit ──────────────────────────────────────────────────────────

_SAMPLE_PIP_AUDIT = [
    {
        "name": "requests",
        "version": "2.27.0",
        "vulns": [
            {
                "id": "CVE-2023-32681",
                "fix_versions": ["2.28.2"],
                "aliases": [],
                "description": "Proxy-Authorization header leak",
            }
        ],
    },
    {
        "name": "cryptography",
        "version": "3.4.8",
        "vulns": [
            {
                "id": "PYSEC-2023-112",
                "fix_versions": [],
                "aliases": [],
                "description": "NULL pointer dereference",
            }
        ],
    },
    {
        "name": "setuptools",
        "version": "65.0.0",
        "vulns": [],
    },
]


def test_parse_pip_audit_returns_one_profile_per_vuln(tmp_path):
    src = tmp_path / "audit.json"
    src.write_text(_json.dumps(_SAMPLE_PIP_AUDIT))
    registry = ToolRegistry()
    make_security_tools(registry)
    result = registry.call("parse_xml", path=str(src))
    assert len(result) == 2  # setuptools has no vulns


def test_parse_pip_audit_profile_id_is_vuln_id(tmp_path):
    src = tmp_path / "audit.json"
    src.write_text(_json.dumps(_SAMPLE_PIP_AUDIT))
    registry = ToolRegistry()
    make_security_tools(registry)
    ids = {p["id"] for p in registry.call("parse_xml", path=str(src))}
    assert "CVE-2023-32681" in ids
    assert "PYSEC-2023-112" in ids


def test_parse_pip_audit_fixed_version_populated_when_fix_exists(tmp_path):
    src = tmp_path / "audit.json"
    src.write_text(_json.dumps(_SAMPLE_PIP_AUDIT))
    registry = ToolRegistry()
    make_security_tools(registry)
    profiles = registry.call("parse_xml", path=str(src))
    cve = next(p for p in profiles if p["id"] == "CVE-2023-32681")
    assert cve["fixed_version"] == "2.28.2"


def test_parse_pip_audit_fixed_version_empty_when_no_fix(tmp_path):
    src = tmp_path / "audit.json"
    src.write_text(_json.dumps(_SAMPLE_PIP_AUDIT))
    registry = ToolRegistry()
    make_security_tools(registry)
    profiles = registry.call("parse_xml", path=str(src))
    pysec = next(p for p in profiles if p["id"] == "PYSEC-2023-112")
    assert pysec["fixed_version"] == ""


def test_parse_pip_audit_content_has_fix_token_when_fix_available(tmp_path):
    src = tmp_path / "audit.json"
    src.write_text(_json.dumps(_SAMPLE_PIP_AUDIT))
    registry = ToolRegistry()
    make_security_tools(registry)
    profiles = registry.call("parse_xml", path=str(src))
    cve = next(p for p in profiles if p["id"] == "CVE-2023-32681")
    assert "fix:2.28.2" in cve["content"]


def test_parse_pip_audit_content_has_no_fix_token_when_unfixable(tmp_path):
    src = tmp_path / "audit.json"
    src.write_text(_json.dumps(_SAMPLE_PIP_AUDIT))
    registry = ToolRegistry()
    make_security_tools(registry)
    profiles = registry.call("parse_xml", path=str(src))
    pysec = next(p for p in profiles if p["id"] == "PYSEC-2023-112")
    assert "fix:" not in pysec["content"]


def test_parse_pip_audit_returns_empty_for_missing_file(tmp_path, capsys):
    registry = ToolRegistry()
    make_security_tools(registry)
    result = registry.call("parse_xml", path=str(tmp_path / "nonexistent.json"))
    assert result == []
    assert "Warning" in capsys.readouterr().err


def test_parse_pip_audit_returns_empty_for_invalid_json(tmp_path, capsys):
    bad = tmp_path / "bad.json"
    bad.write_text("not json {")
    registry = ToolRegistry()
    make_security_tools(registry)
    result = registry.call("parse_xml", path=str(bad))
    assert result == []
    assert "Warning" in capsys.readouterr().err


def test_parse_pip_audit_returns_empty_for_non_list_json(tmp_path, capsys):
    bad = tmp_path / "bad.json"
    bad.write_text('{"key": "value"}')
    registry = ToolRegistry()
    make_security_tools(registry)
    result = registry.call("parse_xml", path=str(bad))
    assert result == []
    assert "Warning" in capsys.readouterr().err


# ── _apply_fix ────────────────────────────────────────────────────────────────

def _make_finding(profile_id: str, line_number: int | None) -> Finding:
    return Finding(
        rule_id="r",
        profile_id=profile_id,
        severity="LOW",
        message="m",
        fix_draft="fix",
        line_number=line_number,
    )


def test_apply_fix_comments_line_in_py_file(tmp_path):
    f = tmp_path / "script.py"
    f.write_text("x = 1\nprint('debug')\ny = 2\n")
    finding = _make_finding(str(f), line_number=2)

    from tools import make_code_review_tools, ToolRegistry
    reg = ToolRegistry()
    make_code_review_tools(reg)
    result = reg.call("apply_fix", finding=finding)

    assert result is True
    lines = f.read_text().splitlines()
    assert lines[1] == "# print('debug')"
    assert lines[0] == "x = 1"
    assert lines[2] == "y = 2"


def test_apply_fix_uses_double_slash_for_js(tmp_path):
    f = tmp_path / "app.js"
    f.write_text("const x = 1;\nconsole.log('debug');\n")
    finding = _make_finding(str(f), line_number=2)

    from tools import make_code_review_tools, ToolRegistry
    reg = ToolRegistry()
    make_code_review_tools(reg)
    result = reg.call("apply_fix", finding=finding)

    assert result is True
    lines = f.read_text().splitlines()
    assert lines[1] == "// console.log('debug');"


def test_apply_fix_returns_false_file_not_found(tmp_path):
    finding = _make_finding(str(tmp_path / "missing.py"), line_number=1)

    from tools import make_code_review_tools, ToolRegistry
    reg = ToolRegistry()
    make_code_review_tools(reg)
    result = reg.call("apply_fix", finding=finding)

    assert result is False


def test_apply_fix_returns_false_line_out_of_range(tmp_path):
    f = tmp_path / "script.py"
    f.write_text("x = 1\n")
    finding = _make_finding(str(f), line_number=99)

    from tools import make_code_review_tools, ToolRegistry
    reg = ToolRegistry()
    make_code_review_tools(reg)
    result = reg.call("apply_fix", finding=finding)

    assert result is False


def test_apply_fix_returns_false_unknown_extension(tmp_path):
    f = tmp_path / "data.csv"
    f.write_text("id,name\n1,alice\n")
    finding = _make_finding(str(f), line_number=2)

    from tools import make_csv_tools, ToolRegistry
    reg = ToolRegistry()
    make_csv_tools(reg)
    result = reg.call("apply_fix", finding=finding)

    assert result is False
