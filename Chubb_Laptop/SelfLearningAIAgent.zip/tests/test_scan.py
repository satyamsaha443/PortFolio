import subprocess
from pathlib import Path
from unittest.mock import patch, MagicMock
import pytest


# ── helpers ──────────────────────────────────────────────────────────────────

def _make_file(tmp_path: Path, name: str, content: str = "") -> Path:
    f = tmp_path / name
    f.write_text(content)
    return f


# ── detect grouping from folder ───────────────────────────────────────────────

def test_scan_folder_groups_by_domain(tmp_path):
    _make_file(tmp_path, "script.py", "x=1")
    _make_file(tmp_path, "data.csv", "id,name\n1,a")
    _make_file(tmp_path, "README.md", "# hi")  # should be skipped

    calls = []

    def fake_run(domain, paths, **_):
        calls.append((domain, sorted(str(p) for p in paths)))

    with patch("main.run", side_effect=fake_run):
        from main import scan
        scan(str(tmp_path))

    domains_called = {c[0] for c in calls}
    assert "code-review" in domains_called
    assert "csv" in domains_called
    assert "infra" not in domains_called  # no yaml files


def test_scan_folder_skips_excluded_dirs(tmp_path):
    venv = tmp_path / "venv"
    venv.mkdir()
    (venv / "junk.py").write_text("x=1")
    real = tmp_path / "real.py"
    real.write_text("y=2")

    calls = []

    def fake_run(domain, paths, **_):
        calls.append((domain, [str(p) for p in paths]))

    with patch("main.run", side_effect=fake_run):
        from main import scan
        scan(str(tmp_path))

    all_paths = [p for _, paths in calls for p in paths]
    assert not any("venv" in p for p in all_paths)
    assert any("real.py" in p for p in all_paths)


def test_scan_single_known_file(tmp_path):
    f = _make_file(tmp_path, "app.py", "x=1")
    calls = []

    def fake_run(domain, paths, **_):
        calls.append((domain, paths))

    with patch("main.run", side_effect=fake_run):
        from main import scan
        scan(str(f))

    assert len(calls) == 1
    assert calls[0][0] == "code-review"


def test_scan_single_unknown_file_skips(tmp_path, capsys):
    f = _make_file(tmp_path, "notes.md", "# notes")

    with patch("main.run") as mock_run:
        from main import scan
        scan(str(f))
        mock_run.assert_not_called()

    out = capsys.readouterr().out
    assert "Skipping" in out or "Nothing" in out


def test_scan_empty_folder_prints_nothing_to_scan(tmp_path, capsys):
    # Only unknown files
    _make_file(tmp_path, "notes.md", "# notes")

    with patch("main.run"):
        from main import scan
        scan(str(tmp_path))

    out = capsys.readouterr().out
    assert "Nothing to scan" in out


# ── git diff mode (no arg) ────────────────────────────────────────────────────

def test_scan_no_arg_uses_git_diff(tmp_path):
    py_file = _make_file(tmp_path, "script.py", "x=1")
    # git diff returns repo-relative path; mock repo root to tmp_path
    rel_path = py_file.name  # just "script.py"

    def fake_subprocess(cmd, **kwargs):
        result = MagicMock()
        result.returncode = 0
        if "rev-parse" in cmd:
            result.stdout = str(tmp_path) + "\n"
        else:
            result.stdout = rel_path + "\n"
        return result

    calls = []

    def fake_run(domain, paths, **_):
        calls.append((domain, paths))

    with patch("subprocess.run", side_effect=fake_subprocess), \
         patch("main.run", side_effect=fake_run):
        from main import scan
        scan(None)

    assert any(c[0] == "code-review" for c in calls)


def test_scan_no_arg_fallback_to_cwd_when_not_git(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    _make_file(tmp_path, "app.py", "x=1")

    def fake_subprocess(cmd, **kwargs):
        raise FileNotFoundError("git not found")

    calls = []

    def fake_run(domain, paths, **_):
        calls.append((domain, paths))

    with patch("subprocess.run", side_effect=fake_subprocess), \
         patch("main.run", side_effect=fake_run):
        from main import scan
        scan(None)

    assert any(c[0] == "code-review" for c in calls)


def test_scan_git_diff_skips_deleted_files(tmp_path):
    missing = str(tmp_path / "deleted.py")  # does not exist on disk

    def fake_subprocess(cmd, **kwargs):
        result = MagicMock()
        result.returncode = 0
        result.stdout = missing + "\n"
        return result

    with patch("subprocess.run", side_effect=fake_subprocess), \
         patch("main.run") as mock_run:
        from main import scan
        scan(None)
        mock_run.assert_not_called()
