import json
import textwrap
import pytest
from pathlib import Path
from main import run

FIXTURES = Path(__file__).parent / "fixtures"

CODE_REVIEW_RULES = textwrap.dedent("""\
    rules:
      - id: "cr:no-eval"
        applies_to: "*"
        check: regex_match
        params:
          pattern: 'eval\\s*\\('
        severity: HIGH
        message: "eval() found"
        fix_template: "Remove eval() in {profile_id}"
      - id: "cr:hardcoded-secret"
        applies_to: "*"
        check: regex_match
        params:
          pattern: '(?i)(password|api_key|secret|token)\\s*=\\s*[''"][^''"]{4,}[''"]'
        severity: HIGH
        message: "Hardcoded secret"
        fix_template: "Move secret to env var in {profile_id}"
      - id: "cr:print-debug"
        applies_to: "py"
        match_field: extension
        check: regex_match
        params:
          pattern: '\\bprint\\s*\\('
        severity: LOW
        message: "Debug print found"
        fix_template: "Remove print() in {profile_id}"
""")

INFRA_RULES = textwrap.dedent("""\
    rules:
      - id: "k8s:latest-image-tag"
        applies_to: "kubernetes"
        match_field: source
        check: regex_match
        params:
          pattern: 'image:\\s+\\S+:latest'
        severity: MEDIUM
        message: "Image tag :latest is unpinned"
        fix_template: "Pin image in {profile_id}"
      - id: "k8s:privileged-container"
        applies_to: "kubernetes"
        match_field: source
        check: regex_match
        params:
          pattern: 'privileged:\\s*true'
        severity: HIGH
        message: "Privileged container found"
        fix_template: "Remove privileged: true from {profile_id}"
      - id: "gha:no-pin-action"
        applies_to: "github-actions"
        match_field: source
        check: regex_match
        params:
          pattern: 'uses:\\s+\\S+@(main|master|v\\d+)\\b'
        severity: MEDIUM
        message: "Action pinned to branch"
        fix_template: "Pin to SHA in {profile_id}"
""")


# ── code-review domain ────────────────────────────────────────────────────────

def test_code_review_detects_eval_in_py_file(tmp_path, monkeypatch):
    rules_file    = tmp_path / "rules.yaml"
    memory_file   = tmp_path / "memory.json"
    feedback_file = tmp_path / "feedback.json"
    rules_file.write_text(CODE_REVIEW_RULES)
    monkeypatch.setattr("builtins.input", lambda _: "y")

    run(
        domain="code-review",
        paths=[str(FIXTURES / "sample.py")],
        rules_path=str(rules_file),
        memory_path=str(memory_file),
        feedback_path=str(feedback_file),
    )

    feedback_data = json.loads(feedback_file.read_text())
    rule_ids = {e["rule_id"] for e in feedback_data}
    assert "cr:no-eval" in rule_ids


def test_code_review_detects_hardcoded_secret_in_py_file(tmp_path, monkeypatch):
    rules_file    = tmp_path / "rules.yaml"
    memory_file   = tmp_path / "memory.json"
    feedback_file = tmp_path / "feedback.json"
    rules_file.write_text(CODE_REVIEW_RULES)
    monkeypatch.setattr("builtins.input", lambda _: "skip")

    run(
        domain="code-review",
        paths=[str(FIXTURES / "sample.py")],
        rules_path=str(rules_file),
        memory_path=str(memory_file),
        feedback_path=str(feedback_file),
    )

    feedback_data = json.loads(feedback_file.read_text())
    rule_ids = {e["rule_id"] for e in feedback_data}
    assert "cr:hardcoded-secret" in rule_ids


def test_code_review_print_rule_only_fires_for_py_not_js(tmp_path, monkeypatch):
    rules_file    = tmp_path / "rules.yaml"
    memory_file   = tmp_path / "memory.json"
    feedback_file = tmp_path / "feedback.json"
    rules_file.write_text(CODE_REVIEW_RULES)
    monkeypatch.setattr("builtins.input", lambda _: "skip")

    run(
        domain="code-review",
        paths=[str(FIXTURES / "sample.py"), str(FIXTURES / "sample.js")],
        rules_path=str(rules_file),
        memory_path=str(memory_file),
        feedback_path=str(feedback_file),
    )

    feedback_data = json.loads(feedback_file.read_text())
    print_findings = [e for e in feedback_data if e["rule_id"] == "cr:print-debug"]
    profile_ids = {e["profile_id"] for e in print_findings}
    assert all("sample.py" in pid for pid in profile_ids), \
        "cr:print-debug must only fire for .py files"


# ── infra domain ──────────────────────────────────────────────────────────────

def test_infra_detects_latest_image_tag_in_k8s_manifest(tmp_path, monkeypatch):
    rules_file    = tmp_path / "rules.yaml"
    memory_file   = tmp_path / "memory.json"
    feedback_file = tmp_path / "feedback.json"
    rules_file.write_text(INFRA_RULES)
    monkeypatch.setattr("builtins.input", lambda _: "skip")

    run(
        domain="infra",
        paths=[str(FIXTURES / "deployment.yaml")],
        rules_path=str(rules_file),
        memory_path=str(memory_file),
        feedback_path=str(feedback_file),
    )

    feedback_data = json.loads(feedback_file.read_text())
    rule_ids = {e["rule_id"] for e in feedback_data}
    assert "k8s:latest-image-tag" in rule_ids


def test_infra_gha_rule_does_not_fire_for_k8s_manifest(tmp_path, monkeypatch):
    rules_file    = tmp_path / "rules.yaml"
    memory_file   = tmp_path / "memory.json"
    feedback_file = tmp_path / "feedback.json"
    rules_file.write_text(INFRA_RULES)
    monkeypatch.setattr("builtins.input", lambda _: "skip")

    run(
        domain="infra",
        paths=[str(FIXTURES / "deployment.yaml")],
        rules_path=str(rules_file),
        memory_path=str(memory_file),
        feedback_path=str(feedback_file),
    )

    feedback_data = json.loads(feedback_file.read_text())
    rule_ids = {e["rule_id"] for e in feedback_data}
    assert "gha:no-pin-action" not in rule_ids, \
        "GHA rules must not fire against Kubernetes manifests"


def test_infra_detects_branch_pinned_action_in_workflow(tmp_path, monkeypatch):
    rules_file    = tmp_path / "rules.yaml"
    memory_file   = tmp_path / "memory.json"
    feedback_file = tmp_path / "feedback.json"
    rules_file.write_text(INFRA_RULES)
    monkeypatch.setattr("builtins.input", lambda _: "skip")

    workflows = tmp_path / ".github" / "workflows"
    workflows.mkdir(parents=True)
    ci = workflows / "ci.yml"
    ci.write_text((FIXTURES / "ci.yml").read_text())

    run(
        domain="infra",
        paths=[str(ci)],
        rules_path=str(rules_file),
        memory_path=str(memory_file),
        feedback_path=str(feedback_file),
    )

    feedback_data = json.loads(feedback_file.read_text())
    rule_ids = {e["rule_id"] for e in feedback_data}
    assert "gha:no-pin-action" in rule_ids


def test_unknown_domain_exits_with_error(capsys):
    with pytest.raises(SystemExit) as exc_info:
        run(domain="nonexistent", paths=["file.txt"])
    assert exc_info.value.code == 1
    assert "nonexistent" in capsys.readouterr().err


# ── log-analysis domain ───────────────────────────────────────────────────────

LOG_RULES = textwrap.dedent("""\
    rules:
      - id: "log:unhandled-exception"
        applies_to: "*"
        check: regex_match
        params:
          pattern: 'Traceback \\(most recent call last\\)|FATAL ERROR|Unhandled Exception'
        severity: HIGH
        message: "Unhandled exception detected"
        fix_template: "Investigate exception in {profile_id}"
      - id: "log:error-present"
        applies_to: "*"
        check: regex_match
        params:
          pattern: '\\b(ERROR|CRITICAL|FATAL)\\b'
        severity: LOW
        message: "Error-level entries found"
        fix_template: "Investigate errors in {profile_id}"
""")


def test_log_analysis_detects_traceback(tmp_path, monkeypatch):
    rules_file    = tmp_path / "rules.yaml"
    memory_file   = tmp_path / "memory.json"
    feedback_file = tmp_path / "feedback.json"
    rules_file.write_text(LOG_RULES)
    monkeypatch.setattr("builtins.input", lambda _: "skip")

    run(
        domain="log-analysis",
        paths=[str(FIXTURES / "sample.log")],
        rules_path=str(rules_file),
        memory_path=str(memory_file),
        feedback_path=str(feedback_file),
    )

    feedback_data = json.loads(feedback_file.read_text())
    rule_ids = {e["rule_id"] for e in feedback_data}
    assert "log:unhandled-exception" in rule_ids


def test_log_analysis_detects_error_entries(tmp_path, monkeypatch):
    rules_file    = tmp_path / "rules.yaml"
    memory_file   = tmp_path / "memory.json"
    feedback_file = tmp_path / "feedback.json"
    rules_file.write_text(LOG_RULES)
    monkeypatch.setattr("builtins.input", lambda _: "skip")

    run(
        domain="log-analysis",
        paths=[str(FIXTURES / "sample.log")],
        rules_path=str(rules_file),
        memory_path=str(memory_file),
        feedback_path=str(feedback_file),
    )

    feedback_data = json.loads(feedback_file.read_text())
    rule_ids = {e["rule_id"] for e in feedback_data}
    assert "log:error-present" in rule_ids


# ── csv domain ────────────────────────────────────────────────────────────────

CSV_RULES = textwrap.dedent("""\
    rules:
      - id: "csv:missing-id-column"
        applies_to: "*"
        check: csv_missing_column
        params:
          column: "id"
        severity: HIGH
        message: "Required 'id' column missing"
        fix_template: "Add 'id' column to {profile_id}"
      - id: "csv:missing-name-column"
        applies_to: "*"
        check: csv_missing_column
        params:
          column: "name"
        severity: MEDIUM
        message: "Expected 'name' column missing"
        fix_template: "Add 'name' column to {profile_id}"
""")


def test_csv_detects_missing_id_column(tmp_path, monkeypatch):
    rules_file    = tmp_path / "rules.yaml"
    memory_file   = tmp_path / "memory.json"
    feedback_file = tmp_path / "feedback.json"
    rules_file.write_text(CSV_RULES)
    monkeypatch.setattr("builtins.input", lambda _: "skip")

    run(
        domain="csv",
        paths=[str(FIXTURES / "sample.csv")],
        rules_path=str(rules_file),
        memory_path=str(memory_file),
        feedback_path=str(feedback_file),
    )

    feedback_data = json.loads(feedback_file.read_text())
    rule_ids = {e["rule_id"] for e in feedback_data}
    assert "csv:missing-id-column" in rule_ids


def test_csv_does_not_flag_present_column(tmp_path, capsys):
    rules_file = tmp_path / "rules.yaml"
    rules_file.write_text(textwrap.dedent("""\
        rules:
          - id: "csv:missing-email-column"
            applies_to: "*"
            check: csv_missing_column
            params:
              column: "email"
            severity: HIGH
            message: "Expected 'email' column missing"
            fix_template: "Add 'email' column to {profile_id}"
    """))

    run(
        domain="csv",
        paths=[str(FIXTURES / "sample.csv")],
        rules_path=str(rules_file),
        memory_path=str(tmp_path / "memory.json"),
        feedback_path=str(tmp_path / "feedback.json"),
    )

    assert "No issues found" in capsys.readouterr().out


# ── security domain ───────────────────────────────────────────────────────────

SECURITY_RULES = textwrap.dedent("""\
    rules:
      - id: "sec:fixable-vuln"
        applies_to: "*"
        check: regex_match
        params:
          pattern: 'fix:\\S+'
        severity: HIGH
        message: "Fix available — update the package"
        fix_template: "Update {profile_id} to fixed version"
      - id: "sec:no-fix-available"
        applies_to: "*"
        check: regex_no_match
        params:
          pattern: 'fix:\\S+'
        severity: MEDIUM
        message: "No fix released — assess risk"
        fix_template: "Mitigate unfixable vuln {profile_id}"
""")


def test_security_detects_fixable_vuln(tmp_path, monkeypatch):
    rules_file    = tmp_path / "rules.yaml"
    memory_file   = tmp_path / "memory.json"
    feedback_file = tmp_path / "feedback.json"
    rules_file.write_text(SECURITY_RULES)
    monkeypatch.setattr("builtins.input", lambda _: "skip")

    run(
        domain="security",
        paths=[str(FIXTURES / "sample_pip_audit.json")],
        rules_path=str(rules_file),
        memory_path=str(memory_file),
        feedback_path=str(feedback_file),
    )

    feedback_data = json.loads(feedback_file.read_text())
    rule_ids = {e["rule_id"] for e in feedback_data}
    assert "sec:fixable-vuln" in rule_ids


def test_security_detects_unfixable_vuln(tmp_path, monkeypatch):
    rules_file    = tmp_path / "rules.yaml"
    memory_file   = tmp_path / "memory.json"
    feedback_file = tmp_path / "feedback.json"
    rules_file.write_text(SECURITY_RULES)
    monkeypatch.setattr("builtins.input", lambda _: "skip")

    run(
        domain="security",
        paths=[str(FIXTURES / "sample_pip_audit.json")],
        rules_path=str(rules_file),
        memory_path=str(memory_file),
        feedback_path=str(feedback_file),
    )

    feedback_data = json.loads(feedback_file.read_text())
    rule_ids = {e["rule_id"] for e in feedback_data}
    assert "sec:no-fix-available" in rule_ids


def test_security_each_vuln_produces_exactly_one_finding(tmp_path, monkeypatch):
    rules_file    = tmp_path / "rules.yaml"
    memory_file   = tmp_path / "memory.json"
    feedback_file = tmp_path / "feedback.json"
    rules_file.write_text(SECURITY_RULES)
    monkeypatch.setattr("builtins.input", lambda _: "skip")

    run(
        domain="security",
        paths=[str(FIXTURES / "sample_pip_audit.json")],
        rules_path=str(rules_file),
        memory_path=str(memory_file),
        feedback_path=str(feedback_file),
    )

    feedback_data = json.loads(feedback_file.read_text())
    # fixture has 2 vulns (setuptools has none); fixable and no-fix rules are mutually exclusive
    assert len(feedback_data) == 2
