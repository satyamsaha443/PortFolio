import pytest
from unittest.mock import patch, MagicMock
from pathlib import Path


def _make_file(tmp_path: Path, name: str, content: str = "") -> Path:
    f = tmp_path / name
    f.write_text(content)
    return f


# ── run() return value ────────────────────────────────────────────────────────

def test_run_returns_true_when_findings(tmp_path):
    f = _make_file(tmp_path, "script.py", "x=1")

    mock_finding = MagicMock()
    mock_agent = MagicMock()
    mock_agent.analyze.return_value = [mock_finding]

    with patch("main.Agent", return_value=mock_agent), \
         patch("main.LongTermMemory"), \
         patch("main.FeedbackTracker"), \
         patch("main.RulesEngine"), \
         patch("main.ToolRegistry"):
        from main import run
        result = run("code-review", [str(f)])

    assert result is True


def test_run_returns_false_when_no_findings(tmp_path):
    f = _make_file(tmp_path, "script.py", "x=1")

    mock_agent = MagicMock()
    mock_agent.analyze.return_value = []

    with patch("main.Agent", return_value=mock_agent), \
         patch("main.LongTermMemory"), \
         patch("main.FeedbackTracker"), \
         patch("main.RulesEngine"), \
         patch("main.ToolRegistry"):
        from main import run
        result = run("code-review", [str(f)])

    assert result is False


# ── scan() return value ───────────────────────────────────────────────────────

def test_scan_returns_true_when_findings(tmp_path):
    f = _make_file(tmp_path, "app.py", "x=1")

    with patch("main.run", return_value=True), \
         patch("main._git_changed_files", return_value=[f]):
        from main import scan
        assert scan(None) is True


def test_scan_returns_false_when_no_findings(tmp_path):
    f = _make_file(tmp_path, "app.py", "x=1")

    with patch("main.run", return_value=False), \
         patch("main._git_changed_files", return_value=[f]):
        from main import scan
        assert scan(None) is False


def test_scan_returns_false_when_nothing_to_scan():
    with patch("main._git_changed_files", return_value=[]):
        from main import scan
        assert scan(None) is False


def test_scan_single_file_returns_true_when_findings(tmp_path):
    f = _make_file(tmp_path, "app.py", "x=1")

    with patch("main.run", return_value=True), \
         patch("main.detect_domain", return_value="code-review"):
        from main import scan
        assert scan(str(f)) is True


def test_scan_single_file_returns_false_when_no_findings(tmp_path):
    f = _make_file(tmp_path, "app.py", "x=1")

    with patch("main.run", return_value=False), \
         patch("main.detect_domain", return_value="code-review"):
        from main import scan
        assert scan(str(f)) is False


def test_scan_returns_true_if_any_domain_has_findings(tmp_path):
    py_file = _make_file(tmp_path, "app.py", "x=1")
    csv_file = _make_file(tmp_path, "data.csv", "id,name")

    call_count = [0]

    def fake_run(domain, paths, **_):
        call_count[0] += 1
        return domain == "code-review"  # only code-review has findings

    with patch("main.run", side_effect=fake_run), \
         patch("main._git_changed_files", return_value=[py_file, csv_file]):
        from main import scan
        assert scan(None) is True
