from models import Finding


def test_finding_defaults():
    f = Finding(
        rule_id="rule:test",
        profile_id="TestProfile",
        severity="HIGH",
        message="Test message",
        fix_draft="Add something",
    )
    assert f.confidence == 0.5


def test_finding_custom_confidence():
    f = Finding(
        rule_id="rule:test",
        profile_id="TestProfile",
        severity="MEDIUM",
        message="msg",
        fix_draft="fix",
        confidence=0.8,
    )
    assert f.confidence == 0.8


def test_finding_line_number_defaults_to_none():
    f = Finding(rule_id="r", profile_id="p", severity="HIGH", message="m", fix_draft="fix")
    assert f.line_number is None
