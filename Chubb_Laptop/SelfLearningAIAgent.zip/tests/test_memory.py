from memory import ShortTermMemory, LongTermMemory


def test_short_term_records():
    mem = ShortTermMemory(maxlen=5)
    mem.record("rule:a", "ProfileA", 0.8)
    assert len(mem.recent()) == 1


def test_short_term_caps_at_maxlen():
    mem = ShortTermMemory(maxlen=3)
    for i in range(5):
        mem.record(f"rule:{i}", f"profile:{i}", float(i))
    recent = mem.recent()
    assert len(recent) == 3
    assert recent[0]["rule_id"] == "rule:2"


def test_short_term_clear():
    mem = ShortTermMemory(maxlen=5)
    mem.record("rule:1", "p1", 1.0)
    mem.clear()
    assert mem.recent() == []


def test_long_term_save_and_recall(tmp_path):
    mem = LongTermMemory(path=str(tmp_path / "memory.json"))
    mem.save("rule:test", {"attempts": 3, "confirmed": 2, "confidence": 0.67})
    assert mem.recall("rule:test")["confidence"] == 0.67


def test_long_term_persists_across_instances(tmp_path):
    path = str(tmp_path / "memory.json")
    LongTermMemory(path=path).save("rule:x", {"attempts": 1, "confirmed": 1, "confidence": 1.0})
    assert LongTermMemory(path=path).recall("rule:x")["confidence"] == 1.0


def test_long_term_recall_missing_returns_default(tmp_path):
    mem = LongTermMemory(path=str(tmp_path / "memory.json"))
    assert mem.recall("rule:missing") is None
    assert mem.recall("rule:missing", default={}) == {}


def test_long_term_all(tmp_path):
    mem = LongTermMemory(path=str(tmp_path / "memory.json"))
    mem.save("rule:a", {"confidence": 0.5})
    mem.save("rule:b", {"confidence": 0.9})
    assert len(mem.all()) == 2
