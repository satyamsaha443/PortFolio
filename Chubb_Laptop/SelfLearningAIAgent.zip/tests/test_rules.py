import textwrap
import pytest
import yaml as _yaml
from rules import RulesEngine

SAMPLE_RULES = textwrap.dedent("""\
    rules:
      - id: missing-client-credentials
        name: "Missing client credentials on non-interactive profile"
        applies_to: "login-NonInteractive"
        check: has_metadata_key
        params:
          key: "client_id"
        severity: HIGH
        message: "Non-interactive profiles require client_id in Metadata."
        fix_template: "Add client_id to <Metadata> in {profile_id}"

      - id: missing-output-claims
        name: "TechnicalProfile missing OutputClaims"
        applies_to: "*"
        check: has_element
        params:
          element: "OutputClaims"
        severity: MEDIUM
        message: "Profile has no OutputClaims."
        fix_template: "Add <OutputClaims> to {profile_id}"
""")


def make_engine(tmp_path):
    rules_file = tmp_path / "rules.yaml"
    rules_file.write_text(SAMPLE_RULES)
    return RulesEngine(rules_path=str(rules_file))


def test_prefix_rule_fires_on_matching_profile(tmp_path):
    engine = make_engine(tmp_path)
    profiles = [{"id": "login-NonInteractive-AccessToken", "metadata_keys": [], "elements": ["OutputClaims"]}]
    findings = engine.apply(profiles)
    assert any(f.rule_id == "missing-client-credentials" for f in findings)


def test_prefix_rule_skips_non_matching_profile(tmp_path):
    engine = make_engine(tmp_path)
    profiles = [{"id": "SelfAsserted-Signup", "metadata_keys": [], "elements": ["OutputClaims"]}]
    findings = engine.apply(profiles)
    assert not any(f.rule_id == "missing-client-credentials" for f in findings)


def test_wildcard_rule_fires_on_all_profiles(tmp_path):
    engine = make_engine(tmp_path)
    profiles = [
        {"id": "SelfAsserted-A", "metadata_keys": [], "elements": []},
        {"id": "login-NonInteractive-B", "metadata_keys": ["client_id"], "elements": []},
    ]
    findings = engine.apply(profiles)
    assert len([f for f in findings if f.rule_id == "missing-output-claims"]) == 2


def test_rule_does_not_fire_when_condition_met(tmp_path):
    engine = make_engine(tmp_path)
    profiles = [{"id": "login-NonInteractive-OK", "metadata_keys": ["client_id"], "elements": ["OutputClaims"]}]
    assert engine.apply(profiles) == []


def test_fix_draft_is_raw_template(tmp_path):
    engine = make_engine(tmp_path)
    profiles = [{"id": "login-NonInteractive-Test", "metadata_keys": [], "elements": ["OutputClaims"]}]
    findings = engine.apply(profiles)
    f = next(f for f in findings if f.rule_id == "missing-client-credentials")
    assert "{profile_id}" in f.fix_draft


def test_finding_severity(tmp_path):
    engine = make_engine(tmp_path)
    profiles = [{"id": "login-NonInteractive-Test", "metadata_keys": [], "elements": ["OutputClaims"]}]
    findings = engine.apply(profiles)
    f = next(f for f in findings if f.rule_id == "missing-client-credentials")
    assert f.severity == "HIGH"


# ── helpers ──────────────────────────────────────────────────────────────────

def make_rule(check, params, applies_to="*", match_field=None, rule_id="test:rule"):
    rule = {
        "id": rule_id,
        "check": check,
        "params": params,
        "severity": "HIGH",
        "message": "test message",
        "fix_template": "fix {profile_id}",
        "applies_to": applies_to,
    }
    if match_field:
        rule["match_field"] = match_field
    return rule


def write_engine(tmp_path, rules):
    f = tmp_path / "rules.yaml"
    f.write_text(_yaml.dump({"rules": rules}))
    return RulesEngine(rules_path=str(f))


# ── regex_match ───────────────────────────────────────────────────────────────

def test_regex_match_fires_when_pattern_found(tmp_path):
    engine = write_engine(tmp_path, [make_rule("regex_match", {"pattern": r"eval\s*\("})])
    findings = engine.apply([{"id": "src/main.py", "content": "result = eval(user_input)"}])
    assert len(findings) == 1
    assert findings[0].rule_id == "test:rule"


def test_regex_match_does_not_fire_when_pattern_absent(tmp_path):
    engine = write_engine(tmp_path, [make_rule("regex_match", {"pattern": r"eval\s*\("})])
    # "ast.literal_eval(s)" contains "eval(" as a substring so use content with no eval call
    findings = engine.apply([{"id": "src/main.py", "content": "x = safe_parse(s)"}])
    assert findings == []


# ── regex_no_match ────────────────────────────────────────────────────────────

def test_regex_no_match_fires_when_pattern_absent(tmp_path):
    engine = write_engine(tmp_path, [make_rule("regex_no_match", {"pattern": "resources:"})])
    findings = engine.apply([{"id": "deploy.yaml::Deployment/app", "content": "spec:\n  containers: []"}])
    assert len(findings) == 1


def test_regex_no_match_does_not_fire_when_pattern_present(tmp_path):
    engine = write_engine(tmp_path, [make_rule("regex_no_match", {"pattern": "resources:"})])
    findings = engine.apply([{"id": "deploy.yaml::Deployment/app", "content": "resources:\n  limits:\n    cpu: 500m"}])
    assert findings == []


# ── yaml_path_missing ─────────────────────────────────────────────────────────

def test_yaml_path_missing_fires_when_path_absent(tmp_path):
    engine = write_engine(tmp_path, [make_rule("yaml_path_missing", {"path": "spec.template.spec.securityContext"})])
    profile = {"id": "deploy.yaml::Deployment/app", "content": "", "raw": {"spec": {"template": {"spec": {}}}}}
    assert len(engine.apply([profile])) == 1


def test_yaml_path_missing_does_not_fire_when_path_present(tmp_path):
    engine = write_engine(tmp_path, [make_rule("yaml_path_missing", {"path": "spec.template.spec.securityContext"})])
    profile = {
        "id": "deploy.yaml::Deployment/app",
        "content": "",
        "raw": {"spec": {"template": {"spec": {"securityContext": {"runAsNonRoot": True}}}}},
    }
    assert engine.apply([profile]) == []


def test_yaml_path_missing_handles_shallow_raw(tmp_path):
    engine = write_engine(tmp_path, [make_rule("yaml_path_missing", {"path": "a.b.c"})])
    profile = {"id": "x", "content": "", "raw": {}}
    assert len(engine.apply([profile])) == 1


# ── yaml_value_equals ─────────────────────────────────────────────────────────

def test_yaml_value_equals_fires_when_value_matches(tmp_path):
    engine = write_engine(tmp_path, [make_rule("yaml_value_equals", {"path": "spec.template.spec.hostNetwork", "value": True})])
    profile = {
        "id": "deploy.yaml::Deployment/app",
        "content": "",
        "raw": {"spec": {"template": {"spec": {"hostNetwork": True}}}},
    }
    assert len(engine.apply([profile])) == 1


def test_yaml_value_equals_does_not_fire_when_value_differs(tmp_path):
    engine = write_engine(tmp_path, [make_rule("yaml_value_equals", {"path": "spec.template.spec.hostNetwork", "value": True})])
    profile = {
        "id": "deploy.yaml::Deployment/app",
        "content": "",
        "raw": {"spec": {"template": {"spec": {"hostNetwork": False}}}},
    }
    assert engine.apply([profile]) == []


def test_yaml_value_equals_does_not_fire_when_path_missing(tmp_path):
    engine = write_engine(tmp_path, [make_rule("yaml_value_equals", {"path": "spec.hostNetwork", "value": True})])
    profile = {"id": "x", "content": "", "raw": {"spec": {}}}
    assert engine.apply([profile]) == []


# ── match_field ───────────────────────────────────────────────────────────────

def test_match_field_extension_scopes_rule_to_py_files(tmp_path):
    engine = write_engine(tmp_path, [make_rule(
        "regex_match", {"pattern": r"print\s*\("}, applies_to="py", match_field="extension"
    )])
    py_profile = {"id": "src/main.py", "extension": "py", "content": "print('hello')"}
    js_profile = {"id": "src/main.js", "extension": "js", "content": "print('hello')"}
    findings = engine.apply([py_profile, js_profile])
    assert len(findings) == 1
    assert findings[0].profile_id == "src/main.py"


def test_match_field_source_scopes_rule_to_kubernetes(tmp_path):
    engine = write_engine(tmp_path, [make_rule(
        "regex_no_match", {"pattern": "resources:"}, applies_to="kubernetes", match_field="source"
    )])
    k8s = {"id": "deploy.yaml::Deployment/app", "source": "kubernetes", "content": "spec: {}"}
    gha = {"id": "ci.yml::Workflow/CI", "source": "github-actions", "content": "spec: {}"}
    findings = engine.apply([k8s, gha])
    assert len(findings) == 1
    assert findings[0].profile_id == "deploy.yaml::Deployment/app"


# ── startup validation ────────────────────────────────────────────────────────

def test_bad_regex_in_regex_match_rule_exits_at_startup(tmp_path):
    f = tmp_path / "rules.yaml"
    f.write_text(_yaml.dump({"rules": [make_rule("regex_match", {"pattern": "[bad(regex"})]}))
    with pytest.raises(SystemExit):
        RulesEngine(rules_path=str(f))


def test_bad_regex_in_regex_no_match_rule_exits_at_startup(tmp_path):
    f = tmp_path / "rules.yaml"
    f.write_text(_yaml.dump({"rules": [make_rule("regex_no_match", {"pattern": "[bad(regex"})]}))
    with pytest.raises(SystemExit):
        RulesEngine(rules_path=str(f))


def test_extension_match_does_not_match_json_against_js_rule(tmp_path):
    engine = write_engine(tmp_path, [make_rule(
        "regex_match", {"pattern": r"console\.log\s*\("}, applies_to="js", match_field="extension"
    )])
    json_profile = {"id": "config.json", "extension": "json", "content": "console.log('debug')"}
    assert engine.apply([json_profile]) == []


# ── csv_missing_column ────────────────────────────────────────────────────────

def test_csv_missing_column_fires_when_column_absent(tmp_path):
    engine = write_engine(tmp_path, [make_rule("csv_missing_column", {"column": "email"})])
    profile = {"id": "data.csv", "headers": ["name", "age"]}
    assert len(engine.apply([profile])) == 1


def test_csv_missing_column_does_not_fire_when_column_present(tmp_path):
    engine = write_engine(tmp_path, [make_rule("csv_missing_column", {"column": "email"})])
    profile = {"id": "data.csv", "headers": ["name", "email", "age"]}
    assert engine.apply([profile]) == []


def test_csv_missing_column_fires_when_headers_empty(tmp_path):
    engine = write_engine(tmp_path, [make_rule("csv_missing_column", {"column": "id"})])
    profile = {"id": "data.csv", "headers": []}
    assert len(engine.apply([profile])) == 1


# ── line_number population ────────────────────────────────────────────────────

REGEX_RULES = textwrap.dedent("""\
    rules:
      - id: debug-print
        name: "Debug print statement"
        applies_to: "py"
        match_field: extension
        check: regex_match
        params:
          pattern: "\\\\bprint\\\\("
        severity: LOW
        message: "Debug print() found."
        fix_template: "Remove the print() statement."

      - id: missing-k8s-limits
        name: "No resource limits"
        applies_to: "*"
        check: yaml_path_missing
        params:
          path: "spec.containers.0.resources.limits"
        severity: HIGH
        message: "No resource limits defined."
        fix_template: "Add resource limits."
""")


def _make_regex_engine(tmp_path):
    f = tmp_path / "rules.yaml"
    f.write_text(REGEX_RULES)
    return RulesEngine(rules_path=str(f))


def test_regex_match_finding_has_correct_line_number(tmp_path):
    engine = _make_regex_engine(tmp_path)
    # print( is on line 3
    profile = {
        "id": "script.py",
        "extension": "py",
        "content": "x = 1\ny = 2\nprint('debug')\nz = 3\n",
        "raw": {"spec": {"containers": {"0": {"resources": {"limits": {"cpu": "100m"}}}}}},
    }
    findings = engine.apply([profile])
    assert len(findings) == 1
    assert findings[0].rule_id == "debug-print"
    assert findings[0].line_number == 3


def test_non_regex_finding_has_line_number_none(tmp_path):
    engine = _make_regex_engine(tmp_path)
    profile = {
        "id": "deployment.yaml::Deployment/app",
        "extension": "yaml",
        "content": "",
        "raw": {},  # missing nested path → yaml_path_missing fires
    }
    findings = engine.apply([profile])
    yaml_findings = [f for f in findings if f.rule_id == "missing-k8s-limits"]
    assert yaml_findings
    assert yaml_findings[0].line_number is None
