import os

# # # # # # # API_KEY = "abc123verysecret"
password = "hunter2"

def run(user_input):
# # # # # # #     result = eval(user_input)
# # # # # # #     print(result)
    return result
