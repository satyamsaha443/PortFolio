const API_KEY = "secret-token-xyz";

function run(input) {
    console.log("debug:", input);
    return eval(input);
}
