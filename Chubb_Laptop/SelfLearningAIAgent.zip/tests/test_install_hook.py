import stat
import sys
from pathlib import Path
from unittest.mock import patch
import pytest


EXPECTED_HOOK = "#!/bin/sh\npython main.py scan\n"


def _fake_git_hooks(tmp_path: Path) -> Path:
    hooks = tmp_path / ".git" / "hooks"
    hooks.mkdir(parents=True)
    return hooks


# ── happy path ────────────────────────────────────────────────────────────────

def test_install_writes_hook_file(tmp_path):
    hooks = _fake_git_hooks(tmp_path)

    import scripts.install_hook as ih
    with patch.object(ih, "_hooks_dir", lambda: hooks):
        ih.install()

    hook = hooks / "pre-commit"
    assert hook.exists()
    assert hook.read_text() == EXPECTED_HOOK


@pytest.mark.skipif(sys.platform == "win32", reason="chmod doesn't set S_IEXEC on Windows")
def test_install_hook_is_executable(tmp_path):
    hooks = _fake_git_hooks(tmp_path)

    import scripts.install_hook as ih
    with patch.object(ih, "_hooks_dir", lambda: hooks):
        ih.install()

    hook = hooks / "pre-commit"
    mode = hook.stat().st_mode
    assert mode & stat.S_IEXEC


def test_install_overwrites_on_y(tmp_path):
    hooks = _fake_git_hooks(tmp_path)
    hook = hooks / "pre-commit"
    hook.write_text("old content")

    import scripts.install_hook as ih
    with patch.object(ih, "_hooks_dir", lambda: hooks), \
         patch("builtins.input", return_value="y"):
        ih.install()

    assert hook.read_text() == EXPECTED_HOOK


def test_install_aborts_on_n(tmp_path):
    hooks = _fake_git_hooks(tmp_path)
    hook = hooks / "pre-commit"
    hook.write_text("old content")

    import scripts.install_hook as ih
    with patch.object(ih, "_hooks_dir", lambda: hooks), \
         patch("builtins.input", return_value="n"):
        ih.install()

    assert hook.read_text() == "old content"


def test_install_aborts_on_empty(tmp_path):
    hooks = _fake_git_hooks(tmp_path)
    hook = hooks / "pre-commit"
    hook.write_text("old content")

    import scripts.install_hook as ih
    with patch.object(ih, "_hooks_dir", lambda: hooks), \
         patch("builtins.input", return_value=""):
        ih.install()

    assert hook.read_text() == "old content"


def test_install_errors_if_not_git_repo(tmp_path, capsys):
    import scripts.install_hook as ih

    no_git = tmp_path / ".git" / "hooks"  # does NOT exist

    with patch.object(ih, "_hooks_dir", lambda: no_git), \
         pytest.raises(SystemExit) as exc_info:
        ih.install()

    assert exc_info.value.code == 1
    assert "not found" in capsys.readouterr().err
