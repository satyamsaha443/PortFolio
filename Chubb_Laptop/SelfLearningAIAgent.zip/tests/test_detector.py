from pathlib import Path
import pytest
from detector import detect_domain


def test_py_is_code_review(tmp_path):
    f = tmp_path / "script.py"
    f.write_text("x = 1")
    assert detect_domain(f) == "code-review"


def test_js_is_code_review(tmp_path):
    f = tmp_path / "app.js"
    f.write_text("const x = 1;")
    assert detect_domain(f) == "code-review"


def test_ts_is_code_review(tmp_path):
    f = tmp_path / "app.ts"
    f.write_text("const x: number = 1;")
    assert detect_domain(f) == "code-review"


def test_sh_is_code_review(tmp_path):
    f = tmp_path / "run.sh"
    f.write_text("#!/bin/bash")
    assert detect_domain(f) == "code-review"


def test_go_is_code_review(tmp_path):
    f = tmp_path / "main.go"
    f.write_text("package main")
    assert detect_domain(f) == "code-review"


def test_log_is_log_analysis(tmp_path):
    f = tmp_path / "app.log"
    f.write_text("INFO starting")
    assert detect_domain(f) == "log-analysis"


def test_csv_is_csv(tmp_path):
    f = tmp_path / "data.csv"
    f.write_text("id,name\n1,alice")
    assert detect_domain(f) == "csv"


def test_audit_json_is_security(tmp_path):
    f = tmp_path / "pip_audit_results.json"
    f.write_text("[]")
    assert detect_domain(f) == "security"


def test_pip_json_is_security(tmp_path):
    f = tmp_path / "pip-audit.json"
    f.write_text("[]")
    assert detect_domain(f) == "security"


def test_unknown_extension_is_none(tmp_path):
    f = tmp_path / "README.md"
    f.write_text("# hello")
    assert detect_domain(f) is None


def test_yaml_k8s_is_infra(tmp_path):
    f = tmp_path / "deployment.yaml"
    f.write_text("apiVersion: apps/v1\nkind: Deployment\nmetadata:\n  name: app\n")
    assert detect_domain(f) == "infra"


def test_yaml_gha_is_infra(tmp_path):
    f = tmp_path / "ci.yml"
    f.write_text("on:\n  push:\n    branches: [main]\njobs:\n  build:\n    runs-on: ubuntu-latest\n")
    assert detect_domain(f) == "infra"


def test_yaml_generic_is_infra(tmp_path):
    f = tmp_path / "config.yaml"
    f.write_text("key: value\n")
    assert detect_domain(f) == "infra"
