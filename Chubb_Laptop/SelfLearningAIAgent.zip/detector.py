from pathlib import Path

_EXTENSION_MAP: dict[str, str] = {
    ".py":   "code-review",
    ".js":   "code-review",
    ".ts":   "code-review",
    ".sh":   "code-review",
    ".go":   "code-review",
    ".rb":   "code-review",
    ".java": "code-review",
    ".log":  "log-analysis",
    ".csv":  "csv",
}

_SECURITY_JSON_PATTERNS = ("audit", "pip")


def _sniff_yaml(path: Path) -> str:
    return "infra"


def detect_domain(path: Path) -> str | None:
    suffix = path.suffix.lower()
    if suffix in (".yaml", ".yml"):
        return _sniff_yaml(path)
    if suffix == ".json":
        name = path.name.lower()
        if any(p in name for p in _SECURITY_JSON_PATTERNS):
            return "security"
        return None
    return _EXTENSION_MAP.get(suffix)
